from django.urls import path
from . import views

app_name = 'Staff'

urlpatterns = [
    path('', views.Index, name='Index'),
    path('User/', views.UserManagement, name='User'),
    path('Forum/', views.Forum, name='Forum'),
    path('File/', views.File, name='File'),
    path('ArticleInfoApi/<int:article_id>/', views.ArticleInfoApi, name='ArticleInfoApi'),
    path('GraphArticle/Edit/<str:knowledge_url>/', views.GraphArticleEdit, name='GraphArticleEdit'),
    path('GraphArticle/Save/', views.GraphArticleSave, name='GraphArticleSave'),
    path('GraphArticle/', views.GraphArticleManagement, name='GraphArticle'),
    path('Knowledge/', views.KnowledgeManagement, name='Knowledge'),
    path('ChartsRecord/', views.ChartsRecord, name='ChartsRecord'),
]