from django import template
from Knowledge.models import GraphArticle

register = template.Library()

@register.filter

def graph_article_count(knowledge_url):
    return GraphArticle.objects.filter(knowledge_url=knowledge_url).count()