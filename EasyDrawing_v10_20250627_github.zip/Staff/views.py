from django.shortcuts import render, reverse, redirect, get_object_or_404
import json
from django.views.decorators.http import require_http_methods
from User.models import User
from Forum.models import Article, Comment
from django.db.models import Q
import re
import hashlib
from django.core.files.storage import FileSystemStorage
from django.conf import settings
import os
from django.http import JsonResponse
import shutil
from datetime import datetime
from django.db.models import Min
from Knowledge.models import ChartKnowledge, GraphArticle
import time
from Chart.models import Chart, File

def GraphArticleEdit(request, knowledge_url):
    request.session['page'] = reverse('Staff:GraphArticle')
    user = {
        'nickname': request.session.get('nickname', ''),
        'username': request.session.get('username', ''),
        'role': request.session.get('role', 0)
    }
    # 非法访问，重定向到搜索页面
    if user['role'] == 0:
        return redirect(reverse('Knowledge:Search') + '?word=无管理员权限')

    # 获取所有知识链接用于下拉选择，排除已创建详情的链接
    existing_knowledge_urls = GraphArticle.objects.values_list('knowledge_url', flat=True).distinct()
    # 编辑时保留当前知识链接在下拉选项中
    knowledges = ChartKnowledge.objects.exclude(knowledge_url__in=existing_knowledge_urls).union(
        ChartKnowledge.objects.filter(knowledge_url=knowledge_url)
    )

    # 获取当前知识链接下的所有内容块
    # 排除标题类型的内容块，标题由ChartKnowledge的name字段管理
    content_blocks = GraphArticle.objects.filter(knowledge_url=knowledge_url).order_by('order')

    # 从ChartKnowledge获取文章标题
    knowledge = get_object_or_404(ChartKnowledge, knowledge_url=knowledge_url)
    article_title = knowledge.name

    context = {
        'user': user,
        'knowledge_url': knowledge_url,
        'knowledges': knowledges,
        'content_blocks': content_blocks,
        'article_title': article_title
    }

    return render(request, 'Staff_GraphArticle_Edit.html', context=context)


@require_http_methods(['POST'])
def GraphArticleSave(request):
    """
    保存知识详情文章内容块的视图函数
    处理知识链接变更、内容块的新增、编辑、删除和排序
    
    参数:
        request: HTTP请求对象，包含POST数据
            - knowledge_url_old: 原始知识链接ID
            - knowledge_url: 新知识链接ID
            - article_title: 文章标题
            - content_blocks: JSON格式的内容块列表
                每个内容块包含: id, content_type, content_detail, order
    
    返回:
        JsonResponse: 包含操作结果的JSON响应
            - success: 布尔值，表示操作是否成功
            - message: 字符串，操作结果描述
    """
    try:
        # 从POST数据中获取参数并处理
        knowledge_url_old = request.POST.get('knowledge_url_old', '').strip()  # 原始知识链接ID
        knowledge_url = request.POST.get('knowledge_url', '').strip()          # 新知识链接ID
        content_blocks = json.loads(request.POST.get('content_blocks', '[]'))  # 内容块列表(JSON解析)

        # 验证新知识链接是否存在于图表知识库中
        # 防止使用无效的知识链接ID导致数据关联错误
        if not ChartKnowledge.objects.filter(knowledge_url=knowledge_url).exists():
            return JsonResponse({'success': False, 'message': '保存失败：知识链接ID不存在'})

        # 处理知识链接变更时的内容块迁移
        # 条件：原始链接存在 + 链接已变更 + 有新内容块（避免空内容迁移）
        if knowledge_url_old and knowledge_url_old != knowledge_url and content_blocks:
            # 将原知识链接下的所有内容块迁移到新知识链接
            GraphArticle.objects.filter(knowledge_url=knowledge_url_old).update(knowledge_url=knowledge_url)

        # 处理内容块数据：新增或更新
        # 删除该知识链接下的所有现有内容块
        GraphArticle.objects.filter(knowledge_url=knowledge_url).delete()
        print('已删除所有现有内容块，准备写入新内容')

        # 遍历前端提交的所有内容块列表，重新创建所有内容块
        for block in content_blocks:
            content_type = block.get('content_type', 'text')  # 内容类型（标题/文本/代码等）
            content_detail = block.get('content_detail', '').strip()  # 内容详情
            order = block.get('order', 0)  # 显示顺序

            # 跟踪新创建的内容块ID
            new_block_ids = []

            # 仅处理非空内容块
            if content_detail:
                # 调试：记录新内容块信息
                print('Creating new block:', { 'knowledge_url': knowledge_url, 'content_type': content_type, 'content_detail': content_detail, 'order': order })
                try:
                    # 确保order是整数类型
                    order_int = int(order)
                except (ValueError, TypeError):
                    order_int = 0
                    print(f'Invalid order value: {order}. Using default order 0.')
                
                try:
                    new_block = GraphArticle.objects.create(
                        knowledge_url=knowledge_url,
                        content_type=content_type,
                        content=content_detail,
                        order=order_int
                    )
                    print(f'New block created successfully with ID: {new_block.id}')
                    new_block_ids.append(new_block.id)
                except Exception as e:
                    print('Error creating new block:', str(e))

        # 调试：记录接收到的内容块数据
        print('content_blocks received:', content_blocks)

        return JsonResponse({'success': True, 'message': '保存成功'})
    except Exception as e:
        # 捕获所有异常并返回错误信息
        # 用于调试和用户反馈，生产环境可考虑更具体的异常处理
        return JsonResponse({'success': False, 'message': str(e)})


def GraphArticleManagement(request):
    request.session['page'] = reverse('Staff:GraphArticle')
    user = {
        'nickname': request.session.get('nickname', ''),
        'username': request.session.get('username', ''),
        'role': request.session.get('role', 0)
    }
    # 非法访问，重定向到搜索页面
    if user['role'] == 0:
        return redirect(reverse('Knowledge:Search') + '?word=无管理员权限')

    # 设置默认notice
    notice = {
        'color': '#2c2735',
        'text': '欢迎进入知识详情管理平台',
    }

    # 获取所有知识链接用于下拉选择
    knowledges = ChartKnowledge.objects.all()

    # 处理POST请求
    if request.method == 'POST':
        # 新增详情内容
        if 'addGraphArticleButton' in request.POST:
            knowledge_url = request.POST.get('addKnowledgeUrl', '').strip()
            title = request.POST.get('addTitle', '').strip()
            if knowledge_url and title:
                # 检查该知识链接是否已存在标题
                existing_article = GraphArticle.objects.filter(knowledge_url=knowledge_url).exists()
                if existing_article:
                    notice = {'color': '#dc3545', 'text': '保存失败：该知识链接已存在详情，请先编辑现有详情！'}
                else:
                    # 创建标题类型内容块，默认顺序为1
                    GraphArticle.objects.create(
                        knowledge_url=knowledge_url,
                        content_type='title',
                        content=title,
                        order=1
                    )
                    notice = {'color': '#28a745', 'text': '科普详情新增成功！已为您定位。'}
            else:
                notice = {'color': '#dc3545', 'text': '知识链接ID和全局标题为必填项！'}

        # 编辑详情内容
        elif 'updateGraphArticleButton' in request.POST:
            article_id = request.POST.get('updateGraphArticleButton')
            if not article_id:
                notice = {'color': '#dc3545', 'text': '内容ID不存在！'}
            else:
                knowledge_url = request.POST.get(f'updateKnowledgeUrl{article_id}', '').strip()
                content_type = request.POST.get(f'updateContentType{article_id}', '').strip()
                content = request.POST.get(f'updateContent{article_id}', '').strip()
                order = request.POST.get(f'updateOrder{article_id}', '').strip()
                if knowledge_url and content_type and content and order:
                    try:
                        article = get_object_or_404(GraphArticle, id=article_id)
                        article.knowledge_url = knowledge_url
                        article.content_type = content_type
                        article.content = content
                        article.order = int(order)
                        article.save()
                        notice = {'color': '#28a745', 'text': '详情内容修改成功！'}
                    except Exception as e:
                        notice = {'color': '#dc3545', 'text': f'修改失败：{str(e)}'}
                else:
                    notice = {'color': '#dc3545', 'text': '所有字段均为必填项！'}

        # 删除详情内容
        elif 'deleteGraphArticleButton' in request.POST:
            article_id = request.POST.get('deleteGraphArticleButton')
            GraphArticle.objects.filter(id=article_id).delete()
            notice = {'color': '#28a745', 'text': '详情内容删除成功！'}

    # 处理仅显示order=1的筛选
    # 使用子查询获取每个knowledge_url的最小ID(对应order=1的记录)
    graph_articles = GraphArticle.objects.all().order_by('knowledge_url', 'order')
    subquery = GraphArticle.objects.filter(order=1).values('knowledge_url').annotate(min_id=Min('id')).values('min_id')
    graph_articles = graph_articles.filter(id__in=subquery)
    display_mode = 'only_order_one' # 模式改为仅显示order=1的筛选
    # 处理搜索和筛选参数
    searchKeyword = ''
    filter_options = []

    if request.method == 'POST' and 'selectButton' in request.POST:
        # 来自搜索表单提交
        searchKeyword = request.POST.get('searchKeyword', '').strip()
        filter_options = request.POST.getlist('filterOption')
        if searchKeyword or filter_options:
            notice = {
                'color': '#3c6df5',
                'text': '筛选成功！',
            }
    else:
        # 来自GET参数
        searchKeyword = request.GET.get('searchKeyword', '').strip()
        filter_options = request.GET.getlist('filterOption')

    # 查询详情内容数据
    if 'all_displayed' in filter_options:
        # 排除标题类型的内容块，标题由ChartKnowledge的name字段管理
        graph_articles = GraphArticle.objects.all().order_by('knowledge_url', 'order')
        filter_options.remove('all_displayed')
        display_mode = 'all_displayed' # 模式改为查询详情内容

    # 应用筛选
    if filter_options:
        graph_articles = graph_articles.filter(content_type__in=filter_options)

    # 应用搜索
    if searchKeyword:
        graph_articles = graph_articles.filter(
            Q(knowledge_url__icontains=searchKeyword) | 
            Q(content__icontains=searchKeyword)
        )

    # 新增成功后自动筛选当前知识链接
    if request.method == 'POST' and 'addGraphArticleButton' in request.POST:
        knowledge_url = request.POST.get('addKnowledgeUrl', '').strip()
        if knowledge_url:
            graph_articles = graph_articles.filter(knowledge_url=knowledge_url)

    context = {
        'user': user,
        'notice': notice,
        'data': graph_articles,
        'knowledges': knowledges,
        'display_mode': display_mode,
    }

    return render(request, 'Staff_GraphArticle.html', context=context)


def KnowledgeManagement(request):
    request.session['page'] = reverse('Staff:Knowledge')
    user = {
        'nickname': request.session.get('nickname', ''),
        'username': request.session.get('username', ''),
        'role': request.session.get('role', 0)
    }
    print(user)
    # 非法访问，重定向到搜索页面
    if user['role'] == 0:
        print('非法访问，无管理员权限')
        return redirect(reverse('Knowledge:Search') + '?word=无管理员权限')

    # 设置默认notice
    notice = {
        'color': '#2c2735',
        'text': '欢迎进入知识科普管理平台',
    }

    # 处理POST请求
    if request.method == 'POST':
        # 新增知识科普
        if 'addKnowledgeButton' in request.POST:
            name = request.POST.get('addName', '').strip()
            info = request.POST.get('addInfo', '').strip()
            about = request.POST.get('addAbout', '').strip()
            knowledge_url = request.POST.get('addKnowledgeUrl', '').strip()
            chart_url = request.POST.get('addChartUrl', '').strip()
            img = request.POST.get('addImg', '').strip()
            common_mistakes = request.POST.getlist('commonMistakes')
            if name:
                ChartKnowledge.objects.create(
                    name=name,
                    info=info,
                    about=about,
                    knowledge_url=knowledge_url,
                    chart_url=chart_url,
                    img=img,
                    common_mistakes=[m for m in common_mistakes if m.strip()],
                )
                notice = {'color': '#28a745', 'text': '知识科普新增成功！'}
            else:
                notice = {'color': '#dc3545', 'text': '知识名称不能为空！'}

        # 编辑知识科普
        elif 'updateKnowledgeButton' in request.POST:
            knowledge_id = request.POST.get('updateKnowledgeButton')
            name = request.POST.get(f'updateName{knowledge_id}', '').strip()
            info = request.POST.get(f'updateInfo{knowledge_id}', '').strip()
            about = request.POST.get(f'updateAbout{knowledge_id}', '').strip()
            knowledge_url = request.POST.get(f'updateKnowledgeUrl{knowledge_id}', '').strip()
            chart_url = request.POST.get(f'updateChartUrl{knowledge_id}', '').strip()
            img = request.POST.get(f'updateImg{knowledge_id}', '').strip()
            common_mistakes = request.POST.getlist(f'updateCommonMistakes{knowledge_id}')
            if name:
                knowledge = ChartKnowledge.objects.get(id=knowledge_id)
                knowledge.name = name
                knowledge.info = info
                knowledge.about = about
                knowledge.knowledge_url = knowledge_url
                knowledge.chart_url = chart_url
                knowledge.img = img
                knowledge.common_mistakes = [m for m in common_mistakes if m.strip()]
                knowledge.save()
                notice = {'color': '#28a745', 'text': '知识科普修改成功！'}
            else:
                notice = {'color': '#dc3545', 'text': '知识名称不能为空！'}

        # 删除知识科普及其关联文章
        elif 'deleteKnowledgeButton' in request.POST:
            knowledge_id = request.POST.get('deleteKnowledgeButton')
            # 获取要删除的知识科普对象
            knowledge = get_object_or_404(ChartKnowledge, id=knowledge_id)
            # 删除关联的所有文章内容块
            GraphArticle.objects.filter(knowledge_url=knowledge.knowledge_url).delete()
            # 删除知识科普本身
            knowledge.delete()
            notice = {'color': '#28a745', 'text': '知识科普及其关联文章删除成功！'}

    # 查询知识科普数据
    chart_knowledges = ChartKnowledge.objects.all()

    # 处理搜索和筛选参数
    searchKeyword = ''
    filter_options = []

    if request.method == 'POST' and 'selectButton' in request.POST:
        # 来自搜索表单提交
        searchKeyword = request.POST.get('searchKeyword', '').strip()
        filter_options = request.POST.getlist('filterOption')
    else:
        # 来自GET参数
        searchKeyword = request.GET.get('searchKeyword', '').strip()
        filter_options = request.GET.getlist('filterOption')

    # 应用筛选
    if '1' in filter_options:  # 有知识链接
        chart_knowledges = chart_knowledges.exclude(knowledge_url='')
    if '2' in filter_options:  # 有绘制链接
        chart_knowledges = chart_knowledges.exclude(chart_url='')

    # 应用搜索
    if searchKeyword:
        chart_knowledges = chart_knowledges.filter(
            Q(name__icontains=searchKeyword) | 
            Q(info__icontains=searchKeyword)
        )

    context = {
        'user': user,
        'notice': notice,
        'data': chart_knowledges,
    }

    return render(request, 'Staff_Knowledge.html', context=context)


def INDEX_LIST():
    """
    网页信息列表
    :return: 内含字典的顺序列表，存储了所有图面网页信息
    """
    return [
        {
            'id': 1,
            'name': '用户信息',
            'icon': 'bi-person',
            'url': reverse('Staff:User'),
            'info': '当前数据量：' + str(User.objects.count()),
        },
        {
            'id': 2,
            'name': '交流论坛',
            'icon': 'bi-chat-left-text',
            'url': reverse('Staff:Forum'),
            'info': '当前数据量：' + str(Article.objects.count()),
        },
        {
            'id': 3,
            'name': '知识科普',
            'icon': 'bi-book',
            'url': reverse('Staff:Knowledge'),
            'info': '当前数据量：' + str(ChartKnowledge.objects.count()),
        },
        {
            'id': 4,
            'name': '科普详情',
            'icon': 'bi-card-text',
            'url': reverse('Staff:GraphArticle'),
            'info': '当前数据量：' + str(GraphArticle.objects.count()),
        },
        {
            'id': 5,
            'name': '清理文件',
            'icon': 'bi-hdd',
            'url': reverse('Staff:File'),
            'info': '请定期删除系统缓存',
        },
        {
            'id': 6,
            'name': '图表记录',
            'icon': 'bi-brush',
            'url': reverse('Staff:ChartsRecord'),
            'info': '当前数据量：' + str(Chart.objects.count()),
        },
    ]


def Index(request):
    request.session['page'] = reverse('Staff:Index')
    user = {
        'nickname': request.session.get('nickname', ''),
        'username': request.session.get('username', ''),
        'role': request.session.get('role', 0)
    }
    print(user)
    # 非法访问，重定向到搜索页面
    if user['role'] == 0:
        print('非法访问，无管理员权限')
        return redirect(reverse('Knowledge:Search') + '?word=无管理员权限')
    context = {
        'user': user,
        'list': INDEX_LIST(),
    }
    return render(request, 'Staff_Index.html', context=context)


def UserManagement(request):
    request.session['page'] = reverse('Staff:User')
    user = {
        'nickname': request.session.get('nickname', ''),
        'username': request.session.get('username', ''),
        'role': request.session.get('role', 0)
    }
    print(user)
    # 非法访问，重定向到搜索页面
    if user['role'] == 0:
        print('非法访问，无管理员权限')
        return redirect(reverse('Knowledge:Search') + '?word=无管理员权限')

    # 设置默认notice
    notice = {
        'color': '#2c2735',
        'text': '欢迎进入用户数据管理平台',
    }

    if 'sort_options' in request.session:
        # 从session中获取排序选项，默认为升序
        sort_options = request.session.get('sort_options', {
            '1': 'a',  # 创建时间
            '2': 'a',  # 修改时间
            '3': 'a',  # 昵称
            '4': 'a',  # 账号
            '5': 'a',  # 身分组
        })
        # 从session中获取启用状态，默认为关闭
        switch_options = request.session.get('switch_options', {
            '1': 'off',  # 创建时间
            '2': 'off',  # 修改时间
            '3': 'off',  # 昵称
            '4': 'off',  # 账号
            '5': 'off',  # 身分组
        })
    else:
        sort_options = {
            '1': 'a', '2': 'a', '3': 'a', '4': 'a', '5': 'a',
        }
        switch_options = {
            '1': 'off', '2': 'off', '3': 'off', '4': 'off', '5': 'off',
        }
        # 将排序选项保存到session中
        request.session['sort_options'] = sort_options
        request.session['switch_options'] = switch_options

    if 'select_options' in request.session:
        # 从session中获取搜索条件
        select_options = request.session.get('select_options', {
            '1': '',  # 昵称
            '2': '',  # 账号
            '3': '',  # 身份组
        })
    else:
        select_options = {'1': '', '2': '', '3': ''}
        # 将搜索选项保存到session中
        request.session['select_options'] = select_options

    # 如果是POST请求，处理表单提交
    if request.method == 'POST':
        print(request.POST)
        print(request.session.items())
        if 'sortButton' in request.POST:
            # 获取用户的选择
            sort_options = {
                '1': request.POST.get('1', ['a'])[0],  # 创建时间
                '2': request.POST.get('2', ['a'])[0],  # 修改时间
                '3': request.POST.get('3', ['a'])[0],  # 昵称
                '4': request.POST.get('4', ['a'])[0],  # 账号
                '5': request.POST.get('5', ['a'])[0],  # 身分组
            }
            # 获取启用状态
            switch_options = {
                '1': request.POST.get('switch1', 'off'),  # 创建时间
                '2': request.POST.get('switch2', 'off'),  # 修改时间
                '3': request.POST.get('switch3', 'off'),  # 昵称
                '4': request.POST.get('switch4', 'off'),  # 账号
                '5': request.POST.get('switch5', 'off'),  # 身分组
            }
            # 将排序选项保存到session中
            request.session['sort_options'] = sort_options
            request.session['switch_options'] = switch_options
            # 设置notice
            notice = {
                'color': '#3c6df5',
                'text': 'SUCCESS：排序成功',
            }
        if 'selectButton' in request.POST:
            # 获取搜索条件
            select_options = {
                '1': request.POST.get('select1', '').strip(),
                '2': request.POST.get('select2', '').strip(),
                '3': request.POST.get('select3', '').strip(),
            }
            # 保存搜索条件到session
            request.session['select_options'] = select_options
            # 设置notice
            notice = {
                'color': '#3c6df5',
                'text': 'SUCCESS：搜索和筛选成功',
            }
        if 'addButton' in request.POST:
            nickname = request.POST.get('add1', '').strip()
            username = request.POST.get('add2', '').strip()
            password = request.POST.get('add3', '').strip()
            role = request.POST.get('add4', '0').strip()
            intro = request.POST.get('add5', '').strip()
            nickname_re = re.compile(r"^[\u4e00-\u9fa5a-zA-Z0-9_]{1,10}$")
            username_re = re.compile(r"^[a-zA-Z0-9_@.]{1,18}$")
            password_re = re.compile(r"^[a-zA-Z0-9_@]{6,20}$")
            if not nickname or not username or not password:
                notice = {
                    'color': '#dc3545',
                    'text': 'ERROR：缺少昵称、账号或密码',
                }
            elif not nickname_re.match(nickname):
                notice = {
                    'color': '#dc3545',
                    'text': 'ERROR：昵称格式不符',
                }
            elif not username_re.match(username):
                notice = {
                    'color': '#dc3545',
                    'text': 'ERROR：账号格式不符',
                }
            elif not password_re.match(password):
                notice = {
                    'color': '#dc3545',
                    'text': 'ERROR：密码格式不符',
                }
            else:
                hash_object = hashlib.sha256()
                hash_object.update(password.encode("utf-8"))
                sha256_password = hash_object.hexdigest()
                try:
                    User.objects.get(username=username)
                    notice = {
                        'color': '#dc3545',
                        'text': 'ERROR：账号已存在',
                    }
                except User.DoesNotExist:
                    # 创建并保存新用户
                    User.objects.create(
                        nickname=nickname,
                        username=username,
                        password=sha256_password,
                        role=role,
                        intro=intro,
                    )
                    notice = {
                        'color': '#198754',
                        'text': 'SUCCESS：新增用户成功',
                    }
        if 'updateButton' in request.POST:
            nickname = request.POST.get('update1', '').strip()
            username_index = request.POST.get('update2', '').strip()
            username = request.POST.get('update2_to_update', '').strip()
            password = request.POST.get('update3', '').strip()
            role = request.POST.get('update4', '0').strip()
            intro = request.POST.get('update5', '').strip()
            nickname_re = re.compile(r"^[\u4e00-\u9fa5a-zA-Z0-9_]{1,10}$")
            username_re = re.compile(r"^[a-zA-Z0-9_@.]{1,18}$")
            password_re = re.compile(r"^[a-zA-Z0-9_@]{6,20}$")
            if not nickname or not username_index or not username:
                notice = {
                    'color': '#dc3545',
                    'text': 'ERROR：缺少昵称或账号',
                }
            elif not nickname_re.match(nickname):
                notice = {
                    'color': '#dc3545',
                    'text': 'ERROR：昵称格式不符',
                }
            elif not username_re.match(username):
                notice = {
                    'color': '#dc3545',
                    'text': 'ERROR：账号格式不符',
                }
            elif password and not password_re.match(password):
                notice = {
                    'color': '#dc3545',
                    'text': 'ERROR：密码格式不符',
                }
            else:
                try:
                    update_user = User.objects.get(username=username_index)
                    update_user.nickname = nickname
                    update_user.username = username
                    # 修改密码
                    if password:
                        hash_object = hashlib.sha256()
                        hash_object.update(password.encode("utf-8"))
                        sha256_password = hash_object.hexdigest()
                        update_user.password = sha256_password
                    update_user.role = role
                    update_user.intro = intro
                    update_user.save()  # 保存修改
                    notice = {
                        'color': '#198754',
                        'text': 'SUCCESS：修改用户成功',
                    }
                except User.DoesNotExist:
                    notice = {
                        'color': '#dc3545',
                        'text': 'ERROR：用户不存在',
                    }
        if 'deleteButton' in request.POST:
            username = request.POST.get('delete2', '').strip()
            try:
                delete_user = User.objects.get(username=username)
                delete_user.delete()  # 删除用户
                notice = {
                    'color': '#198754',
                    'text': 'SUCCESS：删除用户成功',
                }
            except User.DoesNotExist:
                notice = {
                    'color': '#dc3545',
                    'text': 'ERROR：用户不存在',
                }

    # 构建查询条件
    query = Q()
    if select_options.get('1'):
        query &= Q(nickname__icontains=select_options.get('1'))
    if select_options.get('2'):
        query &= Q(username__icontains=select_options.get('2'))
    if select_options.get('3'):
        query &= Q(role=select_options.get('3'))

    # 查询数据
    users = User.objects.filter(query)

    # 构建排序参数
    order_by = []
    if switch_options.get('1') == 'on':
        order_by.append('created_time' if sort_options['1'] == 'a' else '-created_time')
    if switch_options.get('2') == 'on':
        order_by.append('updated_time' if sort_options['2'] == 'a' else '-updated_time')
    if switch_options.get('3') == 'on':
        order_by.append('nickname' if sort_options['3'] == 'a' else '-nickname')
    if switch_options.get('4') == 'on':
        order_by.append('username' if sort_options['4'] == 'a' else '-username')
    if switch_options.get('5') == 'on':
        order_by.append('role' if sort_options['5'] == 'a' else '-role')

    # 排序数据
    users = users.order_by(*order_by)

    # 将排序选项传递到模板
    context = {
        'user': user,
        'notice': notice,
        'data': users,
        'sort': sort_options,
        'switch': switch_options,
        'select': select_options,
    }

    return render(request, 'Staff_User.html', context=context)


def Forum(request):
    request.session['page'] = reverse('Staff:Forum')
    user = {
        'nickname': request.session.get('nickname', ''),
        'username': request.session.get('username', ''),
        'role': request.session.get('role', 0)
    }
    print(user)
    # 非法访问，重定向到搜索页面
    if user['role'] == 0:
        print('非法访问，无管理员权限')
        return redirect(reverse('Knowledge:Search') + '?word=无管理员权限')

    # 设置默认notice
    notice = {
        'color': '#2c2735',
        'text': '欢迎进入论坛管理平台',
    }

    if 'sort_options' in request.session:
        # 从session中获取排序选项，默认为升序
        sort_options = request.session.get('sort_options', {
            '1': 'a',  # 创建时间
            '2': 'a',  # 更新时间
            '3': 'a',  # 标题
        })
        # 从session中获取启用状态，默认为关闭
        switch_options = request.session.get('switch_options', {
            '1': 'off',  # 创建时间
            '2': 'off',  # 更新时间
            '3': 'off',  # 标题
        })
    else:
        sort_options = {
            '1': 'a', '2': 'a', '3': 'a',
        }
        switch_options = {
            '1': 'off', '2': 'off', '3': 'off',
        }
        # 将排序选项保存到session中
        request.session['sort_options'] = sort_options
        request.session['switch_options'] = switch_options

    if 'select_options' in request.session:
        # 从session中获取搜索条件
        select_options = request.session.get('select_options', {
            '1': '',  # 标题
            '2': '',  # 作者
            '3': '',  # 文章ID
        })
    else:
        select_options = {'1': '', '2': '', '3': ''}
        # 将搜索选项保存到session中
        request.session['select_options'] = select_options

    # 如果是POST请求，处理表单提交
    if request.method == 'POST':
        print(request.POST)
        print(request.session.items())
        if 'sortButton' in request.POST:
            # 获取用户的选择
            sort_options = {
                '1': request.POST.get('1', ['a'])[0],  # 创建时间
                '2': request.POST.get('2', ['a'])[0],  # 更新时间
                '3': request.POST.get('3', ['a'])[0],  # 标题
            }
            # 获取启用状态
            switch_options = {
                '1': request.POST.get('switch1', 'off'),  # 创建时间
                '2': request.POST.get('switch2', 'off'),  # 更新时间
                '3': request.POST.get('switch3', 'off'),  # 标题
            }
            # 将排序选项保存到session中
            request.session['sort_options'] = sort_options
            request.session['switch_options'] = switch_options
            # 设置notice
            notice = {
                'color': '#3c6df5',
                'text': 'SUCCESS：排序成功',
            }
        if 'selectButton' in request.POST:
            # 获取搜索条件
            select_options = {
                '1': request.POST.get('select1', '').strip(),
                '2': request.POST.get('select2', '').strip(),
                '3': request.POST.get('select3', '').strip(),
            }
            # 保存搜索条件到session
            request.session['select_options'] = select_options
            # 设置notice
            notice = {
                'color': '#3c6df5',
                'text': 'SUCCESS：搜索和筛选成功',
            }
        if 'addArticleButton' in request.POST:
            title = request.POST.get('addTitle', '').strip()
            content = request.POST.get('addContent', '')
            author = request.POST.get('addAuthor', '').strip()
            picture = request.FILES.get('addPicture', None)
            filename = ""
            if picture:
                # 保存图片文件到本地
                fs = FileSystemStorage(location=os.path.join(settings.MEDIA_ROOT, 'picture'))
                ext = picture.name.split('.')[-1].lower()
                if ext in ["png", "svg", "jpg", "jpeg", "webp"]:
                    last_article = Article.objects.order_by('-id').first()
                    last_article_id = last_article.id if last_article else 0
                    filename = f"{last_article_id + 1}.{ext}"
                    fs.save(filename, picture)
                    filename = 'picture/' + filename

            if not title or not content or not author:
                notice = {
                    'color': '#dc3545',
                    'text': 'ERROR：缺少标题、内容或作者',
                }
            else:
                try:
                    author_user = User.objects.get(username=author)
                    # 创建并保存新文章
                    Article.objects.create(
                        title=title,
                        content=content,
                        image=os.path.join(settings.MEDIA_URL, filename)[1:] if filename else '0',
                        author=author_user,
                    )
                    notice = {
                        'color': '#198754',
                        'text': 'SUCCESS：新增文章成功',
                    }
                except User.DoesNotExist:
                    notice = {
                        'color': '#dc3545',
                        'text': 'ERROR：作者不存在',
                    }
        if 'updateArticleButton' in request.POST:
            article_id = request.POST.get('updateArticleID', '').strip()
            title = request.POST.get('updateTitle', '').strip()
            content = request.POST.get('updateContent', '')
            author = request.POST.get('updateAuthor', '').strip()
            picture = request.FILES.get('updatePicture', None)
            switch_img = request.POST.get('switch_img', None)  # 获取复选框的值

            if not title or not content or not author:
                notice = {
                    'color': '#dc3545',
                    'text': 'ERROR：缺少标题、内容或作者',
                }
            else:
                try:
                    author_user = User.objects.get(username=author)
                    article = Article.objects.get(id=article_id)
                    article.title = title
                    article.content = content
                    article.author = author_user

                    # 检查是否需要删除原有图片
                    if switch_img:
                        # 删除原有图片文件
                        if article.image and article.image != '0':
                            fs = FileSystemStorage(location=os.path.join(settings.MEDIA_ROOT, 'picture'))
                            filename = article.image.split('/')[-1]
                            if fs.exists(filename):
                                fs.delete(filename)
                        # 将图片字段设置为默认值
                        article.image = '0'
                    else:
                        # 如果上传了新图片，更新图片字段
                        if picture:
                            fs = FileSystemStorage(location=os.path.join(settings.MEDIA_ROOT, 'picture'))
                            ext = picture.name.split('.')[-1].lower()
                            if ext in ["png", "svg", "jpg", "jpeg", "webp"]:
                                filename = f"{article_id}.{ext}"
                                # 检查文件是否已经存在
                                if fs.exists(filename):
                                    # 删除旧文件
                                    fs.delete(filename)
                                # 保存新文件
                                fs.save(filename, picture)
                                article.image = os.path.join(settings.MEDIA_URL, 'picture/', filename)[
                                                1:] if filename else '0'

                    article.save()
                    notice = {
                        'color': '#198754',
                        'text': 'SUCCESS：修改文章成功',
                    }
                except User.DoesNotExist:
                    notice = {
                        'color': '#dc3545',
                        'text': 'ERROR：作者不存在',
                    }
                except Article.DoesNotExist:
                    notice = {
                        'color': '#dc3545',
                        'text': 'ERROR：文章不存在',
                    }
        if 'deleteArticleButton' in request.POST:
            article_id = request.POST.get('deleteArticleID', '').strip()
            try:
                article = Article.objects.get(id=article_id)
                # 删除图片文件
                if article.image and article.image != '0':
                    fs = FileSystemStorage(location=os.path.join(settings.MEDIA_ROOT, 'picture'))
                    filename = article.image.split('/')[-1]
                    if fs.exists(filename):
                        fs.delete(filename)
                article.delete()  # 删除文章
                notice = {
                    'color': '#198754',
                    'text': 'SUCCESS：删除文章成功',
                }
            except Article.DoesNotExist:
                notice = {
                    'color': '#dc3545',
                    'text': 'ERROR：文章不存在',
                }

    # 构建查询条件
    query = Q()
    if select_options.get('1'):
        query &= Q(title__icontains=select_options['1'])
    if select_options.get('2'):
        query &= Q(author__username__icontains=select_options['2'])
    if select_options.get('3'):
        query &= Q(id=select_options['3'])

    # 查询数据
    articles = Article.objects.filter(query)

    # 构建排序参数
    order_by = []
    if switch_options.get('1') == 'on':
        order_by.append('created_at' if sort_options['1'] == 'a' else '-created_at')
    if switch_options.get('2') == 'on':
        order_by.append('updated_at' if sort_options['2'] == 'a' else '-updated_at')
    if switch_options.get('3') == 'on':
        order_by.append('title' if sort_options['3'] == 'a' else '-title')

    # 排序数据
    articles = articles.order_by(*order_by)

    # 将排序选项传递到模板
    context = {
        'user': user,
        'notice': notice,
        'data': articles,
        'sort': sort_options,
        'switch': switch_options,
        'select': select_options,
    }

    return render(request, 'Staff_Forum.html', context=context)


def get_recent_files(folder_path, limit):
    if not os.path.exists(folder_path) or not os.path.isdir(folder_path):
        return {'files': [], 'total': 0}

    files = os.listdir(folder_path)
    files.sort(key=lambda x: os.path.getmtime(os.path.join(folder_path, x)), reverse=True)
    recent_files = files[:limit]
    total_files = len(files)

    # 获取文件的修改时间和文件名
    file_info = []
    for file in recent_files:
        file_path = os.path.join(folder_path, file)
        mtime = os.path.getmtime(file_path)
        formatted_mtime = datetime.fromtimestamp(mtime).strftime('%Y-%m-%d %H:%M:%S')
        file_info.append({
            'name': file,
            'mtime': formatted_mtime
        })

    return {'files': file_info, 'total': total_files}


def File(request):
    request.session['page'] = reverse('Staff:File')
    user = {
        'nickname': request.session.get('nickname', ''),
        'username': request.session.get('username', ''),
        'role': request.session.get('role', 0)
    }
    print(user)
    # 非法访问，重定向到搜索页面
    if user['role'] == 0:
        print('非法访问，无管理员权限')
        return redirect(reverse('Knowledge:Search') + '?word=无管理员权限')

    # 获取文件夹路径
    charts_path = os.path.join(settings.MEDIA_ROOT, 'charts')
    picture_path = os.path.join(settings.MEDIA_ROOT, 'picture')
    upload_path = os.path.join(settings.MEDIA_ROOT, 'upload')
    reports_path = os.path.join(settings.MEDIA_ROOT, 'reports')

    # 获取文件夹内的文件列表
    charts_files = get_recent_files(charts_path, 50)
    picture_files = get_recent_files(picture_path, 50)
    upload_files = get_recent_files(upload_path, 50)
    reports_files = get_recent_files(reports_path, 50)

    context = {
        'user': user,
        'charts_files': charts_files,
        'picture_files': picture_files,
        'upload_files': upload_files,
        'reports_files': reports_files,
    }

    if request.method == 'POST':
        try:
            if 'deleteCharts' in request.POST:
                # 设置要删除的文件夹路径
                folder_path = os.path.join(settings.MEDIA_ROOT, 'charts')
            elif 'deletePicture' in request.POST:
                # 设置要删除的文件夹路径
                folder_path = os.path.join(settings.MEDIA_ROOT, 'picture')
            elif 'deleteUpload' in request.POST:
                # 设置要删除的文件夹路径
                folder_path = os.path.join(settings.MEDIA_ROOT, 'upload')
            elif 'deleteReports' in request.POST:
                # 设置要删除的文件夹路径
                folder_path = os.path.join(settings.MEDIA_ROOT, 'reports')
            else:
                folder_path = 'no_path123abc!@#$%^&*()'

            # 检查文件夹是否存在
            if os.path.exists(folder_path) and os.path.isdir(folder_path):
                # 删除文件夹内的所有内容
                for filename in os.listdir(folder_path):
                    file_path = os.path.join(folder_path, filename)

                    # 针对reports文件夹的特殊处理
                    if folder_path == reports_path:
                        # 检查文件创建时间（使用getctime，Unix系统可能返回inode修改时间）
                        try:
                            file_creation_time = os.path.getctime(file_path)
                            current_time = time.time()
                            # 只删除创建时间超过24小时的文件
                            if (current_time - file_creation_time) > 86400:
                                if os.path.isfile(file_path) or os.path.islink(file_path):
                                    os.unlink(file_path)  # 删除文件或链接
                                elif os.path.isdir(file_path):
                                    shutil.rmtree(file_path)  # 删除子文件夹
                        except Exception as e:
                            print(f"获取文件时间失败: {file_path}, 错误: {e}")
                            continue
                    else:
                        # 其他文件夹保持原有逻辑
                        if os.path.isfile(file_path) or os.path.islink(file_path):
                            os.unlink(file_path)  # 删除文件或链接
                        elif os.path.isdir(file_path):
                            shutil.rmtree(file_path)  # 删除子文件夹
                print(f"文件夹 {folder_path} 内的内容已被清空。")
            else:
                print(f"文件夹 {folder_path} 不存在。")
        except Exception as e:
            print(f"删除文件时发生错误: {e}")
        return redirect(reverse('Staff:File'))

    return render(request, 'Staff_File.html', context)


def ArticleInfoApi(request, article_id):
    # 获取文章对象，如果不存在则返回错误
    try:
        article = Article.objects.get(id=article_id)
    except Article.DoesNotExist:
        return JsonResponse({"error": "文章不存在"}, status=404)

    # 构造返回的 JSON 数据
    data = {
        "id": article.id,
        "title": article.title,
        "content": article.content,
        "author": article.author.username,
        "created_at": article.created_at.strftime("%Y-%m-%d %H:%M:%S"),
        "updated_at": article.updated_at.strftime("%Y-%m-%d %H:%M:%S"),
        "image": (f'原文章图片：{article.image}' if len(
            article.image) <= 30 else f'原文章图片：...{article.image[-30:]}') if article.image != '0' else '原文章无图片',  # 图片地址
    }

    # 返回 JSON 响应
    return JsonResponse(data)


def convert_datetime(dt):
    return dt.strftime('%Y-%m-%d %H:%M:%S')


def ChartsRecord(request):
    request.session['page'] = reverse('Staff:ChartsRecord')
    user = {
        'nickname': request.session.get('nickname', ''),
        'username': request.session.get('username', ''),
        'role': request.session.get('role', 0)
    }
    show_model = request.session.get("show_model", "only_info")

    # 非法访问检查
    if user['role'] == 0:
        return redirect(reverse('Knowledge:Search') + '?word=无管理员权限')

    if request.method == 'GET':
        # 检查是否有日期筛选参数
        search_text = request.GET.get('search', None)
        date_filter = request.GET.get('date', None)
        show_all = request.GET.get('show_all', None)  # 新增show_all参数检查

        if search_text:
            # 按搜索文本筛选记录
            sqlData = Chart.objects.filter(
                Q(chartname__icontains=search_text) |
                Q(filename__filename__icontains=search_text) |
                Q(username__username__icontains=search_text) |
                Q(time__icontains=search_text)
            ).order_by('-time')
            print(f"Notice: 按搜索文本筛选 {search_text}")
        elif date_filter and not show_all:  # 如果有日期筛选且不是显示全部
            # 按日期筛选记录
            sqlData = Chart.objects.filter(time__date=date_filter).order_by('-time')
            print(f"Notice: 按日期筛选 {date_filter}")
        else:
            # 显示全部记录
            sqlData = Chart.objects.select_related('filename', 'username').order_by('-time')
            print("Notice: 显示全部图表数据")

        if not sqlData:
            return render(request, 'Staff_ChartsRecord.html', {
                'user': user,
                'list_data': [],
                'info_data': [(-1, 0, 0, "当前数据库没有信息记录", 0, 0)],
                'show_model': show_model
            })

        # 处理数据格式
        index_day = convert_datetime(sqlData[0].time).split(" ")[0]
        info_data = [(0, 0, 0, index_day, 0, 0)]
        list_data = [index_day]

        for t in sqlData:
            this_day = convert_datetime(t.time).split(" ")[0]
            if this_day != index_day:
                list_data.append(this_day)
                info_data.append((-2, 0, 0, this_day, 0, 0))
                index_day = this_day

            # 安全获取用户名
            username = t.username.username if t.username_id else '游客'

            # 安全获取文件名
            filename = ""
            if t.filename_id:
                try:
                    filename = t.filename.filename
                except File.DoesNotExist:
                    filename = "[文件已删除]"

            # 使用 bleach 清理HTML标签并确保纯文本
            from django.utils.html import strip_tags
            info_data.append((
                t.id,
                strip_tags(str(t.chartname)) if t.chartname else "",
                strip_tags(str(filename)),  # 使用安全获取的文件名
                strip_tags(str(convert_datetime(t.time).split(" ")[1])) if t.time else "",
                strip_tags(str(username)) if username else "",
                strip_tags(str(t.chartname.split('.')[-1].upper())) if t.chartname else ""
            ))

        info_data.append((-1, 0, 0, "为提高效率，当前仅显示最近30条记录", 0, 0))

        return render(request, 'Staff_ChartsRecord.html', {
            'user': user,
            'list_data': list_data,
            'info_data': info_data,
            'show_model': show_model
        })

    elif request.method == 'POST':
        notice = 0
        try:
            if 'search_month' in request.POST:
                day_split = re.split('[年|月|日|/|\\.|\\s]+', request.POST['search_month'])
                if len(day_split) == 3:
                    day = f"{int(day_split[0]):04d}-{int(day_split[1]):02d}-{int(day_split[2]):02d}"
                    sqlData = Chart.objects.filter(time__startswith=day).order_by('-time')
                else:
                    day = f"{int(day_split[0]):04d}-{int(day_split[1]):02d}"
                    sqlData = Chart.objects.filter(time__startswith=day).order_by('-time')

            elif 'goto_day' in request.POST:
                day_split = re.split('年|月|日', request.POST['goto_day'])
                day = f"{int(day_split[0]):04d}-{int(day_split[1]):02d}-{int(day_split[2]):02d}"
                sqlData = Chart.objects.filter(time__startswith=day).order_by('-time')

            elif 'switch' in request.POST:
                show_model = 'charts' if request.POST['switch'] == 'only_info' else 'only_info'
                request.session['show_model'] = show_model
                return redirect(reverse('Staff:ChartsRecord'))

            elif 'delete_times' in request.POST:
                chart = Chart.objects.get(chartname=request.POST['delete_times'])
                file_name = chart.filename.filename if chart.filename_id else None
                chart.delete()

                if file_name and Chart.objects.filter(filename__filename=file_name).count() == 0:
                    File.objects.filter(filename=file_name).delete()

                return redirect(reverse('Staff:ChartsRecord'))

            elif 'delete_month' in request.POST:
                # 处理按月删除逻辑
                if request.POST.get('year_1') and request.POST.get('month_1'):
                    year = int(request.POST['year_1'])
                    month = int(request.POST['month_1'])
                    Chart.objects.filter(time__year=year, time__month=month).delete()
                    File.objects.filter(time__year=year, time__month=month).delete()

                return redirect(reverse('Staff:ChartsRecord'))

            else:
                sqlData = Chart.objects.order_by('-time')

        except Exception as e:
            print(f"Error: {str(e)}")
            sqlData = Chart.objects.order_by('-time')[:30]

        # 处理查询结果
        if not sqlData:
            return render(request, 'Staff_ChartsRecord.html', {
                'user': user,
                'list_data': [],
                'info_data': [(-1, 0, 0, "没有找到符合条件的记录", 0, 0)],
                'show_model': show_model
            })

        # 格式化数据
        index_day = convert_datetime(sqlData[0].time).split(" ")[0]
        info_data = [(0, 0, 0, index_day, 0, 0)]
        list_data = [index_day]

        for t in sqlData:
            this_day = convert_datetime(t.time).split(" ")[0]
            if this_day != index_day:
                list_data.append(this_day)
                info_data.append((-2, 0, 0, this_day, 0, 0))
                index_day = this_day

            # 安全获取用户名
            username = t.username.username if t.username_id else '游客'

            # 安全获取文件名
            filename = ""
            if t.filename_id:
                try:
                    filename = t.filename.filename
                except File.DoesNotExist:
                    filename = "[文件已删除]"

            info_data.append((
                t.id,
                t.chartname,
                filename,  # 使用安全获取的文件名
                convert_datetime(t.time).split(" ")[1],
                username,
                t.chartname.split('.')[-1].upper()
            ))

        info_data.append((-1, 0, 0, "查询结果展示完毕", 0, 0))

        return render(request, 'Staff_ChartsRecord.html', {
            'user': user,
            'list_data': list_data,
            'info_data': info_data,
            'show_model': show_model
        })