from django.db import models


class ChartKnowledge(models.Model):
    id = models.AutoField(primary_key=True, verbose_name='图表ID')
    name = models.CharField(max_length=50, verbose_name='图表名称')
    info = models.CharField(max_length=200, verbose_name='图表简介')
    about = models.TextField(verbose_name='详细说明')
    common_mistakes = models.JSONField(verbose_name='常见错误', default=list)
    knowledge_url = models.CharField(max_length=200, verbose_name='知识链接ID')
    chart_url = models.CharField(max_length=200, verbose_name='绘制链接ID')
    img = models.CharField(max_length=200, verbose_name='示例图路径')
    created_at = models.DateTimeField(auto_now_add=True, verbose_name="创建时间")
    updated_at = models.DateTimeField(auto_now=True, verbose_name="更新时间")


    class Meta:
        verbose_name = '图表知识库'
        verbose_name_plural = '图表知识库'

    def __str__(self):
        return self.name


class GraphArticle(models.Model):
    CHART_TYPES = [
        ('title', '标题'),
        ('text', '文本'),
        ('code', '代码'),
        ('img', '图片'),
        ('blank', '空白')
    ]
    knowledge_url = models.CharField(max_length=200, verbose_name='知识链接ID')
    content_type = models.CharField(max_length=10, choices=CHART_TYPES, verbose_name='内容类型')
    content = models.TextField(verbose_name='内容详情')
    order = models.IntegerField(verbose_name='显示顺序')
    created_at = models.DateTimeField(auto_now_add=True, verbose_name="创建时间")
    updated_at = models.DateTimeField(auto_now=True, verbose_name="更新时间")

    class Meta:
        verbose_name = '图表详情文章'
        verbose_name_plural = '图表详情文章'
        ordering = ['order']

    def __str__(self):
        return f'知识链接ID:{self.knowledge_url}-{self.get_content_type_display()}'
