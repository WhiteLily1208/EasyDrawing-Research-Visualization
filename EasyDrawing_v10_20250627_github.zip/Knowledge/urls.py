from django.urls import path
from . import views

app_name = 'Knowledge'

urlpatterns = [
    path('', views.Index, name='Index'),
    path('Search/', views.Search, name='Search'),
    path('Graph/', views.Graph, name='Graph'),
]