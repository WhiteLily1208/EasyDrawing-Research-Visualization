from django.shortcuts import render, reverse, redirect
from rapidfuzz import fuzz
from .models import GraphArticle, ChartKnowledge


def CHARTS_KNOWLEDGE_LIST():
    """
    图表知识信息列表
    :return: 内含字典的顺序列表，存储了所有图面网页信息
    """
    return [{
        "id": obj.id,
        "name": obj.name,
        "info": obj.info,
        "about": obj.about,
        "common_mistakes": obj.common_mistakes,
        'knowledge_url': obj.knowledge_url,
        'chart_url': obj.chart_url,
        "img": obj.img
    } for obj in ChartKnowledge.objects.all().order_by('id')]


def GRAPH_ARTICLE(graph_id_or_name=None):
    """
    各图表类型的文章信息列表
    :param graph_id_or_name: 可接收数字（文章ID），或文字（文章标题/图表类型），或不传参（返回全部列表）
    :return: 若不传参则返回全部列表，若传参则返回对应文章内容字典
    """
    # 从数据库获取数据
    chart_articles = GraphArticle.objects.order_by('knowledge_url', 'order')
    graph_dict_list = [{
        'id': article.id,
        'name': article.knowledge_url,
        'info': article.content,
        'article': [{
            'type': item.content_type,
            'content': item.content
        } for item in chart_articles.filter(knowledge_url=article.knowledge_url)]
    } for article in chart_articles.distinct('knowledge_url')]
    
    if graph_id_or_name is None:
        print('调用所有信息，返回全部')
        return graph_dict_list
    elif type(graph_id_or_name) == int:
        graph_id = graph_id_or_name
        method = 'id'
    elif type(graph_id_or_name) == str:
        try:
            graph_id = int(graph_id_or_name)
            method = 'id'
        except ValueError:
            graph_name = graph_id_or_name
            method = 'name'

    if method == 'id':
        # 按ID查找时遍历列表匹配
        for item in graph_dict_list:
            if item['id'] == graph_id:
                print('成功访问（id方法）')
                return item
        print('查无此文章（id方法）')
        return {'name': '查无此文章（id方法）'}
    else:  # method = 'name'
        for item in graph_dict_list:
            if item.get('name', 'no_input') == graph_name:
                print('成功访问（name方法）')
                return item
        print('查无此文章（name方法）')
        return {'name': '查无此文章（name方法）'}


# Create your views here.
def Index(request):
    request.session['page'] = reverse('Knowledge:Index')
    user = {
        'nickname': request.session.get('nickname', ''),
        'username': request.session.get('username', ''),
        'role': request.session.get('role', 0)
    }
    print(user)
    return render(request, 'Knowledge_Index.html', {'user': user, 'charts_list': CHARTS_KNOWLEDGE_LIST()})


def Graph(request):
    """
    处理知识图表页面的请求，根据ID查询文章内容并渲染页面。
    若查询不到内容块，则重定向到搜索页面。
    """
    # 获取URL中的id参数，默认为0
    graph_id = request.GET.get('id', '0')
    
    # 存储当前页面URL到会话中
    request.session['page'] = reverse('Knowledge:Graph') + f'?id={graph_id}'
    
    # 获取用户会话信息
    user = {
        'nickname': request.session.get('nickname', ''),
        'username': request.session.get('username', ''),
        'role': request.session.get('role', 0)
    }
    print(user)
    
    try:
        # 尝试将id转换为整数
        graph_id = int(graph_id)
    except ValueError:
        # ID不是整数时跳转到搜索页面
        print('ID格式错误，跳转到搜索页面')
        search_url = reverse('Knowledge:Search') + f'?word=未知的知识科普ID:{graph_id}'
        return redirect(search_url)
    
    # 查询数据库，获取knowledge_url匹配的所有文章，并按order字段排序
    graph_list = GraphArticle.objects.filter(knowledge_url=graph_id).order_by('order')
    
    # 检查是否有查询结果
    if not graph_list.exists():
        print(f'未找到knowledge_url为{graph_id}的文章')
        # 没有找到内容块，跳转到搜索页面
        search_url = reverse('Knowledge:Search') + f'?word=未知的知识科普ID:{graph_id}'
        return redirect(search_url)
    
    # 准备传递给模板的数据
    context = {
        'user': user,
        'graph':{
            'name': ChartKnowledge.objects.get(knowledge_url=graph_id).name,
            'info': ChartKnowledge.objects.get(knowledge_url=graph_id).info,
            'article': [{'type': item.content_type, 'content': item.content} for item in graph_list]
        },
    }
    return render(request, 'Knowledge_Graph.html', context)

def Search(request):
    request.session['page'] = reverse('Knowledge:Search')
    if request.method == 'GET':
        word = request.GET.get('word', '')
        print('搜索(GET)： ', word)
    else:
        word = request.POST.get('search', '')
        print('搜索(POST)：', word)
    user = {
        'nickname': request.session.get('nickname', ''),
        'username': request.session.get('username', ''),
        'role': request.session.get('role', 0)
    }

    def __fuzzy_match(word, data_dict, threshold=60):  # 模糊匹配 threshold: 相似度阈值（0 到 100 之间）
        result = []
        for key in data_dict:
            similarity = fuzz.ratio(word, key)  # 计算字符串相似度
            if similarity >= threshold:
                result.append((key, data_dict[key], similarity))  # 将相似度分数也加入结果中
        # 按相似度从低到高排序
        result.sort(key=lambda x: x[2], reverse=True)
        # 返回结果时去掉相似度分数
        # return [(key, value) for key, value, similarity in result]
        return [(key, value, f'{similarity:.1f}%') for key, value, similarity in result]
        # return result

    data_dict = {
        "直方图（科普）": reverse('Knowledge:Graph') + '?id=' + str(1),
        "密度图（科普）": reverse('Knowledge:Graph') + '?id=' + str(2),
        "散点图（科普）": reverse('Knowledge:Graph') + '?id=' + str(3),
        "混淆矩阵（科普）": reverse('Knowledge:Graph') + '?id=' + str(4),
        "直方图（绘制）": reverse('Chart:Workbench') + '?id=' + str(1),
        "密度图（绘制）": reverse('Chart:Workbench') + '?id=' + str(2),
        "散点图（绘制）": reverse('Chart:Workbench') + '?id=' + str(3),
        "混淆矩阵（绘制）": reverse('Chart:Workbench') + '?id=' + str(4),
        "知识科普": reverse('Knowledge:Index'),
        "绘制图表": reverse('Chart:Index'),
        "创意工坊": reverse('CreativeWorkshop:Index'),
        "快速AI数据分析": reverse('CreativeWorkshop:Workbench') + '?id=' + '1',
        "数据分析文档生成": reverse('CreativeWorkshop:Workbench') + '?id=' + '2',
        "交流论坛": reverse('Forum:Index'),
        "搜索": reverse('Knowledge:Search'),
        "登录": reverse('User:login'),
        "退出登录": reverse('User:logout'),
        "注册": reverse('User:signup'),
        "隐私政策": reverse('User:PrivacyPolicy'),
        "免责声明": reverse('User:SponsorshipClause'),
        "赞助我们": reverse('User:SponsorUs'),
        "联系我们": reverse('Knowledge:Search') + '?word=' + '邮箱：faner08@qq.com',
        "用户反馈": reverse('Knowledge:Search') + '?word=' + '邮箱：faner08@qq.com',
        "管理平台": reverse('Staff:Index'),
        "管理员登录": reverse('User:login'),
    }
    matched_result = __fuzzy_match(word, data_dict, threshold=10)
    print("匹配到的结果：", matched_result)

    return render(request, 'Knowledge_Search.html', {'user': user, 'word': word, 'data': matched_result})
