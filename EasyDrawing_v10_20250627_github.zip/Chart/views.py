import json
import matplotlib.pyplot as plt
import matplotlib.colors as mcolors
import seaborn as sns
import pandas as pd
import numpy as np

import os
import time
from .models import Chart, File
from User.models import User
from Knowledge.models import ChartKnowledge
from django.shortcuts import render, reverse, redirect

import sys
import io
import traceback
import matplotlib
import scipy
import plotly

from pathlib import Path
from openai import OpenAI, RateLimitError
import re


def CHARTS_PAGE_LIST():
    """
    网页信息列表
    :return: 内含字典的顺序列表，存储了所有图面网页信息
    """

    return [{
        "id": obj.id,
        "name": obj.name,
        "info": obj.info,
        'knowledge_url': obj.knowledge_url,
        'chart_url': obj.chart_url,
        "img": obj.img
    } for obj in ChartKnowledge.objects.all().order_by('id')]


def truncate_file(input_file, output_file, nrows=None, ncols=None, file_type='csv'):
    """
    截取文件内容并保存到新文件中。

    参数:
        input_file: 输入文件路径（CSV或Excel文件）
        output_file: 输出文件路径（CSV或Excel文件）
        nrows: 截取的行数（默认为None，表示不截取行）
        ncols: 截取的列数（默认为None，表示不截取列）
        file_type: 文件类型（'csv'或'excel'）
    """
    # 读取文件
    if file_type == 'csv':
        df = pd.read_csv(input_file)
    elif file_type == 'excel':
        df = pd.read_excel(input_file)
    else:
        raise ValueError("不支持的文件类型，使用csv或excel。")

    # 获取文件的行数和列数
    original_nrows, original_ncols = df.shape

    # 判断是否需要截取行
    if nrows is not None:
        if original_nrows < nrows:
            print(f"文件的行数 {original_nrows} 少于指定的 {nrows}，不进行行截取。")
        else:
            df = df.head(nrows)  # 截取前n行

    # 判断是否需要截取列
    if ncols is not None:
        if original_ncols < ncols:
            print(f"文件的列数 {original_ncols} 少于指定的 {ncols}，不进行列截取。")
        else:
            df = df.iloc[:, :ncols]  # 截取前n列

    # 保存到新文件
    if file_type == 'csv':
        df.to_csv(output_file, index=False)
    elif file_type == 'excel':
        df.to_excel(output_file, index=False)

    print(f"文件已处理并保存到 {output_file}")


def kimi_write(code: str, query: str):
    client = OpenAI(
        api_key="请替换为您的API_KEY",  # 从 Kimi 开放平台申请的 API Key
        base_url="https://api.moonshot.cn/v1",
    )

    max_retries = 10  # 最大重试次数
    wait_i = 0  # 指数级等待时间参数 i

    for attempt in range(max_retries):
        try:
            completion = client.chat.completions.create(
                model="moonshot-v1-8k",
                messages=[
                    {
                        "role": "system",
                        "content": "你是Kimi。你的回复简洁、专业、高效，并严格遵守用户需求。"
                    },
                    {
                        "role": "user",
                        "content": (
                                '这段Python代码绘制图表：\n' + code +
                                '\n在此基础上修改并优化代码，必要时可以重写。'
                                '我已经为你引入了"import matplotlib.pyplot as plt、import seaborn as sns、import pandas as pd、import numpy as np"，不要使用其他任何import语句。'
                                '不要修改代码中读取文件内容的部分，除非没有。'
                                '重要的是，不要说其他任何话，直接给我代码！'
                                '解决中文字体显示问题，设置图表的分辨率为300，下面是详细的修改需求：' + query
                        )
                    }
                ],
                temperature=0.3,
            )

            answer = completion.choices[0].message.content
            print('----------------------kimi_update_code----------------------\n' + answer)

            # 提取代码
            answer = answer.split('```python\n', 1)[1].split('\n```', 1)[0]
            if 'import numpy as np\n\n' in answer:
                answer = answer.split('import numpy as np\n\n', 1)[1]
            elif 'import numpy as np\n' in answer:
                answer = answer.split('import numpy as np\n', 1)[1]
            if 'file_url = \"' in answer:
                answer = answer.split('file_url = \"', 1)[0] + answer.split('file_url = \"', 1)[1].split('\"\n', 1)[1]
            elif 'file_url = \'' in answer:
                answer = answer.split('file_url = \'', 1)[0] + answer.split('file_url = \'', 1)[1].split('\'\n', 1)[1]
            return answer
        except Exception as e:
            print(f"调用KimiAI接口失败（尝试 {attempt + 1}/{max_retries}）：{e}")
            if attempt < max_retries - 1:  # 如果不是最后一次尝试
                retry_delay = 2 ** wait_i
                wait_i += 1
                print(f"等待 {retry_delay} 秒后重试...")
                time.sleep(retry_delay)
            else:
                print("达到最大重试次数，调用KimiAI接口失败。")
                return "达到最大重试次数，调用KimiAI接口失败。"


def kimi_code(input_path: str, query: str):
    """
    调用KimiAI接口，读取数据文件，按需实现生成Python代码，绘制图表。
    :param input_path: 数据文件路径
    :param query: 需求
    :return: str, 生成的代码
    """
    # 检查文件是否存在
    if not os.path.exists(input_path):
        raise FileNotFoundError(f"指定的文件路径不存在：{input_path}")

    # 初始化OpenAI客户端
    client = OpenAI(
        api_key="请替换为您的API_KEY",  # 替换为你的Kimi开放平台API Key
        base_url="https://api.moonshot.cn/v1"  # Kimi开放平台的API地址
    )

    max_retries = 10  # 最大重试次数
    wait_i = 0  # 指数级等待时间参数 i

    # 在第一次尝试之前截取文件
    directory, filename = os.path.split(input_path)
    name, extension = os.path.splitext(filename)
    new_filename = f"{name}_truncated{extension}"
    new_path = os.path.join(directory, new_filename)
    truncate_file(input_path, new_path, nrows=200, ncols=None, file_type='csv')

    file_object = client.files.create(file=Path(new_path), purpose="file-extract")
    file_content = client.files.content(file_id=file_object.id).text

    for attempt in range(max_retries):
        try:
            # 构造消息内容
            messages = [
                {
                    "role": "system",
                    "content": "你是Kimi。你的回复简洁、专业、高效，并严格遵守用户需求。"
                },
                {
                    "role": "system",
                    "content": file_content  # 将文件内容作为系统提示词的一部分
                },
                {
                    "role": "user",
                    "content": (
                            '查看文件中给出的数据，编写Python代码绘制图表，我已经为你引入了"import matplotlib.pyplot as plt、'
                            'import seaborn as sns、import pandas as pd、import numpy as np"，不要使用其他任何import语句。'
                            '你需要先读取文件内容，我已经把文件路径存入"file_url=\'media/upload/xxx.xxx\'"字符串变量，'
                            '直接使用"file_url"而不要再次定义。重要的是，不要说其他任何话，直接给我代码！'
                            '解决中文字体显示问题，设置图表的分辨率为300，下面是详细的图表需求：' + query
                    )
                }
            ]

            # 调用chat-completion接口获取Kimi的回答
            completion = client.chat.completions.create(
                model="moonshot-v1-8k",
                messages=messages,
                temperature=0.3
            )
            answer = completion.choices[0].message.content
            print('----------------------kimi_answer----------------------\n' + answer)

            # 提取代码
            answer = answer.split('```python\n', 1)[1].split('\n```', 1)[0]
            if 'import numpy as np\n\n' in answer:
                answer = answer.split('import numpy as np\n\n', 1)[1]
            elif 'import numpy as np\n' in answer:
                answer = answer.split('import numpy as np\n', 1)[1]
            if 'file_url = \"' in answer:
                answer = answer.split('file_url = \"', 1)[0] + answer.split('file_url = \"', 1)[1].split('\"\n', 1)[1]
            elif 'file_url = \'' in answer:
                answer = answer.split('file_url = \'', 1)[0] + answer.split('file_url = \'', 1)[1].split('\'\n', 1)[1]
            return answer
        except Exception as e:
            print(f"调用KimiAI接口失败（尝试 {attempt + 1}/{max_retries}）：{e}")
            if attempt < max_retries - 1:  # 如果不是最后一次尝试
                retry_delay = 2 ** wait_i
                wait_i += 1
                print(f"等待 {retry_delay} 秒后重试...")
                time.sleep(retry_delay)
            else:
                print("达到最大重试次数，调用KimiAI接口失败。")
                return "达到最大重试次数，调用KimiAI接口失败。"


def kimi_update(code: str, input_path: str, query: str):
    """
    调用KimiAI接口，读取数据文件，按需实现修改Python代码。
    :param code: 待修改的代码
    :param input_path: 数据文件路径
    :param query: 需求
    :return: str, 修改好的代码
    """
    # 检查文件是否存在
    if not os.path.exists(input_path):
        raise FileNotFoundError(f"指定的文件路径不存在：{input_path}")

    # 初始化OpenAI客户端
    client = OpenAI(
        api_key="请替换为您的API_KEY",  # 替换为你的Kimi开放平台API Key
        base_url="https://api.moonshot.cn/v1"  # Kimi开放平台的API地址
    )

    max_retries = 10  # 最大重试次数
    wait_i = 0  # 指数级等待时间参数 i

    # 在第一次尝试之前截取文件
    directory, filename = os.path.split(input_path)
    name, extension = os.path.splitext(filename)
    new_filename = f"{name}_truncated{extension}"
    new_path = os.path.join(directory, new_filename)
    truncate_file(input_path, new_path, nrows=200, ncols=None, file_type='csv')

    # 上传截取后的文件并获取文件内容
    file_object = client.files.create(file=Path(new_path), purpose="file-extract")
    file_content = client.files.content(file_id=file_object.id).text

    for attempt in range(max_retries):
        try:
            # 构造消息内容
            messages = [
                {
                    "role": "system",
                    "content": "你是Kimi。你的回复简洁、专业、高效，并严格遵守用户需求。"
                },
                {
                    "role": "system",
                    "content": file_content  # 将文件内容作为系统提示词的一部分
                },
                {
                    "role": "user",
                    "content": (
                            '查看文件中给出的数据，这段Python代码绘制图表：\n' + code +
                            '\n在此基础上修改并优化代码，必要时可以重写。'
                            '我已经为你引入了"import matplotlib.pyplot as plt、import seaborn as sns、import pandas as pd、import numpy as np"，不要使用其他任何import语句。'
                            '你需要先读取文件内容，我已经把文件路径存入"file_url=\'media/upload/xxx.xxx\'"字符串变量，'
                            '直接使用"file_url"而不要再次定义。重要的是，不要说其他任何话，直接给我代码！'
                            '解决中文字体显示问题，设置图表的分辨率为300，下面是详细的修改需求：' + query
                    )
                }
            ]
            # 调用chat-completion接口获取Kimi的回答
            completion = client.chat.completions.create(
                model="moonshot-v1-8k",
                messages=messages,
                temperature=0.3
            )
            answer = completion.choices[0].message.content
            print('----------------------kimi_update_code----------------------\n' + answer)

            # 提取代码
            answer = answer.split('```python\n', 1)[1].split('\n```', 1)[0]
            if 'import numpy as np\n\n' in answer:
                answer = answer.split('import numpy as np\n\n', 1)[1]
            elif 'import numpy as np\n' in answer:
                answer = answer.split('import numpy as np\n', 1)[1]
            if 'file_url = \"' in answer:
                answer = answer.split('file_url = \"', 1)[0] + answer.split('file_url = \"', 1)[1].split('\"\n', 1)[1]
            elif 'file_url = \'' in answer:
                answer = answer.split('file_url = \'', 1)[0] + answer.split('file_url = \'', 1)[1].split('\'\n', 1)[1]
            return answer
        except Exception as e:
            print(f"调用KimiAI接口失败（尝试 {attempt + 1}/{max_retries}）：{e}")
            if attempt < max_retries - 1:  # 如果不是最后一次尝试
                retry_delay = 2 ** wait_i
                wait_i += 1
                print(f"等待 {retry_delay} 秒后重试...")
                time.sleep(retry_delay)
            else:
                print("达到最大重试次数，调用KimiAI接口失败。")
                return "达到最大重试次数，调用KimiAI接口失败。"


def run_code(code_str: str, file_name='', ext='png', output_dir='\\media\\charts\\'):
    """
    执行绘图代码并返回结果（保存的图表路径、输出值或报错）
    :param file_name: 数据的文件名（含后缀）
    :param ext: 图表的文件类型
    :param output_dir: 文件的保存路径
    :param code_str: Python代码字符串
    :return: "output": str,程序输出内容
            "images": list,生成的图片路径列表
            "error": str or None
    """
    code_str = rf'file_url = r"{os.path.join('media\\upload\\', file_name)}"'+ '\n' + code_str  # 合并file_name
    matplotlib.use('Agg')  # 禁用GUI交互模式
    matplotlib.pyplot.style.use('default')  # 恢复默认样式
    matplotlib.pyplot.rcParams.update(matplotlib.pyplot.rcParamsDefault)  # 重置 rcParams 为默认值
    # 重定向标准输出
    old_stdout = sys.stdout
    redirected_output = sys.stdout = io.StringIO()
    # 初始化结果容器
    result = {"output": "", "images": [], "error": None}
    try:
        # 动态创建全局命名空间
        global_namespace = {
            "__builtins__": __builtins__,
            "plt": None,  # 预定义关键对象
            "sns": None,
            "pd": None,
            "np": None,
            "gaussian_kde": None,
            "plotly": None,
            "sklearn": None,
        }
        # 执行用户代码（隔离环境）
        exec(
            "import matplotlib.pyplot as plt\n"
            "import seaborn as sns\n"
            "import pandas as pd\n"
            "import numpy as np\n"
            "from scipy.stats import gaussian_kde\n"
            "import plotly.graph_objects as go\n"
            "from plotly.subplots import make_subplots\n"
            "import plotly.express as px\n"
            "from sklearn.metrics import confusion_matrix\n"
            + code_str, global_namespace)
        # 自动保存未关闭的图形
        import matplotlib.pyplot as plt
        plt.figure(dpi=300)  # 设置图表分辨率
        while len(plt.get_fignums()) > 0:
            fig = plt.figure(plt.get_fignums()[0])
            os.makedirs(output_dir, exist_ok=True)
            chart_name = f"{file_name.split('.')[0]}_{len(result['images'])}.{ext}"
            save_path = os.path.join(output_dir[1:], chart_name)
            fig.savefig(save_path)
            result["images"].append('\\' + save_path)
            plt.close(fig)

            try:
                if chart_name.split('.')[0].endswith('_1'):
                    print(f"系统判断名为“{chart_name}”的图片无效，删除且不予记录。")
                    if os.path.exists(save_path):
                        os.remove(save_path)
                        print(f"文件 '{chart_name}' 已成功删除。")
                    else:
                        print(f"文件 '{chart_name}' 不存在，无法删除。")
                else:
                    file_obj = File.objects.filter(filename=file_name).first()
                    if file_obj is None:
                        print(f"保存至数据库记录时，名为“{file_name}”的数据文件不存在。")
                    elif not Chart.objects.filter(chartname=chart_name).exists():
                        chart_db = Chart(
                            chartname=chart_name,
                            filename=file_obj,
                            username=file_obj.username if file_obj.username else None,
                        )
                        chart_db.save()
                    else:
                        print(f"保存至数据库记录时，名为“{chart_name}”的图片记录已存在。")
            except Exception as e:
                print(f"保存至数据库记录时发生错误: {e}")

        # 捕获文本输出
        result["output"] = redirected_output.getvalue()
    except Exception as e:
        result["error"] = traceback.format_exc(limit=10)
    finally:
        sys.stdout = old_stdout

    print("result[\"images\"]: ", result["images"])
    print("result[\"output\"]: ", result["output"])
    print("result[\"errors\"]: ", result["error"])
    return result


# Create your views here.
def Workbench(request):
    workbench_id = request.GET.get('id', '404 Not Found')
    request.session['page'] = reverse('Chart:Workbench') + '?id=' + workbench_id
    user = {
        'nickname': request.session.get('nickname', ''),
        'username': request.session.get('username', ''),
        'role': request.session.get('role', 0)
    }

    # 若访问不存在的图表类型，重定向到搜索页面
    try:
        workbench_id = int(workbench_id)
    except:
        print('访问不存在的图表类型')
        return redirect(reverse('Knowledge:Search') + '?word=未知的工作台ID:' + str(workbench_id))
    if workbench_id > len(CHARTS_PAGE_LIST()) or workbench_id <= 0:
        print('访问不存在的图表类型')
        return redirect(reverse('Knowledge:Search') + '?word=未知的工作台ID:' + str(workbench_id))

    # 处理文件上传
    if 'upload_btn' in request.POST:
        request.session['history_query'] = 'no_history_query'  # 重置历史记录
        if not 'file' in request.FILES:
            print('文件上传为空')
            file_name = 'no_file'
        else:
            file = request.FILES['file']
            ext = file.name.split('.')[-1].lower()
            if ext in ["csv", "xlsx"]:
                file_name = time.strftime('%Y%m%d%H%M%S', time.localtime()) + user.get(
                    'username') + str(workbench_id) + file.name
                with open(os.path.join('media/upload/', file_name), 'wb+') as destination:
                    for chunk in file.chunks():
                        destination.write(chunk)
                print('上传文件：', file.name + '（保存为' + file_name + '）')
                request.session['data_file'] = file_name
                # 创建一个File实例
                if user['username'] == '':
                    file_db = File(
                        filename=file_name,
                        original_name=file.name,
                    )
                else:
                    file_db = File(
                        filename=file_name,
                        original_name=file.name,
                        username=User.objects.get(username=user['username']),
                    )
                # 保存到数据库
                file_db.save()
            else:
                print('上传文件：', file.name + '（文件格式不符）')
                file_name = 'no_file'
    else:
        file_name = request.session.get('data_file', 'no_file')

    # 默认信息模板
    code_first = "import matplotlib.pyplot as plt\nimport seaborn as sns\nimport pandas as pd\nimport numpy as np\nfrom scipy.stats import gaussian_kde\nfrom sklearn.metrics import confusion_matrix\n\n# 载入文件路径\nfile_url = 'media/upload/xxx.xxx(运行代码时自动替换)'\n\n# 在此(下一行)开始编写代码\n"

    info = {
        'title': CHARTS_PAGE_LIST()[int(workbench_id) - 1].get('name', '通用图表类型'),
        'type': 'example',  # example handbook .ext traceback file_error output_only
        'mode': 'simple',  # simple code ai
        'btn': 0,  # 1 0
        'chart_url': rf'/static/img/rule_{workbench_id}.png',  # 默认思路
        'traceback': '',
        'output': '',
    }
    settings = {
        'style': [
            {'type': 'select', 'name': '颜色主题', 'id': 'colorTheme',
             'items': ['江南水乡', '秋日暖阳', '清凉薄荷', '绿野仙踪', '青花瓷韵', '暮光之城', '冷峻冰川']},
            {'type': 'color_check', 'name': '单色主题', 'id': 'AColor', 'value': 0, 'text': '启用单色主题 '},
            {'type': 'number_check', 'name': '箱体个数', 'id': 'boxCount', 'value': 1, 'text': '启用 AUTO 自动计算 '},
            {'type': 'number', 'name': '标题字体大小', 'id': 'titleFontSize'},
            {'type': 'check', 'name': '图例', 'id': 'legend', 'value': 0},
        ],
        'text': [
            {'name': '图表标题', 'id': 'chartTitle'},
        ],
        'code_text': code_first,
        'ai_text': '',
        'history_query': request.session.get('history_query', 'no_history_query'),
    }

    # 默认为GET和POST类型修改返回字典
    if int(workbench_id) == 1:  # 直方图
        # 修改返回字典
        settings['style'] = [
            {'type': 'select', 'name': '字体', 'id': 'fontFamily',
             'items': ['宋体', '仿宋', '楷体', '细黑', '微软雅黑']},
            {'type': 'select', 'name': '颜色主题', 'id': 'colorTheme',
             'items': ['江南水乡', '秋日暖阳', '清凉薄荷', '绿野仙踪', '青花瓷韵', '暮光之城', '冷峻冰川']},
            {'type': 'color_check', 'name': '单色主题', 'id': 'AColor', 'value': 0, 'text': '启用单色主题'},
            {'type': 'number_check', 'name': '箱体个数', 'id': 'boxCount', 'value': 1,
             'text': '启用 AUTO 自动计算 '},
            {'type': 'number', 'name': '标题字体大小', 'id': 'titleFontSize', 'value': 16},
            {'type': 'number', 'name': 'XY 轴标签字体大小', 'id': 'xyLabelFontSize', 'value': 14},
            {'type': 'number', 'name': 'X 轴刻度字体大小', 'id': 'xScaleFontSize', 'value': 12},
            {'type': 'number', 'name': 'Y 轴刻度字体大小', 'id': 'yScaleFontSize', 'value': 12},
            {'type': 'number', 'name': '顶部轴线宽度', 'id': 'topAxisLineWidth', 'value': 0},
            {'type': 'number', 'name': '底部轴线宽度', 'id': 'bottomAxisLineWidth', 'value': 1},
            {'type': 'number', 'name': '左侧轴线宽度', 'id': 'leftAxisLineWidth', 'value': 1},
            {'type': 'number', 'name': '右侧轴线宽度', 'id': 'rightAxisLineWidth', 'value': 0},
            {'type': 'check', 'name': '图例', 'id': 'legend', 'value': 0},
            {'type': 'check', 'name': '中位数线', 'id': 'medianLine', 'value': 0},
            {'type': 'check', 'name': '正态分布曲线', 'id': 'gaussianCurve', 'value': 0},
            {'type': 'select_check', 'name': '图表格式', 'id': 'imageFormat',
             'items': ['PNG', 'SVG', 'PDF', 'JPG'], 'value': 1, 'text': '启用快速绘图'},
        ]
        settings['text'] = [
            {'name': '图表标题', 'id': 'chartTitle'},
            {'name': 'X 轴标签', 'id': 'xAxisLabel'},
            {'name': 'Y 轴标签', 'id': 'yAxisLabel'},
        ]
    elif int(workbench_id) == 2:  # 密度图
        settings['style'] = [
            {'type': 'select', 'name': '字体', 'id': 'fontFamily',
             'items': ['宋体', '仿宋', '楷体', '细黑', '微软雅黑']},
            {'type': 'color', 'name': '选择颜色', 'id': 'AColor'},
            {'type': 'color', 'name': '边框颜色', 'id': 'edgeColor'},
            {'type': 'number', 'name': '标题字体大小', 'id': 'titleFontSize', 'value': 16},
            {'type': 'number', 'name': 'XY 轴标签字体大小', 'id': 'xyLabelFontSize', 'value': 14},
            {'type': 'number', 'name': 'X 轴刻度字体大小', 'id': 'xScaleFontSize', 'value': 12},
            {'type': 'number', 'name': 'Y 轴刻度字体大小', 'id': 'yScaleFontSize', 'value': 12},
            {'type': 'number', 'name': '顶部轴线宽度', 'id': 'topAxisLineWidth', 'value': 0},
            {'type': 'number', 'name': '底部轴线宽度', 'id': 'bottomAxisLineWidth', 'value': 1},
            {'type': 'number', 'name': '左侧轴线宽度', 'id': 'leftAxisLineWidth', 'value': 1},
            {'type': 'number', 'name': '右侧轴线宽度', 'id': 'rightAxisLineWidth', 'value': 0},
            {'type': 'check', 'name': '图例', 'id': 'legend', 'value': 0},
            {'type': 'check', 'name': '中位数线', 'id': 'medianLine', 'value': 0},
            {'type': 'select_check', 'name': '图表格式', 'id': 'imageFormat',
             'items': ['PNG', 'SVG', 'PDF', 'JPG'], 'value': 1, 'text': '启用快速绘图'},
        ]

        settings['text'] = [
            {'name': '图表标题', 'id': 'chartTitle'},
            {'name': 'X 轴标签', 'id': 'xAxisLabel'},
            {'name': 'Y 轴标签', 'id': 'yAxisLabel'},
        ]
    elif int(workbench_id) == 3:  # 散点图
        settings['style'] = [
            {'type': 'select', 'name': '字体', 'id': 'fontFamily',
             'items': ['宋体', '仿宋', '楷体', '细黑', '微软雅黑']},
            {'type': 'color', 'name': '选择颜色', 'id': 'AColor'},
            {'type': 'number', 'name': '标题字体大小', 'id': 'titleFontSize', 'value': 16},
            {'type': 'number', 'name': 'XY 轴标签字体大小', 'id': 'xyLabelFontSize', 'value': 14},
            {'type': 'number', 'name': 'X 轴刻度字体大小', 'id': 'xScaleFontSize', 'value': 12},
            {'type': 'number', 'name': 'Y 轴刻度字体大小', 'id': 'yScaleFontSize', 'value': 12},
            {'type': 'number', 'name': '顶部轴线宽度', 'id': 'topAxisLineWidth', 'value': 0},
            {'type': 'number', 'name': '底部轴线宽度', 'id': 'bottomAxisLineWidth', 'value': 1},
            {'type': 'number', 'name': '左侧轴线宽度', 'id': 'leftAxisLineWidth', 'value': 1},
            {'type': 'number', 'name': '右侧轴线宽度', 'id': 'rightAxisLineWidth', 'value': 0},
            {'type': 'check', 'name': '图例', 'id': 'legend', 'value': 0},
            {'type': 'check', 'name': '中位数线', 'id': 'medianLine', 'value': 0},
            {'type': 'select_check', 'name': '图表格式', 'id': 'imageFormat',
             'items': ['PNG', 'SVG', 'PDF', 'JPG'], 'value': 1, 'text': '启用快速绘图'},
        ]

        settings['text'] = [
            {'name': '图表标题', 'id': 'chartTitle'},
            {'name': 'X 轴标签', 'id': 'xAxisLabel'},
            {'name': 'Y 轴标签', 'id': 'yAxisLabel'},
        ]
    elif int(workbench_id) == 4:  # 混淆矩阵
        settings['style'] = [
            {'type': 'select', 'name': '字体', 'id': 'fontFamily',
             'items': ['宋体', '仿宋', '楷体', '细黑', '微软雅黑']},
            {'type': 'select', 'name': '颜色主题', 'id': 'colorTheme',
             'items': ['Blues渐变蓝', 'Reds渐变红', 'Greens渐变绿', 'Greys渐变灰', 'rainbow彩虹', 'hot热图渐变',
                       'winter冬季渐变',
                       'summer夏季渐变', 'viridis黄紫', 'plasma黄红', 'cividis蓝黄', 'coolwarm蓝白红', 'RdYlGn红黄绿',
                       'RdYlBu红黄蓝']},
            {'type': 'check', 'name': '显示数值', 'id': 'showNumber', 'value': 1},
            {'type': 'text', 'name': 'XY 轴刻度列表', 'id': 'ScaleList', 'value': "['类型1', '类型2', '类型3']"},
            {'type': 'number', 'name': '标题字体大小', 'id': 'titleFontSize', 'value': 16},
            {'type': 'number', 'name': 'XY 轴标签字体大小', 'id': 'xyLabelFontSize', 'value': 14},
            {'type': 'number', 'name': 'X 轴刻度字体大小', 'id': 'xScaleFontSize', 'value': 12},
            {'type': 'number', 'name': 'Y 轴刻度字体大小', 'id': 'yScaleFontSize', 'value': 12},
            {'type': 'check', 'name': '图例', 'id': 'legend', 'value': 0},
            {'type': 'check', 'name': '中位数线', 'id': 'medianLine', 'value': 0},
            {'type': 'select_check', 'name': '图表格式', 'id': 'imageFormat',
             'items': ['PNG', 'SVG', 'PDF', 'JPG'], 'value': 1, 'text': '启用快速绘图'},
        ]

        settings['text'] = [
            {'name': '图表标题', 'id': 'chartTitle'},
            {'name': 'X 轴标签', 'id': 'xAxisLabel', 'value': '预测值'},
            {'name': 'Y 轴标签', 'id': 'yAxisLabel', 'value': '真实值'},
        ]

    # 开始处理POST请求
    if request.method == "POST":
        if 'code_mode' in request.POST:
            if not request.session.get('history_query'):
                request.session['history_query'] = 'no_history_query'  # 重置历史记录
            print('python模式：运行代码')
            ext = request.POST.get('imageFormat', 'PNG').lower()
            # 默认获取code_text
            code_text = request.POST.get('code', 'no_input')
            settings['code_text'] = code_text
            if "# 在此(下一行)开始编写代码" in code_text:
                code_text = code_text.split("# 在此(下一行)开始编写代码", 1)[1]
            execution_result = run_code(code_text, file_name, ext)
            if execution_result["error"]:
                print('python模式：报错（Traceback）')
                re_traceback = execution_result['error']
                re_traceback = re_traceback.split('File ', 1)[0] + 'File "<string>"' + \
                               re_traceback.split('File "<string>"', 1)[1]
                # 修改返回字典
                info['type'] = 'traceback'  # example handbook .ext traceback file_error output_only
                info['mode'] = 'code'  # simple code ai
                info['btn'] = 1  # 1 0
                info['traceback'] = re_traceback
                if execution_result["output"]:
                    print('python模式：有打印')
                    # 修改返回字典
                    info['output'] = execution_result["output"]
            elif not execution_result['images']:
                if execution_result["output"]:
                    print('python模式：有打印')
                    # 修改返回字典
                    info['output'] = execution_result["output"]
                    info['type'] = 'output_only'  # example handbook .ext traceback file_error output_only
                else:
                    print('python模式：空运行')
                    # 修改返回字典
                    info['type'] = 'traceback'  # example handbook .ext traceback file_error output_only
                info['mode'] = 'code'  # simple code ai
                info['btn'] = 1  # 1 0
                info['traceback'] = '未知错误，你的代码运行了什么？'
            else:
                request.session['chart_file'] = execution_result['images'][0]
                print('python模式：执行成功')
                # 修改返回字典
                info['type'] = execution_result['images'][0].split('.')[-1].lower()
                # example handbook .ext traceback file_error output_only
                info['mode'] = 'code'  # simple code ai
                info['btn'] = 1  # 1 0
                info['chart_url'] = execution_result['images'][0]
                if execution_result["output"]:
                    print('python模式：有打印')
                    # 修改返回字典
                    info['output'] = execution_result["output"]

        elif 'ai_update' in request.POST:
            print('python模式：使用AI修改代码')
            ai_update = request.POST.get('ai_update', '自行发挥')
            # 修改返回字典
            info['type'] = 'handbook'  # example handbook .ext traceback file_error output_only
            info['mode'] = 'code'  # simple code ai
            info['btn'] = 1  # 1 0
            # 历史记录存入session
            if request.session['history_query'] == 'no_history_query':
                history_query = [ai_update, ]
                request.session['history_query'] = history_query
                settings['history_query'] = history_query
            else:  # request.session['history_query'] != 'no_history_query':
                history_query = request.session['history_query']  # 定义历史记录列表
                history_query.append(ai_update)  # 更新历史记录列表
                request.session['history_query'] = history_query
                settings['history_query'] = history_query
            code_text = request.POST.get('code', 'no_input')
            if "# 在此(下一行)开始编写代码" in code_text:
                code_text = code_text.split("# 在此(下一行)开始编写代码", 1)[1]
            if file_name == 'no_file':  # 处理未上传文件但直接运行，然后使用AI修改
                settings['code_text'] = code_first + kimi_write(code_text, ai_update)
            else:  # 正常上传文件后的AI修改
                settings['code_text'] = code_first + kimi_update(code_text, os.path.join('media/upload/', file_name),
                                                                 ai_update)

        elif file_name == 'no_file':
            print('文件路径：文件异常')
            info['type'] = 'file_error'

        elif 'ai_btn' in request.POST:
            print('AI模式：正在生成代码')
            ai_text = request.POST.get('ai', '自行发挥')
            # 修改返回字典
            info['type'] = 'handbook'  # example handbook .ext traceback file_error output_only
            info['mode'] = 'code'  # simple code ai
            info['btn'] = 1  # 1 0
            settings['ai_text'] = ai_text
            settings['code_text'] = code_first + kimi_code(os.path.join('media/upload/', file_name), ai_text)

        elif 'simple_mode' in request.POST:
            print(f'简单模式：快速合成代码(页面ID：{workbench_id})')
            if int(workbench_id) == 1:  # 直方图
                # 开始运行简单模式
                fontFamilyDict = {
                    "宋体": "SimSun",
                    "黑体": "SimHei",
                    "微软雅黑": "Microsoft YaHei",
                    "微软正黑体": "Microsoft JhengHei",
                    "楷体": "KaiTi",
                    "新宋体": "NSimSun",
                    "仿宋": "FangSong",
                    "苹方": "PingFang SC",
                    "华文黑体": "STHeiti",
                    "华文楷体": "STKaiti",
                    "华文宋体": "STSong",
                    "冬青黑体简": "Hiragino Sans GB",
                    "幼圆": "YouYuan",
                    "隶书": "LiSu",
                    "思源黑体": "Source Han Sans CN",
                    "思源宋体": "Source Han Serif SC",
                    "文泉驿微米黑": "WenQuanYi Micro Hei",
                }
                colorThemeDict = {
                    "江南水乡": ['#87CEEB', '#FFF8DC', '#6B8E23', '#556B2F'],
                    "秋日暖阳": ['#FFD700', '#FF8C00', '#FF4500', '#E9967A', '#CD5C5C'],
                    "清凉薄荷": ['#7FFFD4', '#00FA9A', '#00FFFF', '#87CEFA', '#F0FFFF'],
                    "绿野仙踪": ['#f1e6a9', '#a9c589', '#45915f', '#085a61', '#2b383b'],
                    "青花瓷韵": ['#4682B4', '#F5F5F5', '#696969', '#FFD700'],
                    "暮光之城": ['#b84721', '#f1f1f2', '#7cb0cf', '#084774', '#111f20'],
                    "冷峻冰川": ['#00BFFF', '#87CEFA', '#4682B4', '#1E90FF', '#0000CD'],
                    "湖光秋色": ['#87CEFA', '#00BFFF', '#FDB813', '#B49B63', '#8B0000']
                }

                # 字体
                fontFamily_re = request.POST.get('fontFamily', '微软雅黑')
                fontFamily = fontFamilyDict.get(fontFamily_re, 'Microsoft YaHei')
                # 箱体个数
                if 'boxCountOn' in request.POST:
                    boxCount = '\'auto\''
                else:
                    boxCount = request.POST.get('boxCount', '\'auto\'')
                # 标题字体大小
                titleFontSize = request.POST.get('titleFontSize', 16)
                if not titleFontSize: titleFontSize = 16
                # XY 轴标签字体大小
                xyLabelFontSize = request.POST.get('xyLabelFontSize', 14)
                if not xyLabelFontSize: xyLabelFontSize = 14
                # X 轴刻度字体大小
                xScaleFontSize = request.POST.get('xScaleFontSize', 12)
                if not xScaleFontSize: xScaleFontSize = 12
                # Y 轴刻度字体大小
                yScaleFontSize = request.POST.get('yScaleFontSize', 12)
                if not yScaleFontSize: yScaleFontSize = 12
                # 顶部轴线宽度
                topAxisLineWidth = request.POST.get('topAxisLineWidth', 0)
                if not topAxisLineWidth: topAxisLineWidth = 0
                # 底部轴线宽度
                bottomAxisLineWidth = request.POST.get('bottomAxisLineWidth', 1)
                if not bottomAxisLineWidth: bottomAxisLineWidth = 1
                # 左侧轴线宽度
                leftAxisLineWidth = request.POST.get('leftAxisLineWidth', 1)
                if not leftAxisLineWidth: leftAxisLineWidth = 1
                # 右侧轴线宽度
                rightAxisLineWidth = request.POST.get('rightAxisLineWidth', 0)
                if not rightAxisLineWidth: rightAxisLineWidth = 0
                # 标题及标签
                text_dict = json.loads(request.POST.get('text_json', '{}'))

                simpleCode = ''  # 等待提交的代码
                code_1 = rf'''# 判断文件类型并读取数据
if file_url.endswith('.csv'):
    data = pd.read_csv(file_url)
elif file_url.endswith('.xlsx'):
    data = pd.read_excel(file_url)

# 设置中文字体
plt.rcParams['font.family'] = '{fontFamily}'
plt.rcParams['axes.unicode_minus'] = False  # 解决负号显示问题

# 设置图表分辨率
plt.figure(dpi=300)
'''
                simpleCode += code_1

                # 颜色主题（以及单色主题）
                if 'AColorOn' in request.POST:
                    AColor = request.POST.get('AColor', '#B685FF')
                    code_2 = rf'''
# 绘制直方图，使用 seaborn 自动选择箱体个数
sns.histplot(data.iloc[:, 0], kde=False, bins={boxCount}, color='{AColor}')
'''
                    simpleCode += code_2
                else:
                    # 定义每个柱子的颜色
                    colorTheme_re = request.POST.get('colorTheme', '绿野仙踪')
                    colorTheme = colorThemeDict.get(colorTheme_re, ['#B685FF', ])
                    code_3 = rf'''
# 计算直方图的柱子位置和高度
counts, bin_edges = np.histogram(data.iloc[:, 0], bins={boxCount})
bin_centers = (bin_edges[:-1] + bin_edges[1:]) / 2

# 定义每个柱子的颜色
colorTheme = {colorTheme}[:len(counts)]  # 确保颜色数量与柱子数量匹配

# 绘制直方图
plt.bar(bin_centers, counts, width=bin_edges[1] - bin_edges[0], color=colorTheme, edgecolor='black')
'''
                    simpleCode += code_3

                # 中位数线
                if 'medianLineOn' in request.POST:
                    code_4 = rf'''
# 中位数线
median = data.iloc[:, 0].median()
plt.axvline(median, color='red', linestyle='--', label='中位数')
'''
                    simpleCode += code_4

                # 正态分布曲线
                if 'gaussianCurveOn' in request.POST:
                    code_5 = rf'''
# 正态分布曲线
mu = data.iloc[:, 0].mean()
sigma = data.iloc[:, 0].std()
x = np.linspace(data.iloc[:, 0].min(), data.iloc[:, 0].max(), 100)
y = np.exp(-((x - mu) ** 2) / (2 * sigma ** 2)) / (sigma * np.sqrt(2 * np.pi))
plt.plot(x, y * len(data) * (data.iloc[:, 0].max() - data.iloc[:, 0].min()) / 10, color='green', label='正态分布曲线')
'''
                    simpleCode += code_5

                # 设置文字
                chartTitle = text_dict.get('chartTitle', '直方图')
                if not chartTitle: chartTitle = '直方图'
                xAxisLabel = text_dict.get('xAxisLabel', 'X轴')
                if not xAxisLabel: xAxisLabel = 'X轴'
                yAxisLabel = text_dict.get('yAxisLabel', 'Y轴')
                if not yAxisLabel: yAxisLabel = 'Y轴'
                code_6 = rf'''
# 设置文字及字体大小
plt.title('{chartTitle}', fontsize={titleFontSize})
plt.xlabel('{xAxisLabel}', fontsize={xyLabelFontSize})
plt.ylabel('{yAxisLabel}', fontsize={xyLabelFontSize})

# 设置轴线宽度
plt.gca().spines['bottom'].set_linewidth({bottomAxisLineWidth})
plt.gca().spines['left'].set_linewidth({leftAxisLineWidth})
plt.gca().spines['top'].set_linewidth({topAxisLineWidth})
plt.gca().spines['right'].set_linewidth({rightAxisLineWidth})

# 设置刻度字体大小
plt.xticks(fontsize={xScaleFontSize})
plt.yticks(fontsize={yScaleFontSize})
'''
                simpleCode += code_6

                # 添加图例
                if 'legendOn' in request.POST:
                    code_7 = rf'''
# 添加图例
plt.legend()
'''
                    simpleCode += code_7

                if 'imageFormatOn' in request.POST:
                    ext = request.POST.get('imageFormat', 'PNG').lower()
                    execution_result = run_code(simpleCode, file_name, ext)
                    # 修改返回字典
                    settings['code_text'] = code_first + simpleCode
                    if execution_result["error"]:
                        print('python模式：报错（Traceback）')
                        re_traceback = execution_result['error']
                        re_traceback = re_traceback.split('File ', 1)[0] + 'File "<string>"' + \
                                       re_traceback.split('File "<string>"', 1)[1]
                        # 修改返回字典
                        info['type'] = 'traceback'  # example handbook .ext traceback file_error output_only
                        info['mode'] = 'code'  # simple code ai
                        info['btn'] = 1  # 1 0
                        info['traceback'] = re_traceback
                    elif not execution_result['images']:
                        print('python模式：空运行')
                        # 修改返回字典
                        info['type'] = 'traceback'  # example handbook .ext traceback file_error output_only
                        info['mode'] = 'code'  # simple code ai
                        info['btn'] = 1  # 1 0
                        info['traceback'] = '未知错误，你的代码运行了什么？'
                    else:
                        request.session['chart_file'] = execution_result['images'][0]
                        print('python模式：执行成功')
                        # 修改返回字典
                        info['type'] = execution_result['images'][0].split('.')[-1].lower()
                        # example handbook .ext traceback file_error
                        info['mode'] = 'code'  # simple code ai
                        info['btn'] = 1  # 1 0
                        info['chart_url'] = execution_result['images'][0]
                else:
                    # 修改返回字典
                    info['type'] = 'handbook'  # example handbook .ext traceback file_error output_only
                    info['mode'] = 'code'  # simple code ai
                    info['btn'] = 1  # 1 0
                    settings['code_text'] = code_first + simpleCode

            elif int(workbench_id) == 2:  # 密度图
                # 开始运行密度图模式
                fontFamilyDict = {
                    "宋体": "SimSun",
                    "黑体": "SimHei",
                    "微软雅黑": "Microsoft YaHei",
                    "微软正黑体": "Microsoft JhengHei",
                    "楷体": "KaiTi",
                    "新宋体": "NSimSun",
                    "仿宋": "FangSong",
                    "苹方": "PingFang SC",
                    "华文黑体": "STHeiti",
                    "华文楷体": "STKaiti",
                    "华文宋体": "STSong",
                    "冬青黑体简": "Hiragino Sans GB",
                    "幼圆": "YouYuan",
                    "隶书": "LiSu",
                    "思源黑体": "Source Han Sans CN",
                    "思源宋体": "Source Han Serif SC",
                    "文泉驿微米黑": "WenQuanYi Micro Hei",
                }

                # 字体
                fontFamily_re = request.POST.get('fontFamily', '微软雅黑')
                fontFamily = fontFamilyDict.get(fontFamily_re, 'Microsoft YaHei')
                # 标题字体大小
                titleFontSize = request.POST.get('titleFontSize', 16)
                if not titleFontSize: titleFontSize = 16
                # XY 轴标签字体大小
                xyLabelFontSize = request.POST.get('xyLabelFontSize', 14)
                if not xyLabelFontSize: xyLabelFontSize = 14
                # X 轴刻度字体大小
                xScaleFontSize = request.POST.get('xScaleFontSize', 12)
                if not xScaleFontSize: xScaleFontSize = 12
                # Y 轴刻度字体大小
                yScaleFontSize = request.POST.get('yScaleFontSize', 12)
                if not yScaleFontSize: yScaleFontSize = 12
                # 顶部轴线宽度
                topAxisLineWidth = request.POST.get('topAxisLineWidth', 0)
                if not topAxisLineWidth: topAxisLineWidth = 0
                # 底部轴线宽度
                bottomAxisLineWidth = request.POST.get('bottomAxisLineWidth', 1)
                if not bottomAxisLineWidth: bottomAxisLineWidth = 1
                # 左侧轴线宽度
                leftAxisLineWidth = request.POST.get('leftAxisLineWidth', 1)
                if not leftAxisLineWidth: leftAxisLineWidth = 1
                # 右侧轴线宽度
                rightAxisLineWidth = request.POST.get('rightAxisLineWidth', 0)
                if not rightAxisLineWidth: rightAxisLineWidth = 0
                # 标题及标签
                text_dict = json.loads(request.POST.get('text_json', '{}'))

                simpleCode = ''  # 等待提交的代码
                code_1 = rf'''# 判断文件类型并读取数据
if file_url.endswith('.csv'):
    data = pd.read_csv(file_url)
elif file_url.endswith('.xlsx'):
    data = pd.read_excel(file_url)

# 动态选择一个数值型列作为绘图目标
numeric_columns = data.select_dtypes(include=['int64', 'float64']).columns.tolist()
if len(numeric_columns) == 0:
    raise ValueError("数据中没有数值型列，无法绘制密度图")
selected_column = numeric_columns[0]  # 选择第一个数值型列

# 设置中文字体
plt.rcParams['font.family'] = '{fontFamily}'
plt.rcParams['axes.unicode_minus'] = False  # 解决负号显示问题
'''
                simpleCode += code_1

                # 颜色主题（以及单色主题）
                edgeColor = request.POST.get('edgeColor', '#B685FF')
                AColor = request.POST.get('AColor', '#B685FF')
                code_2 = rf'''
# 绘制密度图
plt.figure(figsize=(10, 6))
sns.kdeplot(data[selected_column], fill=True, color="{AColor}", alpha=0.8, linewidth=1.5, edgecolor="{edgeColor}", zorder=1)
'''
                simpleCode += code_2

                # 中位数线
                if 'medianLineOn' in request.POST:
                    code_4 = rf'''
# 中位数线
median = data.iloc[:, 0].median()
plt.axvline(median, color='red', linestyle='--', label='中位数')
'''
                    simpleCode += code_4

                # 设置文字
                chartTitle = text_dict.get('chartTitle', '密度图')
                if not chartTitle: chartTitle = '密度图'
                xAxisLabel = text_dict.get('xAxisLabel', 'X轴')
                if not xAxisLabel: xAxisLabel = 'X轴'
                yAxisLabel = text_dict.get('yAxisLabel', 'Y轴')
                if not yAxisLabel: yAxisLabel = 'Y轴'
                code_6 = rf'''
# 设置文字及字体大小
plt.title('{chartTitle}', fontsize={titleFontSize})
plt.xlabel('{xAxisLabel}', fontsize={xyLabelFontSize})
plt.ylabel('{yAxisLabel}', fontsize={xyLabelFontSize})

# 设置轴线宽度
plt.gca().spines['bottom'].set_linewidth({bottomAxisLineWidth})
plt.gca().spines['left'].set_linewidth({leftAxisLineWidth})
plt.gca().spines['top'].set_linewidth({topAxisLineWidth})
plt.gca().spines['right'].set_linewidth({rightAxisLineWidth})

# 设置刻度字体大小
plt.xticks(fontsize={xScaleFontSize})
plt.yticks(fontsize={yScaleFontSize})
'''
                simpleCode += code_6

                # 添加图例
                if 'legendOn' in request.POST:
                    code_7 = rf'''
# 添加图例
plt.legend()
'''
                    simpleCode += code_7

                # 显示图表
                code_9 = rf'''
plt.tight_layout()
plt.show()
'''
                simpleCode += code_9

                if 'imageFormatOn' in request.POST:
                    ext = request.POST.get('imageFormat', 'PNG').lower()
                    execution_result = run_code(simpleCode, file_name, ext)
                    # 修改返回字典
                    settings['code_text'] = code_first + simpleCode
                    if execution_result["error"]:
                        print('python模式：报错（Traceback）')
                        re_traceback = execution_result['error']
                        re_traceback = re_traceback.split('File ', 1)[0] + 'File "<string>"' + \
                                       re_traceback.split('File "<string>"', 1)[1]
                        # 修改返回字典
                        info['type'] = 'traceback'  # example handbook .ext traceback file_error output_only
                        info['mode'] = 'code'  # simple code ai
                        info['btn'] = 1  # 1 0
                        info['traceback'] = re_traceback
                    elif not execution_result['images']:
                        print('python模式：空运行')
                        # 修改返回字典
                        info['type'] = 'traceback'  # example handbook .ext traceback file_error output_only
                        info['mode'] = 'code'  # simple code ai
                        info['btn'] = 1  # 1 0
                        info['traceback'] = '未知错误，你的代码运行了什么？'
                    else:
                        request.session['chart_file'] = execution_result['images'][0]
                        print('python模式：执行成功')
                        # 修改返回字典
                        info['type'] = execution_result['images'][0].split('.')[-1].lower()
                        # example handbook .ext traceback file_error
                        info['mode'] = 'code'  # simple code ai
                        info['btn'] = 1  # 1 0
                        info['chart_url'] = execution_result['images'][0]
                else:
                    # 修改返回字典
                    info['type'] = 'handbook'  # example handbook .ext traceback file_error output_only
                    info['mode'] = 'code'  # simple code ai
                    info['btn'] = 1  # 1 0
                    settings['code_text'] = code_first + simpleCode

            elif int(workbench_id) == 3:  # 散点图
                fontFamilyDict = {
                    "宋体": "SimSun",
                    "黑体": "SimHei",
                    "微软雅黑": "Microsoft YaHei",
                    "微软正黑体": "Microsoft JhengHei",
                    "楷体": "KaiTi",
                    "新宋体": "NSimSun",
                    "仿宋": "FangSong",
                    "苹方": "PingFang SC",
                    "华文黑体": "STHeiti",
                    "华文楷体": "STKaiti",
                    "华文宋体": "STSong",
                    "冬青黑体简": "Hiragino Sans GB",
                    "幼圆": "YouYuan",
                    "隶书": "LiSu",
                    "思源黑体": "Source Han Sans CN",
                    "思源宋体": "Source Han Serif SC",
                    "文泉驿微米黑": "WenQuanYi Micro Hei",
                }

                # 字体
                fontFamily_re = request.POST.get('fontFamily', '微软雅黑')
                fontFamily = fontFamilyDict.get(fontFamily_re, 'Microsoft YaHei')
                # 标题字体大小
                titleFontSize = request.POST.get('titleFontSize', 16)
                if not titleFontSize: titleFontSize = 16
                # XY 轴标签字体大小
                xyLabelFontSize = request.POST.get('xyLabelFontSize', 14)
                if not xyLabelFontSize: xyLabelFontSize = 14
                # X 轴刻度字体大小
                xScaleFontSize = request.POST.get('xScaleFontSize', 12)
                if not xScaleFontSize: xScaleFontSize = 12
                # Y 轴刻度字体大小
                yScaleFontSize = request.POST.get('yScaleFontSize', 12)
                if not yScaleFontSize: yScaleFontSize = 12
                # 顶部轴线宽度
                topAxisLineWidth = request.POST.get('topAxisLineWidth', 0)
                if not topAxisLineWidth: topAxisLineWidth = 0
                # 底部轴线宽度
                bottomAxisLineWidth = request.POST.get('bottomAxisLineWidth', 1)
                if not bottomAxisLineWidth: bottomAxisLineWidth = 1
                # 左侧轴线宽度
                leftAxisLineWidth = request.POST.get('leftAxisLineWidth', 1)
                if not leftAxisLineWidth: leftAxisLineWidth = 1
                # 右侧轴线宽度
                rightAxisLineWidth = request.POST.get('rightAxisLineWidth', 0)
                if not rightAxisLineWidth: rightAxisLineWidth = 0
                # 标题及标签
                text_dict = json.loads(request.POST.get('text_json', '{}'))

                simpleCode = ''  # 等待提交的代码
                code_1 = rf'''# 判断文件类型并读取数据
if file_url.endswith('.csv'):
    data = pd.read_csv(file_url)
elif file_url.endswith('.xlsx'):
    data = pd.read_excel(file_url)

# 动态选择数值型列作为绘图目标
numeric_columns = data.select_dtypes(include=['int64', 'float64']).columns.tolist()
if len(numeric_columns) < 2:
    raise ValueError("数据中数值型列不足2个，无法绘制散点图")
selected_columns = numeric_columns[:2]  # 选择前两个数值型列

# 设置中文字体
plt.rcParams['font.family'] = '{fontFamily}'
plt.rcParams['axes.unicode_minus'] = False  # 解决负号显示问题
'''
                simpleCode += code_1

                # 颜色主题（以及单色主题）
                AColor = request.POST.get('AColor', '#B685FF')
                code_2 = rf'''
# 绘制散点图
plt.figure(figsize=(10, 6))
sns.scatterplot(x=selected_columns[0], y=selected_columns[1], data=data, color="{AColor}", alpha=0.6, zorder=1)
'''
                simpleCode += code_2

                # 中位数线
                if 'medianLineOn' in request.POST:
                    code_4 = rf'''
# 中位数线
median = data.iloc[:, 0].median()
plt.axvline(median, color='red', linestyle='--', label='中位数')
'''
                    simpleCode += code_4

                # 设置文字
                chartTitle = text_dict.get('chartTitle', '散点图')
                if not chartTitle: chartTitle = '散点图'
                xAxisLabel = text_dict.get('xAxisLabel', 'X轴')
                if not xAxisLabel: xAxisLabel = 'X轴'
                yAxisLabel = text_dict.get('yAxisLabel', 'Y轴')
                if not yAxisLabel: yAxisLabel = 'Y轴'
                code_6 = rf'''
# 设置文字及字体大小
plt.title('{chartTitle}', fontsize={titleFontSize})
plt.xlabel('{xAxisLabel}', fontsize={xyLabelFontSize})
plt.ylabel('{yAxisLabel}', fontsize={xyLabelFontSize})

# 设置轴线宽度
plt.gca().spines['bottom'].set_linewidth({bottomAxisLineWidth})
plt.gca().spines['left'].set_linewidth({leftAxisLineWidth})
plt.gca().spines['top'].set_linewidth({topAxisLineWidth})
plt.gca().spines['right'].set_linewidth({rightAxisLineWidth})

# 设置刻度字体大小
plt.xticks(fontsize={xScaleFontSize})
plt.yticks(fontsize={yScaleFontSize})
'''
                simpleCode += code_6

                # 添加图例
                if 'legendOn' in request.POST:
                    code_7 = rf'''
# 添加图例
plt.legend()
'''
                    simpleCode += code_7

                # 显示图表
                code_9 = rf'''
plt.tight_layout()
plt.show()
'''
                simpleCode += code_9

                if 'imageFormatOn' in request.POST:
                    ext = request.POST.get('imageFormat', 'PNG').lower()
                    execution_result = run_code(simpleCode, file_name, ext)
                    # 修改返回字典
                    settings['code_text'] = code_first + simpleCode
                    if execution_result["error"]:
                        print('python模式：报错（Traceback）')
                        re_traceback = execution_result['error']
                        re_traceback = re_traceback.split('File ', 1)[0] + 'File "<string>"' + \
                                       re_traceback.split('File "<string>"', 1)[1]
                        # 修改返回字典
                        info['type'] = 'traceback'  # example handbook .ext traceback file_error output_only
                        info['mode'] = 'code'  # simple code ai
                        info['btn'] = 1  # 1 0
                        info['traceback'] = re_traceback
                    elif not execution_result['images']:
                        print('python模式：空运行')
                        # 修改返回字典
                        info['type'] = 'traceback'  # example handbook .ext traceback file_error output_only
                        info['mode'] = 'code'  # simple code ai
                        info['btn'] = 1  # 1 0
                        info['traceback'] = '未知错误，你的代码运行了什么？'
                    else:
                        request.session['chart_file'] = execution_result['images'][0]
                        print('python模式：执行成功')
                        # 修改返回字典
                        info['type'] = execution_result['images'][0].split('.')[-1].lower()
                        # example handbook .ext traceback file_error
                        info['mode'] = 'code'  # simple code ai
                        info['btn'] = 1  # 1 0
                        info['chart_url'] = execution_result['images'][0]
                else:
                    # 修改返回字典
                    info['type'] = 'handbook'  # example handbook .ext traceback file_error output_only
                    info['mode'] = 'code'  # simple code ai
                    info['btn'] = 1  # 1 0
                    settings['code_text'] = code_first + simpleCode

                settings['style'] = [
                    {'type': 'select', 'name': '字体', 'id': 'fontFamily',
                     'items': [fontFamily_re, '宋体', '仿宋', '楷体', '细黑', '微软雅黑']},
                    {'type': 'color', 'name': '选择颜色', 'id': 'AColor', 'value': AColor},
                    {'type': 'number', 'name': '标题字体大小', 'id': 'titleFontSize', 'value': titleFontSize},
                    {'type': 'number', 'name': 'XY 轴标签字体大小', 'id': 'xyLabelFontSize', 'value': xyLabelFontSize},
                    {'type': 'number', 'name': 'X 轴刻度字体大小', 'id': 'xScaleFontSize', 'value': xScaleFontSize},
                    {'type': 'number', 'name': 'Y 轴刻度字体大小', 'id': 'yScaleFontSize', 'value': yScaleFontSize},
                    {'type': 'number', 'name': '顶部轴线宽度', 'id': 'topAxisLineWidth', 'value': topAxisLineWidth},
                    {'type': 'number', 'name': '底部轴线宽度', 'id': 'bottomAxisLineWidth',
                     'value': bottomAxisLineWidth},
                    {'type': 'number', 'name': '左侧轴线宽度', 'id': 'leftAxisLineWidth', 'value': leftAxisLineWidth},
                    {'type': 'number', 'name': '右侧轴线宽度', 'id': 'rightAxisLineWidth', 'value': rightAxisLineWidth},
                    {'type': 'check', 'name': '图例', 'id': 'legend', 'value': 0},
                    {'type': 'check', 'name': '中位数线', 'id': 'medianLine', 'value': 0},
                    {'type': 'select_check', 'name': '图表格式', 'id': 'imageFormat',
                     'items': ['PNG', 'SVG', 'PDF', 'JPG'], 'value': 1, 'text': '启用快速绘图'},
                ]

                settings['text'] = [
                    {'name': '图表标题', 'id': 'chartTitle', 'value': chartTitle},
                    {'name': 'X 轴标签', 'id': 'xAxisLabel', 'value': xAxisLabel},
                    {'name': 'Y 轴标签', 'id': 'yAxisLabel', 'value': yAxisLabel},
                ]

            elif int(workbench_id) == 4:  # 混淆矩阵
                fontFamilyDict = {
                    "宋体": "SimSun",
                    "黑体": "SimHei",
                    "微软雅黑": "Microsoft YaHei",
                    "微软正黑体": "Microsoft JhengHei",
                    "楷体": "KaiTi",
                    "新宋体": "NSimSun",
                    "仿宋": "FangSong",
                    "苹方": "PingFang SC",
                    "华文黑体": "STHeiti",
                    "华文楷体": "STKaiti",
                    "华文宋体": "STSong",
                    "冬青黑体简": "Hiragino Sans GB",
                    "幼圆": "YouYuan",
                    "隶书": "LiSu",
                    "思源黑体": "Source Han Sans CN",
                    "思源宋体": "Source Han Serif SC",
                    "文泉驿微米黑": "WenQuanYi Micro Hei",
                }

                # 颜色主题
                original_list = [
                    'Blues渐变蓝', 'Reds渐变红', 'Greens渐变绿', 'Greys渐变灰', 'rainbow彩虹', 'hot热图渐变',
                    'winter冬季渐变', 'summer夏季渐变', 'viridis黄紫', 'plasma黄红', 'cividis蓝黄',
                    'coolwarm蓝白红', 'RdYlGn红黄绿', 'RdYlBu红黄蓝'
                ]
                no_chinese_list = [
                    'Blues', 'Reds', 'Greens', 'Greys', 'rainbow', 'hot',
                    'winter', 'summer', 'viridis', 'plasma', 'cividis',
                    'coolwarm', 'RdYlGn', 'RdYlBu'
                ]
                colorTheme_re = request.POST.get('colorTheme', 'Blues渐变蓝')
                if colorTheme_re in original_list:
                    index = original_list.index(colorTheme_re)
                    colorTheme = no_chinese_list[index]
                else:
                    colorTheme = 'Blues'
                # 字体
                fontFamily_re = request.POST.get('fontFamily', '微软雅黑')
                fontFamily = fontFamilyDict.get(fontFamily_re, 'Microsoft YaHei')
                # 标题字体大小
                titleFontSize = request.POST.get('titleFontSize', 16)
                if not titleFontSize: titleFontSize = 16
                # XY 轴标签字体大小
                xyLabelFontSize = request.POST.get('xyLabelFontSize', 14)
                if not xyLabelFontSize: xyLabelFontSize = 14
                # X 轴刻度字体大小
                xScaleFontSize = request.POST.get('xScaleFontSize', 12)
                if not xScaleFontSize: xScaleFontSize = 12
                # Y 轴刻度字体大小
                yScaleFontSize = request.POST.get('yScaleFontSize', 12)
                if not yScaleFontSize: yScaleFontSize = 12
                # 顶部轴线宽度
                topAxisLineWidth = request.POST.get('topAxisLineWidth', 0)
                if not topAxisLineWidth: topAxisLineWidth = 0
                # 底部轴线宽度
                bottomAxisLineWidth = request.POST.get('bottomAxisLineWidth', 1)
                if not bottomAxisLineWidth: bottomAxisLineWidth = 1
                # 左侧轴线宽度
                leftAxisLineWidth = request.POST.get('leftAxisLineWidth', 1)
                if not leftAxisLineWidth: leftAxisLineWidth = 1
                # 右侧轴线宽度
                rightAxisLineWidth = request.POST.get('rightAxisLineWidth', 0)
                if not rightAxisLineWidth: rightAxisLineWidth = 0
                # 标题及标签
                text_dict = json.loads(request.POST.get('text_json', '{}'))

                simpleCode = ''  # 等待提交的代码
                code_1 = rf'''# 判断文件类型并读取数据
if file_url.endswith('.csv'):
    data = pd.read_csv(file_url)
elif file_url.endswith('.xlsx'):
    data = pd.read_excel(file_url)

# 动态选择数值型列作为绘图目标
numeric_columns = data.select_dtypes(include=['int64', 'float64']).columns.tolist()
if len(numeric_columns) < 2:
    raise ValueError("数据中数值型列不足2个，无法绘制热力图")
selected_columns = numeric_columns[:2]  # 选择前两个数值型列

# 设置中文字体
plt.rcParams['font.family'] = '{fontFamily}'
plt.rcParams['axes.unicode_minus'] = False  # 解决负号显示问题
'''
                simpleCode += code_1

                ScaleList = request.POST.get('ScaleList', "['类型1','类型2','类型3']")
                code_2 = rf'''
# 提取真实标签和预测标签
true_labels = data[selected_columns[0]].values
predicted_labels = data[selected_columns[1]].values

# 计算混淆矩阵
cm = confusion_matrix(true_labels, predicted_labels)

# 定义类别标签（根据你的数据调整）
class_labels = {ScaleList}
'''
                simpleCode += code_2

                # 颜色主题（以及单色主题）
                if 'showNumberOn' in request.POST:
                    code_3 = rf'''
# 绘制热力图
plt.figure(figsize=(12, 10))
sns.heatmap(cm, annot=True, fmt='d', cmap='{colorTheme}', xticklabels=class_labels, yticklabels=class_labels)
'''
                    simpleCode += code_3
                else:
                    code_3 = rf'''
# 绘制热力图
plt.figure(figsize=(12, 10))
sns.heatmap(cm, annot=False, fmt='d', cmap='{colorTheme}', xticklabels=class_labels, yticklabels=class_labels)
'''
                    simpleCode += code_3

                # 中位数线
                if 'medianLineOn' in request.POST:
                    code_4 = rf'''
# 中位数线
median = data.iloc[:, 0].median()
plt.axvline(median, color='red', linestyle='--', label='中位数')
'''
                    simpleCode += code_4

                # 设置文字
                chartTitle = text_dict.get('chartTitle', '混淆矩阵')
                if not chartTitle: chartTitle = '混淆矩阵'
                xAxisLabel = text_dict.get('xAxisLabel', '预测值')
                if not xAxisLabel: xAxisLabel = 'X轴'
                yAxisLabel = text_dict.get('yAxisLabel', '真实值')
                if not yAxisLabel: yAxisLabel = 'Y轴'
                code_6 = rf'''
# 设置文字及字体大小
plt.title('{chartTitle}', fontsize={titleFontSize})
plt.xlabel('{xAxisLabel}', fontsize={xyLabelFontSize})
plt.ylabel('{yAxisLabel}', fontsize={xyLabelFontSize})

# 设置轴线宽度
plt.gca().spines['bottom'].set_linewidth({bottomAxisLineWidth})
plt.gca().spines['left'].set_linewidth({leftAxisLineWidth})
plt.gca().spines['top'].set_linewidth({topAxisLineWidth})
plt.gca().spines['right'].set_linewidth({rightAxisLineWidth})

# 设置刻度字体大小
plt.xticks(fontsize={xScaleFontSize})
plt.yticks(fontsize={yScaleFontSize})
'''
                simpleCode += code_6

                # 添加图例
                if 'legendOn' in request.POST:
                    code_7 = rf'''
# 添加图例
plt.legend()
'''
                    simpleCode += code_7

                # 显示图表
                code_9 = rf'''
plt.tight_layout()
plt.show()
'''
                simpleCode += code_9

                if 'imageFormatOn' in request.POST:
                    ext = request.POST.get('imageFormat', 'PNG').lower()
                    execution_result = run_code(simpleCode, file_name, ext)
                    # 修改返回字典
                    settings['code_text'] = code_first + simpleCode
                    if execution_result["error"]:
                        print('python模式：报错（Traceback）')
                        re_traceback = execution_result['error']
                        re_traceback = re_traceback.split('File ', 1)[0] + 'File "<string>"' + \
                                       re_traceback.split('File "<string>"', 1)[1]
                        # 修改返回字典
                        info['type'] = 'traceback'  # example handbook .ext traceback file_error output_only
                        info['mode'] = 'code'  # simple code ai
                        info['btn'] = 1  # 1 0
                        info['traceback'] = re_traceback
                    elif not execution_result['images']:
                        print('python模式：空运行')
                        # 修改返回字典
                        info['type'] = 'traceback'  # example handbook .ext traceback file_error output_only
                        info['mode'] = 'code'  # simple code ai
                        info['btn'] = 1  # 1 0
                        info['traceback'] = '未知错误，你的代码运行了什么？'
                    else:
                        request.session['chart_file'] = execution_result['images'][0]
                        print('python模式：执行成功')
                        # 修改返回字典
                        info['type'] = execution_result['images'][0].split('.')[-1].lower()
                        # example handbook .ext traceback file_error
                        info['mode'] = 'code'  # simple code ai
                        info['btn'] = 1  # 1 0
                        info['chart_url'] = execution_result['images'][0]
                else:
                    # 修改返回字典
                    info['type'] = 'handbook'  # example handbook .ext traceback file_error output_only
                    info['mode'] = 'code'  # simple code ai
                    info['btn'] = 1  # 1 0
                    settings['code_text'] = code_first + simpleCode

                # 记忆上次修改
                settings['style'] = [
                    {'type': 'select', 'name': '字体', 'id': 'fontFamily',
                     'items': [fontFamily_re, '宋体', '仿宋', '楷体', '细黑', '微软雅黑']},
                    {'type': 'select', 'name': '颜色主题', 'id': 'colorTheme',
                     'items': [colorTheme_re, 'Blues渐变蓝', 'Reds渐变红', 'Greens渐变绿', 'Greys渐变灰', 'rainbow彩虹',
                               'hot热图渐变',
                               'winter冬季渐变', 'summer夏季渐变', 'viridis黄紫', 'plasma黄红', 'cividis蓝黄',
                               'coolwarm蓝白红',
                               'RdYlGn红黄绿', 'RdYlBu红黄蓝']},
                    {'type': 'check', 'name': '显示数值', 'id': 'showNumber', 'value': 1},
                    {'type': 'text', 'name': 'XY 轴刻度列表', 'id': 'ScaleList',
                     'value': ScaleList},
                    {'type': 'number', 'name': '标题字体大小', 'id': 'titleFontSize', 'value': titleFontSize},
                    {'type': 'number', 'name': 'XY 轴标签字体大小', 'id': 'xyLabelFontSize', 'value': xyLabelFontSize},
                    {'type': 'number', 'name': 'X 轴刻度字体大小', 'id': 'xScaleFontSize', 'value': xScaleFontSize},
                    {'type': 'number', 'name': 'Y 轴刻度字体大小', 'id': 'yScaleFontSize', 'value': yScaleFontSize},
                    {'type': 'check', 'name': '图例', 'id': 'legend', 'value': 0},
                    {'type': 'check', 'name': '中位数线', 'id': 'medianLine', 'value': 0},
                    {'type': 'select_check', 'name': '图表格式', 'id': 'imageFormat',
                     'items': ['PNG', 'SVG', 'PDF', 'JPG'], 'value': 1, 'text': '启用快速绘图'},
                ]

                settings['text'] = [
                    {'name': '图表标题', 'id': 'chartTitle', 'value': chartTitle},
                    {'name': 'X 轴标签', 'id': 'xAxisLabel', 'value': xAxisLabel},
                    {'name': 'Y 轴标签', 'id': 'yAxisLabel', 'value': yAxisLabel},
                ]

        else:  # 文件上传后首次加载
            print('首次加载：文件已上传')
            # 修改返回字典
            info['type'] = 'handbook'  # example handbook .ext traceback file_error output_only
            info['mode'] = 'simple'  # simple code ai
            info['btn'] = 1  # 1 0
            settings['code_text'] = code_first

    print('--------------------------request.GET--------------------------\n', request.GET)
    print('--------------------------request.POST--------------------------\n', request.POST)
    return render(request, 'Chart_Workbench.html', {'user': user, 'info': info, 'settings': settings})


def Index(request):
    request.session['page'] = reverse('Chart:Index')
    user = {
        'nickname': request.session.get('nickname', ''),
        'username': request.session.get('username', ''),
        'role': request.session.get('role', 0)
    }
    print(user)
    return render(request, 'Chart_Index.html', {'user': user, 'charts': CHARTS_PAGE_LIST()})
