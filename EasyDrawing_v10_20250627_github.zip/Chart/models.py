from django.db import models

# Create your models here.
class Chart(models.Model):
    id = models.BigAutoField(primary_key=True)
    time = models.DateTimeField(auto_now_add=True)
    chartname = models.CharField(max_length=255, unique=True)
    filename = models.ForeignKey('File', on_delete=models.SET_NULL, null=True, db_column='filename', to_field="filename")
    username = models.ForeignKey('User.User', on_delete=models.SET_NULL, null=True, db_column='username', to_field="username")


class File(models.Model):
    id = models.BigAutoField(primary_key=True)
    time = models.DateTimeField(auto_now_add=True)
    filename = models.CharField(max_length=255, unique=True)
    original_name = models.CharField(max_length=255)
    username = models.ForeignKey('User.User', on_delete=models.SET_NULL, null=True, db_column='username', to_field="username")