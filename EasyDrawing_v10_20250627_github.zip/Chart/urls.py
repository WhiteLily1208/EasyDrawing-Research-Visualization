from django.urls import path
from . import views

app_name = 'Chart'

urlpatterns = [
    path('Workbench/', views.Workbench, name='Workbench'), # 绘制页面
    path('', views.Index, name='Index'), # 图表首页
]