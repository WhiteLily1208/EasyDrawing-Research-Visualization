import re
from Chart.views import truncate_file
from EasyDrawing import settings
import os
import sys
import io
import traceback
import time
import random
import tiktoken
from pathlib import Path
from django.conf import settings
from openai import OpenAI, APIError, AuthenticationError, RateLimitError
from docx import Document
from docx.shared import Pt, RGBColor, Inches
from docx.enum.text import WD_PARAGRAPH_ALIGNMENT
from docx.oxml.ns import qn
import matplotlib.pyplot as plt
import seaborn as sns
import pandas as pd
import numpy as np
import uuid
from .models import UserDocument
from User.models import User
import matplotlib
matplotlib.use('Agg')


def generate_research_report(user_text, file_path, request, api_keys):
    """生成学术研究报告的主函数"""
    result = {
        "report": "",
        "error": None,
        "used_files": []
    }

    # 准备API请求的信息
    info = f"用户提供的文本: {user_text}"
    if file_path and os.path.exists(file_path):
        info += f"\n附加文件: {os.path.basename(file_path)}"

    try:
        # 调用Kimi API生成报告
        report_data = interact_with_kimi(
            request=request,
            info=info,
            file_path=file_path,
            api_keys=api_keys
        )

        if report_data["error"]:
            result["error"] = report_data["error"]
            result["report"] = f"报告生成失败: {report_data['error']}"
            return result

        result["report"] = report_data["response"]
        result["used_files"] = report_data["file_paths"]
        return result

    except Exception as e:
        result["error"] = f"生成报告时发生错误: {str(e)}"
        result["report"] = f"错误详情: {traceback.format_exc()}"
        return result


def interact_with_kimi(request: str, info: str, file_path: str = None, api_keys: list = None):
    """与Kimi API交互的通用函数"""
    result = {"response": "", "error": None, "file_paths": []}

    if api_keys is None:
        api_key = os.getenv("KIMI_API_KEY")
        if not api_key:
            raise ValueError("未提供API密钥且环境变量KIMI_API_KEY未设置")
        api_keys = [api_key]

    max_retries_per_key = 5
    wait_base = 2
    max_wait_time = 60
    key_index = 0
    key_attempts = {key: 0 for key in api_keys}
    RETRYABLE_ERRORS = (RateLimitError, APIError, TimeoutError)

    while True:
        current_key = api_keys[key_index]
        key_attempts[current_key] += 1
        retry_count = key_attempts[current_key]

        if retry_count > 1:
            _control_request_interval()

        e = None
        try:
            client = OpenAI(api_key=current_key, base_url="https://api.moonshot.cn/v1", timeout=30)

            if file_path and os.path.exists(file_path):
                result = _handle_file_interaction(client, request, info, file_path, current_key)
            else:
                result = _handle_conversation_interaction(client, request, info)

            if not result["error"]:
                global LAST_REQUEST_TIME
                LAST_REQUEST_TIME = time.time()
                return result

        except AuthenticationError as e:
            error_code = e.http_status
            error_msg = str(e)
            result["error"] = f"认证错误 (状态码: {error_code}): {error_msg}"

        except RETRYABLE_ERRORS as e:
            error_code = e.http_status if hasattr(e, 'http_status') else "N/A"
            error_msg = str(e)
            if retry_count == 1:
                result["error"] = f"首次尝试可重试错误 (状态码: {error_code}): {error_msg}"
            else:
                result["error"] = f"可重试错误 (状态码: {error_code}): {error_msg}"

        except Exception as e:
            error_msg = str(e)
            result["error"] = f"不可重试异常: {error_msg}"
            result["response"] = f"错误详情: {traceback.format_exc()}"

        if result["error"]:
            is_auth_error = isinstance(e, AuthenticationError) if e else False
            if is_auth_error or retry_count >= max_retries_per_key:
                key_index = (key_index + 1) % len(api_keys)
                if current_key in FILE_CACHE:
                    del FILE_CACHE[current_key]
            elif retry_count == 1:
                key_index = (key_index + 1) % len(api_keys)
                if current_key in FILE_CACHE:
                    del FILE_CACHE[current_key]
            else:
                wait_time = min(wait_base * (2 ** (retry_count - 1)) + random.uniform(0, 1), max_wait_time)
                time.sleep(wait_time)


# 文件交互处理
def _handle_file_interaction(client, request: str, info: str, file_path: str, api_key: str):
    result = {"response": "", "error": None, "file_paths": []}
    max_file_size = 10 * 1024 * 1024
    model = "moonshot-v1-8k"
    encoding = tiktoken.get_encoding("cl100k_base")
    max_model_tokens = 8192
    max_request_tokens = max_model_tokens - 1500

    try:
        file_size = os.path.getsize(file_path)
        if file_size > max_file_size:
            directory, filename = os.path.split(file_path)
            name, extension = os.path.splitext(filename)
            truncated_file = f"{name}_truncated{extension}"
            truncated_path = os.path.join(directory, truncated_file)
            truncate_file(file_path, truncated_path, extension[1:])
            file_path = truncated_path
            result["file_paths"].append(truncated_path)
        else:
            result["file_paths"].append(file_path)

        global FILE_CACHE
        if api_key not in FILE_CACHE:
            FILE_CACHE[api_key] = {}
        cache_key = os.path.abspath(file_path)

        if cache_key in FILE_CACHE[api_key]:
            file_object = FILE_CACHE[api_key][cache_key]
        else:
            file_object = client.files.create(file=Path(file_path), purpose="file-extract")
            FILE_CACHE[api_key][cache_key] = file_object

        file_content = client.files.content(file_id=file_object.id).text
        token_count = count_tokens(file_content, model, encoding)

        if token_count > max_request_tokens:
            truncated_content = truncate_to_tokens(file_content, max_request_tokens, encoding)
            file_content = truncated_content

        messages = [
            {"role": "system", "content": "你是Kimi，擅长数据分析。请根据提供的文件内容回答用户问题，回答要简洁专业。"},
            {"role": "user", "content": f"用户要求: {request}\n提供的信息: {info}"}
        ]
        if file_content:
            messages.insert(1, {"role": "system", "content": f"文件内容: {file_content}"})

        completion = client.chat.completions.create(
            model=model,
            messages=messages,
            temperature=0.3
        )

        result["response"] = completion.choices[0].message.content

    except Exception as e:
        result["error"] = f"文件交互过程中发生错误: {str(e)}"
        result["response"] = f"错误详情: {traceback.format_exc()}"

    return result


# 对话交互处理
def _handle_conversation_interaction(client, request: str, info: str):
    result = {"response": "", "error": None, "file_paths": []}
    model = "moonshot-v1-8k"
    encoding = tiktoken.get_encoding("cl100k_base")
    max_model_tokens = 8192
    max_request_tokens = max_model_tokens - 500

    try:
        system_prompt = "你是Kimi。你的回复浅显易懂、专业有效、温和自然，并严格遵守用户需求。"
        user_prompt = f"提供的信息: {info}\n用户要求: {request}"

        system_tokens = count_tokens(system_prompt, model, encoding)
        user_tokens = count_tokens(user_prompt, model, encoding)

        if system_tokens + user_tokens > max_request_tokens:
            max_user_tokens = max_request_tokens - system_tokens
            if max_user_tokens > 0:
                user_prompt = truncate_to_tokens(user_prompt, max_user_tokens, encoding)
            else:
                user_prompt = "用户提示词因Token限制被省略"

        messages = [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt}
        ]

        completion = client.chat.completions.create(
            model=model,
            messages=messages,
            temperature=0.3
        )

        result["response"] = completion.choices[0].message.content

    except Exception as e:
        result["error"] = f"对话交互过程中发生错误: {str(e)}"
        result["response"] = f"错误详情: {traceback.format_exc()}"

    return result


# Token计数与文本截断
def count_tokens(text: str, model: str, encoding) -> int:
    if text is None:
        return 0
    return len(encoding.encode(text))


def truncate_to_tokens(text: str, max_tokens: int, encoding) -> str:
    tokens = encoding.encode(text)
    if len(tokens) <= max_tokens:
        return text

    truncated_tokens = tokens[:max_tokens]
    truncated_text = encoding.decode(truncated_tokens)

    last_period = truncated_text.rfind('.')
    last_newline = truncated_text.rfind('\n')
    last_space = truncated_text.rfind(' ')

    best_pos = max(last_period, last_newline, last_space)
    if best_pos > 0:
        truncated_text = truncated_text[:best_pos + 1] + " [内容已截断]"
    else:
        truncated_text = truncated_text + " [内容已截断]"

    return truncated_text


def truncate_file(source_path: str, target_path: str, file_type: str):
    try:
        if file_type.lower() in ['csv', 'txt', 'tsv']:
            with open(source_path, 'r', encoding='utf-8') as f:
                lines = f.readlines()
            if len(lines) > 200:
                lines = lines[:200] + ["[文件内容已截断，仅保留前200行]"]
            with open(target_path, 'w', encoding='utf-8') as f:
                f.writelines(lines)
        else:
            with open(source_path, 'rb') as f_source, open(target_path, 'wb') as f_target:
                content = f_source.read(10 * 1024 * 1024)
                f_target.write(content)
                truncated_mark = "[文件内容已截断]".encode('utf-8')
                f_target.write(truncated_mark)
    except Exception as e:
        with open(source_path, 'rb') as f_source, open(target_path, 'wb') as f_target:
            f_target.write(f_source.read())


def _control_request_interval():
    global LAST_REQUEST_TIME, MIN_REQUEST_INTERVAL
    current_time = time.time()
    if current_time - LAST_REQUEST_TIME < MIN_REQUEST_INTERVAL:
        wait_time = MIN_REQUEST_INTERVAL - (current_time - LAST_REQUEST_TIME)
        time.sleep(wait_time)
    LAST_REQUEST_TIME = time.time()


# 全局变量
FILE_CACHE = {}
LAST_REQUEST_TIME = 0
MIN_REQUEST_INTERVAL = 20  # 最小请求间隔（秒）
API_KEYS = [
    os.getenv("KIMI_API_KEY1", "请替换为您的API_KEY"),
    os.getenv("KIMI_API_KEY2", "请替换为您的API_KEY"),
    os.getenv("KIMI_API_KEY3", "请替换为您的API_KEY")
]


def generate_chart_code_and_images(input_path, query, file_name, output_dir="charts"):
    """生成图表代码并执行生成图像，增加列名自动适配"""
    result = {
        "code": "",
        "images": [],
        "error": None
    }

    if not input_path or not os.path.exists(input_path):
        result["error"] = f"未提供有效数据文件或文件不存在: {input_path}"
        return result

    try:
        # 先读取数据检查列名
        df = pd.read_csv(input_path)
        column_names = df.columns.tolist()

        chart_code = kimi_code(input_path, query, column_names, api_keys=API_KEYS)

        if "最大重试次数" in chart_code:
            result["error"] = chart_code
            return result

        # 代码预处理：修复已知问题并适配列名
        processed_code = preprocess_chart_code(chart_code, column_names)
        result["code"] = processed_code

        # 使用实际输入路径和自定义输出目录
        output = run_code(processed_code, file_name, input_path, output_dir)

        if output["error"]:
            result["error"] = f"生成图表时出错: {output['error']}"
            return result

        result["images"] = output["images"]
        return result

    except Exception as e:
        result["error"] = f"图表生成过程中发生错误: {str(e)}"
        result["code"] = f"# 错误: {traceback.format_exc()}"
        return result


def kimi_code(input_path: str, query: str, column_names: list, api_keys: list = None):
    """调用KimiAI生成图表代码，支持多密钥轮换和请求控制"""
    if not os.path.exists(input_path):
        raise FileNotFoundError(f"文件不存在: {input_path}")

    # 处理API密钥
    if api_keys is None:
        api_keys = API_KEYS
    api_keys = [k for k in api_keys if k]  # 过滤空密钥
    if not api_keys:
        raise ValueError("未提供有效的API密钥")

    max_retries_per_key = 5
    key_index = 0
    key_attempts = {key: 0 for key in api_keys}
    RETRYABLE_ERRORS = (RateLimitError, APIError)

    directory, filename = os.path.split(input_path)
    name, extension = os.path.splitext(filename)
    new_path = os.path.join(directory, f"{name}_truncated{extension}")
    truncate_file(input_path, new_path, extension[1:])

    file_content = ""
    file_object = None

    while True:
        current_key = api_keys[key_index]
        key_attempts[current_key] += 1
        retry_count = key_attempts[current_key]

        # 控制请求间隔
        _control_request_interval()

        e = None
        try:
            client = OpenAI(
                api_key=current_key,
                base_url="https://api.moonshot.cn/v1",
                timeout=30
            )

            # 上传文件并获取内容（仅首次调用时执行）
            if file_object is None:
                file_object = client.files.create(file=Path(new_path), purpose="file-extract")
                file_content = client.files.content(file_id=file_object.id).text

            # 向Kimi提供列名信息
            column_info = f"数据包含以下列: {', '.join(column_names)}"

            for attempt in range(max_retries_per_key):
                try:
                    messages = [
                        {"role": "system", "content": "你是Kimi。你的回复简洁、专业、高效，并严格遵守用户需求。"},
                        {"role": "system", "content": file_content},
                        {"role": "system", "content": column_info},
                        {"role": "user", "content": (
                                '查看文件中给出的数据，编写Python代码绘制图表，我已经为你引入了"import matplotlib.pyplot as plt、'
                                'import seaborn as sns、import pandas as pd、import numpy as np"，不要使用其他任何import语句。'
                                f'你需要先读取文件内容，文件路径为: "{input_path}"，直接使用此路径而不要再次定义。'
                                '重要的是，不要说其他任何话，直接给我代码！'
                                '解决中文字体显示问题，设置图表的分辨率为300，下面是详细的图表需求：' + query
                        )}
                    ]

                    completion = client.chat.completions.create(
                        model="moonshot-v1-8k",
                        messages=messages,
                        temperature=0.3
                    )
                    answer = completion.choices[0].message.content

                    if '```python\n' in answer and '\n```' in answer:
                        code = answer.split('```python\n', 1)[1].split('\n```', 1)[0]
                        if 'import numpy as np\n\n' in code:
                            code = code.split('import numpy np\n\n', 1)[1]
                        elif 'import numpy as np\n' in code:
                            code = code.split('import numpy np\n', 1)[1]
                        code = code.replace('file_url = "media/upload/xxx.xxx"', '')
                        code = code.replace("file_url = 'media/upload/xxx.xxx'", '')
                        return code
                    return answer

                except RETRYABLE_ERRORS as e:
                    wait_time = min(2 ** (attempt + 1), 60)
                    print(f"API错误，第{attempt + 1}次重试，等待{wait_time}秒...")
                    time.sleep(wait_time)
                except Exception as e:
                    break

            # 切换到下一个密钥
            key_index = (key_index + 1) % len(api_keys)
            key_attempts[current_key] = 0
            print(f"切换到API密钥 {key_index + 1}/{len(api_keys)}")

        except Exception as e:
            error_msg = str(e)
            print(f"API调用失败: {error_msg}")
            if key_index >= len(api_keys) - 1 and key_attempts[current_key] >= max_retries_per_key:
                return f"达到最大重试次数，调用KimiAI接口失败。错误: {error_msg}"

    return "API调用异常，无法生成图表代码"


def preprocess_chart_code(code_str, column_names):
    """预处理Kimi生成的图表代码，修复已知问题并适配列名"""
    code_str = code_str.replace(
        ".pct_change()",
        ".pct_change(fill_method=None)"
    )

    if "melt(" in code_str and "@index" in code_str:
        melt_pattern = r"melt\(([^)]*)\)"
        matches = re.findall(melt_pattern, code_str)
        for match in matches:
            if "@index" in match:
                new_match = match.replace("@index", "季度")
                code_str = code_str.replace(f"melt({match})", f"melt({new_match})")

    if "sns.pie(" in code_str:
        code_str = code_str.replace("sns.pie(", "plt.pie(")

    if "销量" in code_str:
        sales_columns = [col for col in column_names if "销量" in col]
        if sales_columns:
            code_str = code_str.replace("销量", sales_columns[0])

    if "plt.rcParams" not in code_str:
        code_str = (
                "plt.rcParams['font.family'] = ['SimHei', 'WenQuanYi Micro Hei', 'Heiti TC']\n"
                "plt.rcParams['axes.unicode_minus'] = False\n"
                + code_str
        )

    return code_str


def run_code(code_str: str, file_name='', input_path='', output_dir='charts'):
    """执行图表代码并保存图像，支持自定义输出目录"""
    if not file_name or not input_path:
        return {"output": "", "images": [], "error": "未提供文件名或输入路径"}

    input_path = os.path.normpath(input_path)
    if not os.path.exists(input_path):
        return {"output": "", "images": [], "error": f"文件不存在: {input_path}"}

    code_str = code_str.replace('media/upload/xxx.xxx', input_path)
    code_str = code_str.replace('"file_url"', f'"{input_path}"')
    code_str = code_str.replace("'file_url'", f"'{input_path}'")

    old_stdout = sys.stdout
    redirected_output = sys.stdout = io.StringIO()
    result = {"output": "", "images": [], "error": None}

    try:
        global_namespace = {
            "__builtins__": __builtins__,
            "plt": plt,
            "sns": sns,
            "pd": pd,
            "np": np,
        }
        exec(
            "import matplotlib.pyplot as plt\n"
            "import seaborn as sns\n"
            "import pandas as pd\n"
            "import numpy as np\n"
            "from scipy.stats import gaussian_kde\n"
            + code_str, global_namespace)

        plt.rcParams["font.family"] = ["SimHei", "WenQuanYi Micro Hei", "Heiti TC"]
        plt.rcParams["axes.unicode_minus"] = False
        plt.rcParams["figure.dpi"] = 300

        os.makedirs(output_dir, exist_ok=True)

        while len(plt.get_fignums()) > 0:
            fig = plt.figure(plt.get_fignums()[0])
            chart_name = f"{file_name.split('.')[0]}_{len(result['images'])}.png"
            save_path = os.path.join(output_dir, chart_name)
            fig.savefig(save_path)
            result["images"].append(save_path)
            plt.close(fig)

    except Exception as e:
        result["error"] = traceback.format_exc(limit=10)
    finally:
        sys.stdout = old_stdout
        result["output"] = redirected_output.getvalue()
    return result


# 文档生成模块
def create_combined_document(report_content, chart_images, used_files, user_request, user_text, file_content,
                             output_dir="media/reports"):
    """根据用户输入生成唯一命名的文档，并清理Markdown格式"""
    # 调用Kimi生成文档内容，使用多密钥轮换
    client = OpenAI(
        api_key=API_KEYS[0],  # 初始密钥，内部会轮换
        base_url="https://api.moonshot.cn/v1"
    )

    # 生成唯一文件名（时间戳+UUID）
    timestamp = int(time.time())
    unique_id = uuid.uuid4().hex[:8]
    output_filename = f"research_report_{timestamp}_{unique_id}.docx"
    full_path = os.path.join(output_dir, output_filename)

    # 动态生成报告标题
    title_prompt = f"根据以下信息生成报告标题（不超过25字）：\n用户请求：{user_request}\n用户文本：{user_text}\n文件内容摘要：{file_content[:300]}"
    title = _call_kimi(client, title_prompt, max_tokens=25, api_keys=API_KEYS) or "数据分析研究报告"

    # 动态生成研究背景
    background_prompt = f"生成研究背景段落（约200字）：\n用户请求：{user_request}\n用户文本：{user_text}\n文件内容摘要：{file_content[:500]}"
    background = _call_kimi(client, background_prompt, max_tokens=200,
                            api_keys=API_KEYS) or "本研究基于当前行业发展现状，结合数据进行系统性分析。"

    # 动态生成数据来源说明
    data_method_prompt = f"生成数据来源与方法段落（约150字）：\n使用文件：{', '.join([os.path.basename(f) for f in used_files]) if used_files else '无外部文件'}\n文件内容摘要：{file_content[:300]}"
    data_method = _call_kimi(client, data_method_prompt, max_tokens=150,
                             api_keys=API_KEYS) or "本研究数据来源于相关数据源，采用科学方法进行分析。"

    # 动态生成结论建议
    conclusion_prompt = f"根据以下分析结果生成结论与建议（约300字）：\n分析结果：{report_content[:1000]}\n用户关注点：{user_text}"
    conclusion = _call_kimi(client, conclusion_prompt, max_tokens=300,
                            api_keys=API_KEYS) or "综合分析表明，需结合具体数据进一步研究。建议关注相关领域动态。"

    # 清理报告内容中的Markdown格式
    report_content = clean_markdown(report_content)
    background = clean_markdown(background)
    data_method = clean_markdown(data_method)
    conclusion = clean_markdown(conclusion)

    config = [
        {"type": "heading", "text": title, "level": 1, "font_name": "SimHei", "font_size": 28, "bold": True,
         "color": (0, 0, 0), "alignment": "center"},
        {"type": "paragraph", "text": "", "line_spacing": 2.0},
        {"type": "paragraph", "text": f"—— {user_request}", "font_name": "SimHei", "font_size": 16,
         "alignment": "center", "line_spacing": 1.5},
        {"type": "paragraph", "text": f"生成日期: {time.strftime('%Y年%m月%d日')}", "font_name": "SimHei",
         "font_size": 14, "alignment": "center", "line_spacing": 2.0},
        {"type": "paragraph", "text": "", "line_spacing": 2.0},
        {"type": "page_break"},

        {"type": "heading", "text": "目录", "level": 1, "font_name": "SimHei", "font_size": 24, "bold": True,
         "color": (0, 0, 0), "alignment": "center"},
        {"type": "paragraph", "text": "", "line_spacing": 1.5},
        {"type": "list",
         "items": ["1. 研究背景与目的", "2. 数据来源与方法", "3. 数据分析结果", "4. 结论与建议", "5. 数据分析图表"],
         "level": 1, "font_name": "SimSun", "font_size": 14, "line_spacing": 1.5},
        {"type": "page_break"},

        {"type": "heading", "text": "1. 研究背景与目的", "level": 1, "font_name": "SimHei", "font_size": 20,
         "bold": True, "color": (0, 0, 0)},
        {"type": "paragraph", "text": background, "font_name": "SimSun", "font_size": 12, "line_spacing": 1.5},
        {"type": "paragraph", "text": f"本研究旨在{user_request}，通过系统性数据分析揭示相关规律与趋势。",
         "font_name": "SimSun", "font_size": 12, "line_spacing": 1.5},
        {"type": "paragraph", "text": "", "line_spacing": 1.5},

        {"type": "heading", "text": "2. 数据来源与方法", "level": 1, "font_name": "SimHei", "font_size": 20,
         "bold": True, "color": (0, 0, 0)},
        {"type": "paragraph", "text": data_method, "font_name": "SimSun", "font_size": 12, "line_spacing": 1.5},
        {"type": "paragraph", "text": "分析方法包括描述性统计、可视化分析及趋势预测，使用Python工具完成全流程处理。",
         "font_name": "SimSun", "font_size": 12, "line_spacing": 1.5},
        {"type": "paragraph", "text": "", "line_spacing": 1.5},

        {"type": "heading", "text": "2.1 数据文件说明", "level": 2, "font_name": "SimHei", "font_size": 16,
         "bold": True, "color": (0, 0, 0)},
    ]

    if used_files:
        file_list = [f"•  {os.path.basename(file)}" for file in used_files]
        config.append({"type": "list", "items": file_list, "level": 0, "font_name": "SimSun", "font_size": 12,
                       "line_spacing": 1.2})
    else:
        config.append(
            {"type": "paragraph", "text": "本次分析未使用外部数据文件，数据来源于内置基准库。", "font_name": "SimSun",
             "font_size": 12, "line_spacing": 1.5})

    config.extend([
        {"type": "paragraph", "text": "", "line_spacing": 1.5},
        {"type": "heading", "text": "3. 数据分析结果", "level": 1, "font_name": "SimHei", "font_size": 20, "bold": True,
         "color": (0, 0, 0)},
        {"type": "paragraph", "text": report_content, "font_name": "SimSun", "font_size": 12, "line_spacing": 1.5},
        {"type": "paragraph", "text": "", "line_spacing": 1.5},
        {"type": "heading", "text": "4. 结论与建议", "level": 1, "font_name": "SimHei", "font_size": 20, "bold": True,
         "color": (0, 0, 0)},
        {"type": "paragraph", "text": conclusion, "font_name": "SimSun", "font_size": 12, "line_spacing": 1.5},
        {"type": "paragraph", "text": "", "line_spacing": 2.0},
        {"type": "heading", "text": "5. 数据分析图表", "level": 1, "font_name": "SimHei", "font_size": 20, "bold": True,
         "color": (0, 0, 0)},
    ])

    if chart_images:
        config.append(
            {"type": "paragraph", "text": "本研究生成以下数据分析图表，直观展示关键指标与趋势：", "font_name": "SimSun",
             "font_size": 12, "line_spacing": 1.5})
        for i, img_path in enumerate(chart_images):
            config.append({"type": "image", "path": img_path, "width": 6, "caption": f"图 {i + 1}. 数据分析可视化结果"})
            config.append({"type": "paragraph", "text": "", "line_spacing": 1.5})
    else:
        config.append(
            {"type": "paragraph", "text": "本次分析未生成可视化图表，数据结果已通过文字描述呈现。", "font_name": "SimSun",
             "font_size": 12, "line_spacing": 1.5})

    save_to_word(config, full_path)
    return full_path, output_filename


def clean_markdown(text):
    """清理文本中的Markdown格式"""
    if not text:
        return ""

    # 移除常见Markdown格式
    text = re.sub(r'\*{1,2}([^*]+)\*{1,2}', r'\1', text)  # 移除*斜体*和**粗体**
    text = re.sub(r'_{1,2}([^_]+)_{1,2}', r'\1', text)  # 移除_斜体_和__粗体__
    text = re.sub(r'`([^`]+)`', r'\1', text)  # 移除`代码`
    text = re.sub(r'^#{1,6}\s', '', text, flags=re.M)  # 移除标题标记
    text = re.sub(r'^\s*[-*+]\s', '', text, flags=re.M)  # 移除无序列表标记
    text = re.sub(r'^\d+\.\s', '', text, flags=re.M)  # 移除有序列表标记
    text = re.sub(r'!\[.*?\]\(.*?\)', '', text)  # 移除图片
    text = re.sub(r'\[.*?\]\(.*?\)', '', text)  # 移除链接

    # 规范化换行符
    text = re.sub(r'\n{3,}', '\n\n', text)  # 合并多个空行

    return text.strip()


def _call_kimi(client, prompt, max_tokens=200, api_keys=None):
    """调用Kimi API的通用方法，包含多密钥轮换和重试机制"""
    if api_keys is None:
        api_keys = API_KEYS
    api_keys = [k for k in api_keys if k]  # 过滤空密钥
    if not api_keys:
        return None

    max_retries_per_key = 5
    key_index = 0
    key_attempts = {key: 0 for key in api_keys}
    RETRYABLE_ERRORS = (RateLimitError, APIError)

    while True:
        current_key = api_keys[key_index]
        key_attempts[current_key] += 1
        retry_count = key_attempts[current_key]

        # 控制请求间隔
        _control_request_interval()

        e = None
        try:
            client.api_key = current_key
            completion = client.chat.completions.create(
                model="moonshot-v1-8k",
                messages=[{"role": "user", "content": prompt}],
                temperature=0.5,
                max_tokens=max_tokens
            )
            return completion.choices[0].message.content.strip()

        except RETRYABLE_ERRORS as e:
            error_code = e.http_status if hasattr(e, 'http_status') else "N/A"
            error_msg = str(e)
            if retry_count < max_retries_per_key:
                wait_time = min(2 ** (retry_count), 60)
                print(f"API错误 {error_code}，第{retry_count}次重试，等待{wait_time}秒...")
                time.sleep(wait_time)
                continue
            else:
                print(f"密钥 {key_index + 1}/{len(api_keys)} 达到最大重试次数: {error_msg}")

        except Exception as e:
            print(f"API调用异常: {str(e)}")

        # 切换到下一个密钥
        key_index = (key_index + 1) % len(api_keys)
        key_attempts[current_key] = 0
        print(f"切换到API密钥 {key_index + 1}/{len(api_keys)}")

        if key_index == 0:
            print("所有密钥均已尝试，返回空结果")
            return None


def save_to_word(config, filename):
    doc = Document()
    for element in config:
        element_type = element.get("type", "paragraph")
        if element_type == "paragraph":
            _process_paragraph(doc, element)
        elif element_type == "image":
            _process_image(doc, element)
        elif element_type == "list":
            _process_list(doc, element)
        elif element_type == "heading":
            _process_heading(doc, element)
        elif element_type == "page_break":
            doc.add_page_break()
    doc.save(filename)


def _process_paragraph(doc, config):
    text = config.get("text", "")
    if not text:
        return
    para = doc.add_paragraph()
    run = para.add_run(text)
    _set_font(run, config)
    alignment = config.get("alignment")
    if alignment:
        align_map = {
            "left": WD_PARAGRAPH_ALIGNMENT.LEFT,
            "center": WD_PARAGRAPH_ALIGNMENT.CENTER,
            "right": WD_PARAGRAPH_ALIGNMENT.RIGHT,
            "justify": WD_PARAGRAPH_ALIGNMENT.JUSTIFY,
        }
        para.paragraph_format.alignment = align_map.get(alignment.lower(), WD_PARAGRAPH_ALIGNMENT.LEFT)
    if config.get("indent") is not None:
        para.paragraph_format.first_line_indent = Pt(config.get("indent"))
    if config.get("line_spacing") is not None:
        para.paragraph_format.line_spacing = config.get("line_spacing")


def _process_image(doc, config):
    path = config.get("path")
    if not path:
        return
    width = Inches(config.get("width", 6))
    height = Inches(config.get("height")) if config.get("height") else None
    doc.add_picture(path, width=width, height=height)
    caption = config.get("caption")
    if caption:
        para = doc.add_paragraph()
        run = para.add_run(caption)
        run.font.italic = True
        para.alignment = WD_PARAGRAPH_ALIGNMENT.CENTER
        _set_font(run, {"font_name": "SimSun"})


def _process_list(doc, config):
    items = config.get("items", [])
    if not items:
        return
    level = config.get("level", 0)
    level = max(0, min(9, level))
    for item in items:
        p = doc.add_paragraph()
        p.add_run(item)
        p.paragraph_format.left_indent = Pt(18 * level)
        p.style = "List Bullet"
        _set_font(p.runs[0], config)


def _process_heading(doc, config):
    text = config.get("text", "")
    if not text:
        return
    level = config.get("level", 1)
    heading = doc.add_heading(text, level=level)
    for run in heading.runs:
        _set_font(run, config)


def _set_font(run, config):
    font = run.font
    font_name = config.get("font_name", "SimSun")
    font.name = font_name
    run._element.rPr.rFonts.set(qn("w:eastAsia"), font_name)
    font_size = config.get("font_size")
    if font_size is not None:
        font.size = Pt(font_size)
    color = config.get("color")
    if color:
        font.color.rgb = RGBColor(*color)
    font.bold = config.get("bold", False)
    font.italic = config.get("italic", False)
    font.underline = config.get("underline", False)


def split_text_into_paragraphs(text, max_chars=800):
    if not text:
        return ["无报告内容"]
    sentences = []
    current_sentence = ""
    for char in text:
        current_sentence += char
        if char in ['.', '?', '!', '！', '。', '？'] and len(current_sentence) > 100:
            sentences.append(current_sentence.strip())
            current_sentence = ""
    if current_sentence:
        sentences.append(current_sentence.strip())

    paragraphs = []
    current_para = ""
    for sentence in sentences:
        if len(current_para) + len(sentence) > max_chars or not current_para:
            if current_para:
                paragraphs.append(current_para)
            current_para = sentence
        else:
            current_para += " " + sentence
    if current_para:
        paragraphs.append(current_para)
    return paragraphs


# 辅助函数：控制请求间隔
def _control_request_interval():
    global LAST_REQUEST_TIME, MIN_REQUEST_INTERVAL
    current_time = time.time()
    if current_time - LAST_REQUEST_TIME < MIN_REQUEST_INTERVAL:
        wait_time = MIN_REQUEST_INTERVAL - (current_time - LAST_REQUEST_TIME)
        print(f"等待 {wait_time:.2f} 秒以满足请求间隔要求...")
        time.sleep(wait_time)
    LAST_REQUEST_TIME = time.time()


def truncate_file(source_path: str, target_path: str, file_type: str):
    """截断大文件"""
    try:
        if file_type.lower() in ['csv', 'txt', 'tsv']:
            with open(source_path, 'r', encoding='utf-8') as f:
                lines = f.readlines()
            if len(lines) > 200:
                lines = lines[:200] + ["[文件内容已截断，仅保留前200行]"]
            with open(target_path, 'w', encoding='utf-8') as f:
                f.writelines(lines)
        else:
            with open(source_path, 'rb') as f_source, open(target_path, 'wb') as f_target:
                content = f_source.read(10 * 1024 * 1024)
                f_target.write(content)
                truncated_mark = "[文件内容已截断]".encode('utf-8')
                f_target.write(truncated_mark)
    except Exception:
        with open(source_path, 'rb') as f_source, open(target_path, 'wb') as f_target:
            f_target.write(f_source.read())


# 主处理函数
def process_user_request(user_text, file_path, research_request, chart_query, api_keys, output_dir="media", request=None):
    """处理用户请求的主函数，整合文本分析、图表生成和文档创建"""
    print("开始处理用户请求...")

    report_result = generate_research_report(
        user_text=user_text,
        file_path=file_path,
        request=research_request,
        api_keys=api_keys
    )

    if report_result["error"]:
        print(f"报告生成失败: {report_result['error']}")
        return None, None, report_result["error"]

    chart_images = []
    file_name = os.path.basename(file_path) if file_path else None

    if file_path and chart_query:
        print("正在生成数据分析图表...")
        chart_result = generate_chart_code_and_images(
            input_path=file_path,
            query=chart_query,
            file_name=file_name,
            output_dir=output_dir
        )

        if chart_result["error"]:
            print(f"图表生成失败: {chart_result['error']}")
        else:
            chart_images = chart_result["images"]
            print(f"成功生成 {len(chart_images)} 张图表")
    else:
        print("跳过图表生成：未提供文件或图表查询")

    file_content = ""
    if file_path and os.path.exists(file_path):
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                file_content = f.read(1000)  # 读取前1000字作为摘要
        except:
            file_content = f"[文件内容读取失败：{os.path.basename(file_path)}]"

    print("正在创建整合文档...")
    output_dir = os.path.join(settings.MEDIA_ROOT, 'reports')
    os.makedirs(output_dir, exist_ok=True)

    # 调用文档生成函数，获取完整路径和文件名
    doc_path, doc_filename = create_combined_document(
        report_content=report_result["report"],
        chart_images=chart_images,
        used_files=report_result["used_files"],
        user_request=research_request,
        user_text=user_text,
        file_content=file_content,
        output_dir=output_dir
    )

    print(f"处理完成！文档已保存至: {doc_path}")

    if doc_path and doc_filename:
        try:
            title = extract_title_from_request(research_request)
            current_user = User.objects.get(username=request.session.get('username'))
            save_document_record(doc_path, doc_filename, title, user=current_user, request=request)
        except Exception as e:
            print(f"文档记录保存失败: {str(e)}")

    return doc_path, doc_filename, None


def extract_title_from_request(request_text):
    """从研究请求中提取标题"""
    if not request_text:
        return f"数据分析报告 - {time.strftime('%Y%m%d%H%M')}"

    # 去除前后空格
    request_text = request_text.strip()

    # 提取"分析XXX"或"研究XXX"作为关键词
    match = re.search(r'(分析|研究)\s*([^\s，。；]+)', request_text)
    key_word = match.group(2) if match else request_text[:20]

    # 构造标题
    title = f"关于{key_word}的研究报告"

    # 标题长度限制
    return title[:50] or f"数据分析报告 - {time.strftime('%Y%m%d%H%M')}"


def save_document_record(file_path, file_name, title, user, request=None):
    """保存文档记录到数据库，增加对request的安全检查"""
    session_key = None
    if request and hasattr(request, 'session'):
        session_key = request.session.session_key

    UserDocument.objects.create(
        user=user,
        session_key=session_key,
        file_name=file_name,
        file_path=file_path,
        title=title
    )