from django.shortcuts import render, reverse, redirect, HttpResponse
from django.core.files.storage import FileSystemStorage
from openai import OpenAI, APIError, AuthenticationError, RateLimitError
from docx import Document
import matplotlib.pyplot as plt
import matplotlib
matplotlib.use('Agg')
from .cw_2_tools import *
from django.utils import timezone

# Create your views here.
def CW_INDEX_LIST():
    """
    图表知识信息列表
    :return: 内含字典的顺序列表，存储了所有图面网页信息
    """
    return [
        {
            "id": 1,
            "name": '快速 AI 数据分析',
            "info": '快速生成简单的数据分析图表，帮助用户快速了解数据趋势和分布情况。',
            'cw_url': 1,
            "img": 'cw_1.png',
            'LoginRequired': False,
        },
        {
            "id": 2,
            "name": '数据分析文档生成',
            "info": '一键生成带有数据分析结果和图表的文档，帮助用户快速了解数据趋势和分布情况。',
            'cw_url': 2,
            "img": 'cw_2.png',
            'LoginRequired': True,
        },
    ]


def Workbench(request):
    # 获取URL中的id参数，默认为0
    cw_id = request.GET.get('id', '0')

    # 存储当前页面URL到会话中
    request.session['page'] = reverse('CreativeWorkshop:Workbench') + f'?id={cw_id}'
    user = {
        'nickname': request.session.get('nickname', ''),
        'username': request.session.get('username', ''),
        'role': request.session.get('role', 0)
    }
    print(user)

    try:
        # 尝试将id转换为整数
        cw_id = int(cw_id)
    except ValueError:
        # ID不是整数时跳转到搜索页面
        print('ID格式错误，跳转到搜索页面')
        search_url = reverse('Knowledge:Search') + f'?word=未知的创意工坊ID:{cw_id}'
        return redirect(search_url)

    # 新增逻辑：验证cw_id是否存在于CW_INDEX_LIST中
    cw_exists = False
    for item in CW_INDEX_LIST():
        if item.get('cw_url') == cw_id:
            cw_exists = True
            break

    if not cw_exists:
        print('ID未找到，跳转到搜索页面')
        search_url = reverse('Knowledge:Search') + f'?word=未知的创意工坊ID:{cw_id}'
        return redirect(search_url)

    if cw_id == 1:
        return redirect(reverse('CreativeWorkshop:CW_1'))
    elif cw_id == 2:
        return redirect(reverse('CreativeWorkshop:CW_2'))

    # 处理其他ID的逻辑
    print('ID未找到，跳转到搜索页面')
    search_url = reverse('Knowledge:Search') + f'?word=未知的创意工坊ID:{cw_id}'
    return redirect(search_url)


def Index(request):
    request.session['page'] = reverse('CreativeWorkshop:Index')
    user = {
        'nickname': request.session.get('nickname', ''),
        'username': request.session.get('username', ''),
        'role': request.session.get('role', 0)
    }
    print(user)
    return render(request, 'CreativeWorkshop_Index.html', {'user': user, 'index_list': CW_INDEX_LIST()})


def kimi_write(input_path: str, query: str):
    # 检查文件是否存在
    if not os.path.exists(input_path):
        raise FileNotFoundError(f"指定的文件路径不存在：{input_path}")

    # 初始化OpenAI客户端
    client = OpenAI(
        api_key="请替换为您的API_KEY",  # 替换为你的Kimi开放平台API Key
        base_url="https://api.moonshot.cn/v1"  # Kimi开放平台的API地址
    )

    max_retries = 10  # 最大重试次数
    wait_i = 0  # 指数级等待时间参数 i
    read_rows_flag = 0

    for attempt in range(max_retries):
        try:
            # 截取文件
            directory, filename = os.path.split(input_path)
            name, extension = os.path.splitext(filename)
            new_filename = f"{name}_truncated{extension}"
            new_path = os.path.join(directory, new_filename)
            truncate_file(input_path, new_path, nrows=read_rows_flag, ncols=None, file_type='csv')

            # 上传文件并获取文件内容
            file_object = client.files.create(file=Path(new_path), purpose="file-extract")
            file_content = client.files.content(file_id=file_object.id).text

            # 构造消息内容
            messages = [
                {
                    "role": "system",
                    "content": "你是Kimi。你的回复简洁、专业、高效，并严格遵守用户需求。"
                },
                {
                    "role": "system",
                    "content": file_content  # 将文件内容作为系统提示词的一部分
                },
                {
                    "role": "user",
                    "content": (
                            "查看文件中给出的数据，写短篇论文，内容从数据分析的角度对其进行简单的特征描述（比如最值、极值、平均数之类）。" +
                            "需求：用python中的列表的形式返回结果，下标为0的是标题，剩下的是每个段落，比如：result = ['标题', '字段1', '字段2']。" +
                            "注意：不要分点回答，不写公式但可以写数据，应该像论文一样总结成几段。以下简单描述实验内容：" + query
                    )
                }
            ]
            # 调用chat-completion接口获取Kimi的回答
            completion = client.chat.completions.create(
                model="moonshot-v1-8k",
                messages=messages,
                temperature=0.3
            )
            answer = completion.choices[0].message.content
            # 使用 re 提取列表
            pattern = r"result = \[(.*?)\]"
            match = re.search(pattern, answer, re.DOTALL)
            if match:
                result_str = match.group(1)
                result = [s.strip().strip("'").strip('"') for s in result_str.split(',')]
            else:
                result = ['信息返回失败', '请稍后重试。']
            return [result[0], result[1:]]
        except Exception as e:
            print(f"调用KimiAI接口失败（尝试 {attempt + 1}/{max_retries}）：{e}")
            if attempt < max_retries - 1:  # 如果不是最后一次尝试
                retry_delay = 2 ** wait_i
                wait_i += 1
                read_rows_flag = 200
                print(f"等待 {retry_delay} 秒后重试...")
                time.sleep(retry_delay)
            else:
                print("达到最大重试次数，调用KimiAI接口失败。")
                return "达到最大重试次数，调用KimiAI接口失败。"


def CW_1(request):
    # 获取用户会话信息
    user = {
        'nickname': request.session.get('nickname', ''),
        'username': request.session.get('username', ''),
        'role': request.session.get('role', 0)
    }
    print(user)

    if request.method == 'GET':
        data_file = request.session.get("data_file", "NULL")
        if data_file == "NULL":
            return render(request, 'CreativeWorkshop_CW_1.html', context={'user': user})
        else:
            return render(request, 'CreativeWorkshop_CW_1_Quickly.html', context={'user': user, 'file_name': os.path.join('media/upload/', data_file).split("/")[-1].split("\\")[-1]})

    elif request.method == 'POST':
        if 're-upload' in request.POST:
            request.session['data_file'] = "NULL"
            request.session['chart_file'] = 'NULL'
            return render(request, 'CreativeWorkshop_CW_1.html', context={'user': user})

        if 'upload_file' in request.POST:
            request.session['chart_file'] = 'NULL'
            file = request.FILES.get('file', None)
            if file:
                ext = file.name.split('.')[-1].lower()
                if ext not in ["csv", "xlsx"]:
                    return render(request, 'CreativeWorkshop_CW_1.html', context={'user': user})

                fs = FileSystemStorage(location=os.path.join(settings.MEDIA_ROOT, 'upload'))
                filename = f"UserUpload.{ext}"
                file_path = os.path.join(settings.MEDIA_ROOT, 'upload', filename)
                fs.save(filename, file)
                request.session['data_file'] = file_path
            else:
                return render(request, 'CreativeWorkshop_CW_1.html', context={'user': user})

        file_path = request.session.get("data_file", "NotFound")
        charts_path = request.session.get("chart_file", "NotFound")

        if file_path == "NotFound" or file_path == "NULL":
            return render(request, 'CreativeWorkshop_CW_1_Show.html', context={'user': user})

        input_text = request.POST.get('input', '似乎忘记了实验内容，简单分析吧。')
        text_list = kimi_write(os.path.join('media/upload/', file_path), input_text)
        print("Notice: 调用KimiAI: Successfully 加载成功")
        return render(request, 'CreativeWorkshop_CW_1_Show.html', context={'user': user, 'charts_path': charts_path , 'text_list': text_list})


# Django视图函数
def CW_2(request):
    # 获取用户会话信息
    user = {
        'nickname': request.session.get('nickname', ''),
        'username': request.session.get('username', ''),
        'role': request.session.get('role', 0)
    }

    # 获取或初始化会话中的分析状态
    if 'analysis_state' not in request.session:
        request.session['analysis_state'] = {
            'data_file': None,
            'report_generated': False,
            'error_message': None,
            'generated_docs': []  # 记录生成的文档列表
        }

    analysis_state = request.session['analysis_state']

    if request.method == 'GET':
        # 检查是否有上传的文件

        # 加载历史文档
        history_docs = []
        if User.objects.filter(username=request.session.get('username')).exists():
            # 用户已登录，查询关联的文档记录，只搜索最近一小时内的文档
            one_hour_ago = timezone.now() - timezone.timedelta(hours=24)
            history_docs = UserDocument.objects.filter(user=request.session.get('username'), generate_time__gte=one_hour_ago).values(
                'id', 'file_name', 'file_path', 'title', 'generate_time'
            )


        if analysis_state['data_file']:
            file_name = os.path.basename(analysis_state['data_file'])
            return render(request, 'CreativeWorkshop_CW_2.html',
                          context={'user': user, 'file_name': file_name, 'history_docs': history_docs})
        else:
            return render(request, 'CreativeWorkshop_CW_2.html',
                          context={'user': user, 'history_docs': history_docs})

    elif request.method == 'POST':
        # 加载历史文档
        history_docs = []
        if User.objects.filter(username=request.session.get('username')).exists():
            # 用户已登录，查询关联的文档记录，只搜索最近一小时内的文档
            one_hour_ago = timezone.now() - timezone.timedelta(hours=24)
            history_docs = UserDocument.objects.filter(user=request.session.get('username'),
                                                       generate_time__gte=one_hour_ago).values(
                'id', 'file_name', 'file_path', 'title', 'generate_time'
            )

        print("历史文档：", history_docs)

        # 处理重新上传请求
        if 're-upload' in request.POST:
            analysis_state['data_file'] = None
            analysis_state['report_generated'] = False
            analysis_state['error_message'] = None
            analysis_state['generated_docs'] = []  # 清空文档列表
            request.session['analysis_state'] = analysis_state
            return render(request, 'CreativeWorkshop_CW_2.html',
                          context={'user': user, 'history_docs': history_docs})

        # 处理文件上传
        if 'upload_file' in request.POST:
            file = request.FILES.get('file_path', None)
            #用户未登录，不可以上传文件
            if not request.session.get('username'):
                print("请登录后上传文件")
                analysis_state['error_message'] = "请先登录"
                request.session['analysis_state'] = analysis_state
                return render(request, 'CreativeWorkshop_CW_2.html',
                              context={'user': user, 'error': analysis_state['error_message'],
                                       'history_docs': history_docs})

            elif file:
                ext = file.name.split('.')[-1].lower()
                if ext not in ["csv", "xlsx", "txt"]:
                    analysis_state['error_message'] = "不支持的文件格式，请上传CSV、Excel或TXT文件"
                    request.session['analysis_state'] = analysis_state
                    return render(request, 'CreativeWorkshop_CW_2.html',
                                  context={'user': user, 'error': analysis_state['error_message'], 'history_docs': history_docs})

                # 保存上传的文件
                fs = FileSystemStorage(location=os.path.join(settings.MEDIA_ROOT, 'upload'))
                filename = f"analysis_{int(time.time())}.{ext}"
                file_path = fs.path(filename)
                fs.save(filename, file)

                # 更新会话状态
                analysis_state['data_file'] = file_path
                analysis_state['report_generated'] = False
                analysis_state['error_message'] = None
                request.session['analysis_state'] = analysis_state

                return render(request, 'CreativeWorkshop_CW_2.html',
                              context={'user': user, 'file_name': filename, 'history_docs': history_docs})
            else:
                analysis_state['error_message'] = "请选择要上传的文件"
                request.session['analysis_state'] = analysis_state
                return render(request, 'CreativeWorkshop_CW_2.html',
                              context={'user': user, 'error': analysis_state['error_message'], 'history_docs': history_docs})

        # 处理分析请求
        file_path = analysis_state.get('data_file')
        if not file_path or not os.path.exists(file_path):
            analysis_state['error_message'] = "找不到上传的数据文件"
            request.session['analysis_state'] = analysis_state
            return render(request, 'CreativeWorkshop_CW_2.html',
                          context={'user': user, 'error': analysis_state['error_message'], 'history_docs': history_docs})

        # 获取表单数据
        user_text = request.POST.get('user_text', '')
        research_request = request.POST.get('research_request', '')
        chart_query = request.POST.get('chart_query', '')

        if not research_request:
            analysis_state['error_message'] = "请提供研究请求内容"
            request.session['analysis_state'] = analysis_state
            return render(request, 'CreativeWorkshop_CW_2.html',
                          context={'user': user, 'error': analysis_state['error_message'], 'history_docs': history_docs})

        # 获取API密钥
        api_key_list = [
            os.getenv("KIMI_API_KEY1", "请替换为您的API_KEY"),
            os.getenv("KIMI_API_KEY2", "请替换为您的API_KEY"),
            os.getenv("KIMI_API_KEY3", "请替换为您的API_KEY")
        ]

        # 处理用户请求，传递request参数
        output_dir = os.path.join(settings.MEDIA_ROOT, 'reports')
        os.makedirs(output_dir, exist_ok=True)

        doc_path, doc_filename, error = process_user_request(
            user_text=user_text,
            file_path=file_path,
            research_request=research_request,
            chart_query=chart_query,
            api_keys=api_key_list,
            output_dir=output_dir,
            request=request  # 传递request参数
        )

        if error:
            analysis_state['error_message'] = f"分析失败: {error}"
            analysis_state['report_generated'] = False
            request.session['analysis_state'] = analysis_state
            return render(request, 'CreativeWorkshop_CW_2.html',
                          context={'user': user, 'error': analysis_state['error_message'], 'history_docs': history_docs})

        # 更新会话状态
        analysis_state['report_generated'] = True
        analysis_state['report_path'] = doc_path
        analysis_state['report_filename'] = doc_filename  # 保存文件名
        analysis_state['error_message'] = None
        analysis_state['generated_docs'].append(doc_filename)  # 记录生成的文档
        request.session['analysis_state'] = analysis_state

        # 提取报告预览
        report_content = "无法提取报告预览内容"
        try:
            doc = Document(doc_path)
            preview = []
            max_paragraphs = 5
            for i, para in enumerate(doc.paragraphs):
                if i >= max_paragraphs:
                    break
                preview.append(para.text)
            report_content = "\n\n".join(preview)
        except Exception:
            pass

        # 查找图表
        chart_images = []
        try:
            for file in os.listdir(output_dir):
                if file.lower().endswith(('.png', '.jpg', '.jpeg')):
                    chart_images.append(os.path.join(output_dir, file))
        except Exception:
            pass

        return render(request, 'CreativeWorkshop_CW_2.html',
                      context={
                          'user': user,
                          'report_path': doc_path,
                          'report_filename': doc_filename,
                          'report_content': report_content,
                          'chart_images': chart_images,
                          'media_url': settings.MEDIA_URL,
                          'generated_docs': analysis_state['generated_docs'],
                          'history_docs': history_docs
                      })