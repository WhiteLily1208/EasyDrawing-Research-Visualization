from django.apps import AppConfig


class CreativeworkshopConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'CreativeWorkshop'
