# models.py
from django.db import models
from django.contrib.auth.models import User
from django.utils.timezone import now
import os
from EasyDrawing import settings


class UserDocument(models.Model):
    user= models.ForeignKey('User.User', on_delete=models.SET_NULL, null=True, db_column='username', to_field="username")
    session_key = models.CharField(max_length=40, null=True, blank=True)  # 未登录用户会话标识
    file_name = models.CharField(max_length=255)
    file_path = models.FilePathField(path=os.path.join(settings.MEDIA_ROOT, 'reports'))
    title = models.CharField(max_length=100, blank=True)
    generate_time = models.DateTimeField(default=now)

    def __str__(self):
        return self.title or self.file_name

    class Meta:
        ordering = ['-generate_time']  # 按生成时间倒序排列
        unique_together = ('user', 'file_name')  # 避免同一用户生成同名文档


# 信号处理：用户删除时清理无主文档
from django.db.models.signals import post_delete
from django.dispatch import receiver


@receiver(post_delete, sender=User)
def delete_user_documents(sender, instance, **kwargs):
    UserDocument.objects.filter(user=instance).delete()