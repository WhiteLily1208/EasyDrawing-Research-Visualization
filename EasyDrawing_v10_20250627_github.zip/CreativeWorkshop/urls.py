from django.urls import path
from . import views

app_name = 'CreativeWorkshop'

urlpatterns = [
    path('', views.Index, name='Index'), # 首页
    path('Workbench/', views.Workbench, name='Workbench'), # 工作台重定向
    path('CW_1/', views.CW_1, name='CW_1'), # 1
    path('CW_2/', views.CW_2, name='CW_2'), # 1
]