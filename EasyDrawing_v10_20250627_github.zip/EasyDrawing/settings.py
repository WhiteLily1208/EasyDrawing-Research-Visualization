"""
EasyDrawing 项目的 Django 设置。

由 Django -admin startproject 使用 Django 5.1.7 生成。

有关此文件的详细信息，请参见
https://docs.djangoproject.com/en/5.1/topics/settings/

有关设置及其值的完整列表，请参见
https://docs.djangoproject.com/en/5.1/ref/settings/
"""

import os
from pathlib import Path


# 像这样在项目内部构建路径：BASE_DIR / 'subdir'。
BASE_DIR = Path(__file__).resolve().parent.parent


# 快速启动开发设置 - 不适合生产
# 参见https://docs.djangoproject.com/en/5.1/howto/deployment/checklist/


# 安全警告：将生产中使用的密钥保密！
SECRET_KEY = 'django-insecure-_3(apxr)-fcf-p0b@^#c%08r$$mcp#6l%%@*xv)9ddu)3-hbq#'


# 安全警告：不要在生产环境中打开调试开关运行！
DEBUG = True

ALLOWED_HOSTS = ['*']


# <frame> <iframe> <embed> 或 <object> 网页只允许在同源（即相同域名）的页面中被嵌套显示
X_FRAME_OPTIONS = 'SAMEORIGIN'


# Application definition 应用定义

INSTALLED_APPS = [
    'django.contrib.admin',
    'django.contrib.auth',
    'django.contrib.contenttypes',
    'django.contrib.sessions',
    'django.contrib.messages',
    'django.contrib.staticfiles',
    'Knowledge',
    'User',
    'Chart',
    'Forum',
    'Staff',
    'CreativeWorkshop',
]

MIDDLEWARE = [
    'django.middleware.security.SecurityMiddleware',
    'django.contrib.sessions.middleware.SessionMiddleware',
    'django.middleware.common.CommonMiddleware',
    'django.middleware.csrf.CsrfViewMiddleware',
    'django.contrib.auth.middleware.AuthenticationMiddleware',
    'django.contrib.messages.middleware.MessageMiddleware',
    'django.middleware.clickjacking.XFrameOptionsMiddleware',
]

ROOT_URLCONF = 'EasyDrawing.urls'

TEMPLATES = [
    {
        'BACKEND': 'django.template.backends.django.DjangoTemplates',
        'DIRS': [os.path.join(BASE_DIR, 'templates')],
        'APP_DIRS': True,
        'OPTIONS': {
            'context_processors': [
                'django.template.context_processors.debug',
                'django.template.context_processors.request',
                'django.contrib.auth.context_processors.auth',
                'django.contrib.messages.context_processors.messages',
                'django.template.context_processors.media',
            ],
        },
    },
]

WSGI_APPLICATION = 'EasyDrawing.wsgi.application'


# Databases 数据库
# https://docs.djangoproject.com/en/5.1/ref/settings/#databases

DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.mysql',
        'NAME': 'easydrawing',
        'USER': 'root',
        'PASSWORD': '123456',
        'HOST': 'localhost',
        'PORT': '3306',
    }
}


# Password validation 密码验证
# https://docs.djangoproject.com/en/5.1/ref/settings/#auth-password-validators

AUTH_PASSWORD_VALIDATORS = [
    {
        'NAME': 'django.contrib.auth.password_validation.UserAttributeSimilarityValidator',
    },
    {
        'NAME': 'django.contrib.auth.password_validation.MinimumLengthValidator',
    },
    {
        'NAME': 'django.contrib.auth.password_validation.CommonPasswordValidator',
    },
    {
        'NAME': 'django.contrib.auth.password_validation.NumericPasswordValidator',
    },
]


# 国际化
# https://docs.djangoproject.com/en/5.1/topics/i18n/

LANGUAGE_CODE = 'zh-hans'

TIME_ZONE = 'Asia/Shanghai'

USE_I18N = True

USE_TZ = False


# Static files (CSS, JavaScript, Images) 静态文件
# https://docs.djangoproject.com/en/5.1/howto/static-files/

STATIC_URL = 'static/'

STATIC_ROOT = os.path.join(BASE_DIR, 'static')

STATICFILES_DIRS = (
    ("bootstrap-5.3.0-alpha1-dist", os.path.join(STATIC_ROOT, 'bootstrap-5.3.0-alpha1-dist')),
    ("bootstrap-icons-1.11.3", os.path.join(STATIC_ROOT, 'bootstrap-icons-1.11.3')),
    ("codemirror-5.65.2", os.path.join(STATIC_ROOT, 'codemirror-5.65.2')),
    ("ace-1.4.12", os.path.join(STATIC_ROOT, 'ace-1.4.12')),
    ("img", os.path.join(STATIC_ROOT, 'img')),
    ("css", os.path.join(STATIC_ROOT, 'css')),
    ("js", os.path.join(STATIC_ROOT, 'js')),
    ("sample-data", os.path.join(STATIC_ROOT, 'sample-data')),
    ("bootstrap-3.4.1-dist", os.path.join(STATIC_ROOT, 'bootstrap-3.4.1-dist')),
)

MEDIA_URL = 'media/'

MEDIA_ROOT = os.path.join(BASE_DIR, 'media')

# Default primary key field type 默认主键字段类型
# https://docs.djangoproject.com/en/5.1/ref/settings/#default-auto-field

DEFAULT_AUTO_FIELD = 'django.db.models.BigAutoField'
