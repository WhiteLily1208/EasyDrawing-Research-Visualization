import os
from django.core.files.storage import FileSystemStorage
from django.shortcuts import render, reverse, redirect
from EasyDrawing import settings
from .models import Article, Comment
from User.models import User


# Create your views here.
def Index(request):
    # 获取请求中的分页参数
    pages = int(request.GET.get("pages", 1))
    request.session['page'] = reverse('Forum:Index') + "?pages=" + str(pages)

    # 获取用户会话信息
    user = {
        'nickname': request.session.get('nickname', ''),
        'username': request.session.get('username', ''),
        'role': request.session.get('role', 0)
    }
    username = user.get('username', '')
    nickname = user.get('nickname', '')
    administrator = user.get('role', '')

    # 显示文章
    start_article = (pages - 1) * 10
    articles = Article.objects.all().order_by('-id')[start_article:start_article + 10]

    # 查询文章数据
    count_article = Article.objects.count()

    count_pages = (count_article + 9) // 10
    if count_pages == 0:
        pages_list = [0, 0, 0, 0, 0, 0, count_pages]
    elif count_pages == 1:
        pages_list = [pages, 0, 0, 1, 0, 0, count_pages]
    elif count_pages == 2:
        if pages == 1:
            pages_list = [pages, 0, 1, 2, 0, 2, count_pages]
        else:
            pages_list = [pages, 1, 1, 2, 0, 0, count_pages]
    else:
        pages_list = [pages, pages - 1, pages - 1, pages, pages + 1, pages + 1, count_pages]

    print("Notice: 第", pages, "页，共", count_pages, "页")

    # 准备传递给模板的上下文
    context = {
        'user': user,
        'username': username,
        'nickname': nickname,
        'administrator': administrator,
        'data': articles,
        'pages': pages_list,
    }

    return render(request, 'Forum_Index.html', context)


def Detail(request):
    request.session['page'] = reverse('Forum:Detail') + '?id=' + str(request.GET.get('id', -1))

    # 获取用户会话信息
    user = {
        'nickname': request.session.get('nickname', ''),
        'username': request.session.get('username', ''),
        'role': request.session.get('role', 0)
    }
    username = user.get('username', '')
    nickname = user.get('nickname', '')
    administrator = user.get('role', '')

    if request.method == 'GET':
        # 获取文章详情
        try:
            article_id = request.GET.get('id', -1)
            article = Article.objects.get(id=article_id)
        except Exception as e:
            return redirect(reverse('Knowledge:Search') + '?word=未知的文章ID:' + str(request.GET.get('id', -1)))

        # 获取评论
        comments = Comment.objects.filter(article=article).order_by('-created_at')

        return render(request, 'Forum_Detail.html', {
            'user': user,
            'username': username,
            'nickname': nickname,
            'administrator': administrator,
            'article_data': article,
            'comments': comments
        })

    elif request.method == 'POST':
        print(request.POST)
        if username == "":
            return redirect('User:login')
        user = User.objects.get(username=username)

        try:
            article_id = request.GET.get('id', -1)
            article = Article.objects.get(id=article_id)
        except Exception as e:
            return redirect(reverse('Knowledge:Search') + '?word=未知的文章ID:' + str(request.GET.get('id', -1)))

        if 'send' in request.POST:
            comments_text = request.POST.get('comments', "No_comments")
            # 保存评论
            Comment.objects.create(
                article=article,
                author=user,
                content=comments_text
            )
        elif 'delete' in request.POST:
            comment_id = int(request.POST.get('delete', "-1"))
            try:
                article_author = article.author
                comment_author = Comment.objects.filter(id=comment_id)[0].author
                if comment_author.username == username or article_author.username == username or administrator == 1:
                    Comment.objects.filter(id=comment_id).delete()
                else:
                    print('权限不足，评论id:', comment_id, '删除失败')
                    return redirect(reverse('Knowledge:Search') + f'?word=权限不足删除失败，文章ID:{str(article.id)}，评论ID:{str(comment_id)}')
            except Exception as e:
                print('未知原因，评论id:', comment_id, '删除失败')
                return redirect(reverse('Knowledge:Search') + f'?word=未知原因删除失败，文章ID:{str(article.id)}，评论ID:{str(comment_id)}')

        return redirect(reverse('Forum:Detail') + '?id=' + article_id)


def Send(request):
    request.session['page'] = reverse('Forum:Send')

    # 获取用户会话信息
    user = {
        'nickname': request.session.get('nickname', ''),
        'username': request.session.get('username', ''),
        'role': request.session.get('role', 0)
    }
    username = user.get('username', '')
    nickname = user.get('nickname', '')
    administrator = user.get('role', '')

    if username == "":
        request.session['page'] = reverse('Forum:Index')
        return redirect('User:login')
    user = User.objects.get(username=username)

    if request.method == 'GET':

        return render(request, 'Forum_Send.html', {
            'user': user,
            'username': username,
            'nickname': nickname,
            'administrator': administrator,
        })

    elif request.method == 'POST':
        # 获取最后 article_id
        last_article = Article.objects.order_by('-id').first()
        last_article_id = last_article.id if last_article else 0

        # 获取图片文件
        picture = request.FILES.get('picture', None)
        filename = ""
        if picture:
            # 保存图片文件到本地
            fs = FileSystemStorage(location=os.path.join(settings.MEDIA_ROOT, 'picture'))
            ext = picture.name.split('.')[-1].lower()
            if ext in ["png", "svg", "jpg", "jpeg", "webp"]:
                filename = f"{last_article_id + 1}.{ext}"
                fs.save(filename, picture)
                filename = 'picture/' + filename

        # 获取文章信息
        title = request.POST.get('title', 'No_title')
        content = request.POST.get('content', 'No_content')

        # 保存文章信息到数据库
        Article.objects.create(
            title=title,
            content=content,
            image=os.path.join(settings.MEDIA_URL, filename) if filename else '0',
            author=user
        )
        return redirect('Forum:MyArticle')


def Edit(request):
    request.session['page'] = reverse('Forum:Edit')

    # 获取用户会话信息
    user = {
        'nickname': request.session.get('nickname', ''),
        'username': request.session.get('username', ''),
        'role': request.session.get('role', 0)
    }
    username = user.get('username', '')
    nickname = user.get('nickname', '')
    administrator = user.get('role', '')

    if username == "":
        return redirect('User:login')

    if request.method == 'GET':
        try:
            article_id = request.GET.get('id', -1)
            article = Article.objects.get(id=article_id)
        except Exception as e:
            return redirect(reverse('Knowledge:Search') + '?word=未知的文章ID:' + str(request.GET.get('id', -1)))

        return render(request, 'Forum_Edit.html', {
            'user': user,
            'username': username,
            'nickname': nickname,
            'administrator': administrator,
            'article_data': article,
        })

    elif request.method == 'POST':
        try:
            article_id = request.POST.get('id', -1)
            article = Article.objects.get(id=article_id)
            if username != article.author.username:
                return redirect(reverse('Knowledge:Search') + '?word=权限不足修改失败，文章ID:' + str(request.GET.get('id', -1)))
        except Exception as e:
            return redirect(reverse('Knowledge:Search') + '?word=未知的文章ID:' + str(request.GET.get('id', -1)))

        # 获取文章信息
        title = request.POST.get('title', 'No_title')
        content = request.POST.get('content', 'No_content')
        picture = request.FILES.get('picture', None)
        switch_img = request.POST.get('switch_img', None)  # 获取复选框的值

        article.title = title
        article.content = content

        # 检查是否需要删除原有图片
        if switch_img:
            # 删除原有图片文件
            if article.image and article.image != '0':
                fs = FileSystemStorage(location=os.path.join(settings.MEDIA_ROOT, 'picture'))
                filename = article.image.split('/')[-1]
                if fs.exists(filename):
                    fs.delete(filename)
            # 将图片字段设置为默认值
            article.image = '0'
        else:
            # 如果上传了新图片，更新图片字段
            if picture:
                fs = FileSystemStorage(location=os.path.join(settings.MEDIA_ROOT, 'picture'))
                ext = picture.name.split('.')[-1].lower()
                if ext in ["png", "svg", "jpg", "jpeg", "webp"]:
                    filename = f"{article_id}.{ext}"
                    # 检查文件是否已经存在
                    if fs.exists(filename):
                        # 删除旧文件
                        fs.delete(filename)
                    # 保存新文件
                    fs.save(filename, picture)
                    article.image = os.path.join(settings.MEDIA_URL, 'picture/', filename) if filename else '0'

        article.save()

        print("Notice: 更新信息已修改到数据库。")
        return redirect('Forum:MyArticle')


def MyArticle(request):
    request.session['page'] = reverse('Forum:Index')

    # 获取用户会话信息
    user = {
        'nickname': request.session.get('nickname', ''),
        'username': request.session.get('username', ''),
        'role': request.session.get('role', 0)
    }
    username = user.get('username', '')
    nickname = user.get('nickname', '')
    administrator = user.get('role', '')

    if username == "":
        return redirect('User:login')
    user = User.objects.get(username=username)

    if request.method == 'GET':
        # 获取请求中的分页参数
        pages = int(request.GET.get("pages", 1))

        # 显示文章
        start_article = (pages - 1) * 10
        articles = Article.objects.filter(author=user).order_by('-id')[start_article:start_article + 10]

        # 查询文章数据
        count_article = Article.objects.filter(author=user).count()

        count_pages = (count_article + 9) // 10
        if count_pages == 0:
            pages_list = [0, 0, 0, 0, 0, 0, count_pages]
        elif count_pages == 1:
            pages_list = [pages, 0, 0, 1, 0, 0, count_pages]
        elif count_pages == 2:
            if pages == 1:
                pages_list = [pages, 0, 1, 2, 0, 2, count_pages]
            else:
                pages_list = [pages, 1, 1, 2, 0, 0, count_pages]
        else:
            pages_list = [pages, pages - 1, pages - 1, pages, pages + 1, pages + 1, count_pages]

        print("Notice: 第", pages, "页，共", count_pages, "页")

        return render(request, 'Forum_MyArticle.html', {
            'user': user,
            'username': username,
            'nickname': nickname,
            'administrator': administrator,
            'data': articles,
            'pages': pages_list,
        })

    elif request.method == 'POST':
        article_id = request.POST.get('deleteArticleID', '').strip()
        try:
            article = Article.objects.get(id=article_id)
            if username != article.author.username:
                return redirect(reverse('Knowledge:Search') + '?word=权限不足删除失败，文章ID:' + str(request.GET.get('id', -1)))
            # 删除图片文件
            if article.image and article.image != '0':
                fs = FileSystemStorage(location=os.path.join(settings.MEDIA_ROOT, 'picture'))
                filename = article.image.split('/')[-1]
                if fs.exists(filename):
                    fs.delete(filename)
            article.delete()  # 删除文章
        except Exception as e:
            return redirect(reverse('Knowledge:Search') + '?word=未知的文章ID:' + str(request.GET.get('id', -1)))

        return redirect('Forum:MyArticle')
