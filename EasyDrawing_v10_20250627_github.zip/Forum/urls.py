from django.urls import path
from . import views

app_name = 'Forum'

urlpatterns = [
    path('', views.Index, name='Index'),  # 论坛首页
    path('Send/', views.Send, name='Send'),
    path('MyArticle/', views.MyArticle, name='MyArticle'),
    path('Detail/', views.Detail, name='Detail'),
    path('Edit/', views.Edit, name='Edit'),
]
