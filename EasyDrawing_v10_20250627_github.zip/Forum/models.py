from django.db import models

# Create your models here.
class Article(models.Model):
    id = models.BigAutoField(primary_key=True)
    created_at = models.DateTimeField(auto_now_add=True, verbose_name="创建时间")
    updated_at = models.DateTimeField(auto_now=True, verbose_name="更新时间")
    title = models.CharField(max_length=200, verbose_name="标题")
    content = models.TextField(verbose_name="内容")
    image = models.CharField(max_length=200, blank=True, null=True, verbose_name="图片地址", default='0')
    author = models.ForeignKey('User.User', on_delete=models.CASCADE, db_column='username', to_field="username", verbose_name="作者")

    def __str__(self):
        return self.title

    class Meta:
        verbose_name = "文章"
        verbose_name_plural = "文章列表"
        ordering = ['-created_at']  # 按创建时间降序排列


class Comment(models.Model):
    id = models.BigAutoField(primary_key=True)
    article = models.ForeignKey('Article', on_delete=models.CASCADE, related_name='comments', verbose_name="所属文章")
    author = models.ForeignKey('User.User', on_delete=models.CASCADE, verbose_name="评论者")
    content = models.TextField(verbose_name="评论内容")
    created_at = models.DateTimeField(auto_now_add=True, verbose_name="评论时间")

    def __str__(self):
        return f"评论 发表自 {self.author.username} 位于文章 {self.article.title}"

    class Meta:
        verbose_name = "评论"
        verbose_name_plural = "评论列表"
        ordering = ['-created_at']  # 按评论时间降序排列