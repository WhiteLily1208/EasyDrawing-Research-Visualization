from django.contrib import admin
from .models import Article, Comment

# Register your models here.

@admin.register(Article)
class ArticleAdmin(admin.ModelAdmin):
    list_display = ('title', 'author', 'created_at')  # 在列表页显示的字段
    list_filter = ('author', 'created_at')  # 添加过滤器
    search_fields = ('title', 'content')  # 添加搜索字段
    date_hierarchy = 'created_at'  # 按日期层次结构显示
    ordering = ('-created_at',)  # 默认排序方式

    def short_article(self, obj):
        return obj.content[:30]  # 显示前30个字符

    short_article.short_description = "文章内容"  # 自定义列标题

@admin.register(Comment)
class CommentAdmin(admin.ModelAdmin):
    list_display = ('article', 'author', 'created_at')  # 在列表页显示的字段
    list_filter = ('author', 'created_at')  # 添加过滤器
    search_fields = ('content',)  # 添加搜索字段
    ordering = ('-created_at',)  # 默认排序方式

    def short_content(self, obj):
        return obj.content[:30]  # 显示前30个字符

    short_content.short_description = "评论内容"  # 自定义列标题