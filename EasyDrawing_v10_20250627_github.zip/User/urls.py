from django.urls import path
from . import views

app_name = 'User'

urlpatterns = [
    path('login/', views.EDlogin, name='login'),
    path('logout/', views.EDlogout, name='logout'),
    path('signup/', views.EDsignup, name='signup'),
    path('SponsorUs/', views.SponsorUs, name='SponsorUs'),
    path('SponsorshipClause/', views.SponsorshipClause, name='SponsorshipClause'),
    path('PrivacyPolicy/', views.PrivacyPolicy, name='PrivacyPolicy'),
]