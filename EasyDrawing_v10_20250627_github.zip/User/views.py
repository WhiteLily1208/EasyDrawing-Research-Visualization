from .models import User
from django.contrib.auth import logout
from django.shortcuts import render, redirect, reverse
import re
import hashlib


# Create your views here.
def EDlogin(request):
    if request.method == "GET":
        page = request.session.get('page', '/')
        print('page:', page)
        logout(request)  # 清除用户的会话信息
        request.session['page'] = page
        return render(request, 'User_Login.html', {'page': page})
    else: # request.method == 'POST':
        page = request.session.get('page', '/')
        print('page:', page)
        username = request.POST.get('username')
        password = request.POST.get('password')
        remember = request.POST.get('remember_me', 'off')  # 获取复选框的值
        print(f"(1)username:{username} (2)password:{password} (3)remember:{remember}")
        username_re = re.compile(r"^[a-zA-Z0-9_@.]{1,18}$")
        password_re = re.compile(r"^[a-zA-Z0-9_@]{6,20}$")
        if not username or not password:
            notice = "缺少账号或密码"
            return render(request, 'User_Login.html', {'notice': notice, 'username': username, 'page': page})
        elif not username_re.match(username):
            notice = "账号格式不符"
            return render(request, 'User_Login.html', {'notice': notice, 'username': username, 'page': page})
        elif not password_re.match(password):
            notice = "密码格式不符"
            return render(request, 'User_Login.html', {'notice': notice, 'username': username, 'page': page})
        else:
            hash_object = hashlib.sha256()
            hash_object.update(password.encode("utf-8"))
            sha256_password = hash_object.hexdigest()
            try:
                user = User.objects.get(username=username)
            except User.DoesNotExist:
                notice = "账号不存在"
                return render(request, 'User_Login.html', {'notice': notice, 'username': username, 'page': page})
            if user.password != sha256_password:
                notice = "密码不正确"
                return render(request, 'User_Login.html', {'notice': notice, 'username': username, 'page': page})
            else:
                request.session['nickname'] = user.nickname
                request.session['username'] = user.username
                request.session['role'] = user.role
                # 如果用户勾选了“记住登录状态”，设置会话过期时间为两周
                if remember == 'on':
                    request.session.set_expiry(1209600)
                    print("(4)remember: YES")
                else:
                    # 否则，会话在浏览器关闭时过期
                    request.session.set_expiry(0)
                    print("(4)remember: NO")
                return redirect(page)


def EDlogout(request):
    page = request.session.get('page', '/')
    print('page:', page)
    logout(request)  # 清除用户的会话信息
    request.session['page'] = page
    return redirect(page)  # 重定向到登录页面


def EDsignup(request):
    if request.method == "GET":
        page = request.session.get('page', '/')
        print('page:', page)
        logout(request)  # 清除用户的会话信息
        request.session['page'] = page
        return render(request, 'User_Signup.html', {'page': page})
    else: # request.method == 'POST':
        page = request.session.get('page', '/')
        print('page:', page)
        nickname = request.POST.get('nickname')
        username = request.POST.get('username')
        password = request.POST.get('password')
        quickly = request.POST.get('quickly', 'off')
        print(f"(1)nickname:{nickname} (2)username:{username} (3)password:{password}")
        nickname_re = re.compile(r"^[\u4e00-\u9fa5a-zA-Z0-9_]{1,10}$")
        username_re = re.compile(r"^[a-zA-Z0-9_@.]{1,18}$")
        password_re = re.compile(r"^[a-zA-Z0-9_@]{6,20}$")
        if not nickname or not username or not password:
            notice = "缺少昵称、账号或密码"
            return render(request, 'User_Signup.html', {'notice': notice, 'username': username, 'nickname': nickname, 'page': page})
        elif not nickname_re.match(nickname):
            notice = "昵称格式不符"
            return render(request, 'User_Signup.html', {'notice': notice, 'username': username, 'nickname': nickname, 'page': page})
        elif not username_re.match(username):
            notice = "账号格式不符"
            return render(request, 'User_Signup.html', {'notice': notice, 'username': username, 'nickname': nickname, 'page': page})
        elif not password_re.match(password):
            notice = "密码格式不符"
            return render(request, 'User_Signup.html', {'notice': notice, 'username': username, 'nickname': nickname, 'page': page})
        else:
            hash_object = hashlib.sha256()
            hash_object.update(password.encode("utf-8"))
            sha256_password = hash_object.hexdigest()
            try:
                User.objects.get(username=username)
                notice = "账号已存在"
                return render(request, 'User_Signup.html', {'notice': notice, 'username': username, 'nickname': nickname, 'page': page})
            except User.DoesNotExist:
                # 创建并保存新用户
                user = User.objects.create(
                    nickname = nickname,
                    username = username,
                    password = sha256_password,
                )
                # 如果用户勾选了“注册后自动登录”，跳过登录步骤
                if quickly == 'on':
                    request.session['nickname'] = user.nickname
                    request.session['username'] = user.username
                    request.session['role'] = user.role
                    print("(4)quickly: YES")
                else:
                    # 否则，回到之前页面
                    print("(4)quickly: NO")
                return redirect(page)


def SponsorUs(request):
    request.session['page'] = reverse('User:SponsorUs')
    user = {
        'nickname': request.session.get('nickname', ''),
        'username': request.session.get('username', ''),
        'role': request.session.get('role', 0)
    }
    print(user)
    return render(request, 'User_SponsorUs.html', {'user': user})

def SponsorshipClause(request):
    return render(request, 'User_SponsorshipClause.html')

def PrivacyPolicy(request):
    return render(request, 'User_PrivacyPolicy.html')